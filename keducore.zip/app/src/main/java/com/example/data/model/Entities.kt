package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "teachers")
data class Teacher(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val email: String,
    val phone: String,
    val subject: String,
    val employeeId: String = "",
    val qualification: String = "B.Ed, Bachelor's Degree",
    val joinDate: String = "2023-08-01",
    val address: String = "",
    val photoAvatar: String = "avatar_teacher_1",
    val assignedSubjects: String = "",
    val username: String = "",
    val passwordHash: String = "teacher123",
    val isActive: Boolean = true,
    val lastLogin: Long? = null
)

@Entity(tableName = "classes")
data class SchoolClass(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, // e.g. "Grade 10" or "Class 8"
    val section: String, // e.g. "A", "B"
    val roomNumber: String,
    val teacherId: Long? = null // Assigned Class Teacher ID
) {
    val displayName: String
        get() = if (section.isNotBlank()) "$name - $section" else name
}

@Entity(
    tableName = "students",
    indices = [Index(value = ["classId"])]
)
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val rollNumber: String,
    val classId: Long,
    val parentContact: String = "",
    val gender: String = "Other",
    val parentName: String = "",
    val parentEmail: String = "",
    val guardianRelation: String = "Parent",
    val address: String = "",
    val emergencyContact: String = "",
    val bloodGroup: String = "O+",
    val dateOfBirth: String = "2010-05-15",
    val admissionDate: String = "2022-04-01",
    val photoAvatar: String = "avatar_student_1",
    val isActive: Boolean = true
)

@Entity(
    tableName = "attendance_records",
    indices = [Index(value = ["classId", "date"], unique = true)]
)
data class AttendanceRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val classId: Long,
    val date: String, // Format: YYYY-MM-DD
    val teacherId: Long,
    val isSubmitted: Boolean = false,
    val submittedAt: Long? = null,
    val notes: String = ""
)

@Entity(
    tableName = "attendance_items",
    indices = [Index(value = ["attendanceRecordId", "studentId"], unique = true)]
)
data class AttendanceItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val attendanceRecordId: Long,
    val studentId: Long,
    val isPresent: Boolean = true,
    val absentReason: String = "" // Optional note for absent students
)

@Entity(
    tableName = "teacher_attendance",
    indices = [Index(value = ["teacherId", "date"], unique = true)]
)
data class TeacherAttendanceRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val teacherId: Long,
    val date: String, // YYYY-MM-DD
    val status: String = "PRESENT", // "PRESENT", "ABSENT", "HALF_DAY", "ON_LEAVE"
    val notes: String = ""
)

@Entity(tableName = "homework")
data class Homework(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val classId: Long,
    val teacherId: Long,
    val subject: String,
    val title: String,
    val description: String,
    val dueDate: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "student_marks")
data class StudentMark(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val classId: Long,
    val studentId: Long,
    val subject: String,
    val assessmentName: String, // e.g., "Unit Test 1", "Midterm"
    val maxMarks: Int = 100,
    val obtainedMarks: Int,
    val remarks: String = "",
    val date: String
)

@Entity(tableName = "announcements")
data class Announcement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val authorName: String = "Principal Office",
    val targetAudience: String = "ALL", // "ALL", "TEACHERS", "STUDENTS", "CLASS_SPECIFIC"
    val targetClassId: Long? = null,
    val targetClassName: String? = null,
    val category: String = "CIRCULAR", // "CIRCULAR", "URGENT", "EVENT", "EXAM", "HOLIDAY"
    val createdAt: Long = System.currentTimeMillis(),
    val isImportant: Boolean = false
)

@Entity(tableName = "leave_applications")
data class LeaveApplication(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val teacherId: Long,
    val leaveType: String, // "Sick Leave", "Casual Leave", "Personal Leave", etc.
    val startDate: String,
    val endDate: String,
    val reason: String,
    val status: String = "PENDING", // "PENDING", "APPROVED", "REJECTED"
    val principalRemark: String = "",
    val appliedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "timetable_entries",
    indices = [Index(value = ["classId", "dayOfWeek", "periodNumber"], unique = true)]
)
data class TimetableEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val classId: Long,
    val dayOfWeek: String, // "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    val periodNumber: Int, // 1 to 7
    val startTime: String, // "08:30 AM"
    val endTime: String, // "09:15 AM"
    val subject: String,
    val teacherId: Long,
    val roomNumber: String = ""
)

@Entity(tableName = "exam_schedules")
data class ExamSchedule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examName: String, // e.g. "Mid-Term Examination 2026"
    val classId: Long,
    val subject: String,
    val examDate: String, // YYYY-MM-DD
    val startTime: String, // "09:00 AM"
    val endTime: String, // "12:00 PM"
    val roomNumber: String = "",
    val maxMarks: Int = 100,
    val instructions: String = ""
)

@Entity(tableName = "school_events")
data class SchoolEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val date: String, // YYYY-MM-DD
    val endDate: String? = null,
    val eventType: String = "EVENT", // "HOLIDAY", "EXAM", "EVENT", "MEETING"
    val isHoliday: Boolean = false
)

@Entity(tableName = "school_settings")
data class SchoolSettingsEntity(
    @PrimaryKey val id: Long = 1,
    val schoolName: String = "KEduCore Academy",
    val schoolAddress: String = "124 Education Boulevard, Academic City",
    val schoolPhone: String = "+1 (555) 019-2834",
    val schoolEmail: String = "admin@keducore.edu",
    val academicSession: String = "2026 - 2027",
    val principalName: String = "Dr. Arthur Vance, Ph.D",
    val principalUsername: String = "admin",
    val principalPassword: String = "admin123",
    val principalPin: String = "1234",
    val isPinEnabled: Boolean = false,
    val isBiometricEnabled: Boolean = false
)

@Entity(tableName = "absence_notification_logs")
data class AbsenceNotificationLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val studentName: String,
    val className: String,
    val parentContact: String,
    val date: String,
    val message: String,
    val sentAt: Long = System.currentTimeMillis(),
    val status: String = "DELIVERED" // "DELIVERED", "QUEUED", "SMS_SENT"
)

// UI & Aggregate models
data class ClassAttendanceSummary(
    val classItem: SchoolClass,
    val teacherName: String,
    val totalStudents: Int,
    val presentCount: Int,
    val absentCount: Int,
    val absentStudentsWithNotes: List<AbsentStudentDetail>,
    val date: String,
    val isSubmitted: Boolean,
    val submittedAt: Long?
)

data class AbsentStudentDetail(
    val studentId: Long,
    val studentName: String,
    val rollNumber: String,
    val parentContact: String = "",
    val reason: String = ""
)

data class StudentWithAttendance(
    val student: Student,
    val isPresent: Boolean,
    val absentReason: String
)

data class StudentAttendanceStats(
    val student: Student,
    val className: String,
    val totalRecordedDays: Int,
    val presentDays: Int,
    val absentDays: Int,
    val attendancePercentage: Float,
    val recentRecords: List<StudentDailyAttendanceRecord> = emptyList()
)

data class StudentDailyAttendanceRecord(
    val date: String,
    val isPresent: Boolean,
    val absentReason: String
)

data class SubjectAnalysis(
    val subject: String,
    val assessmentName: String,
    val classId: Long,
    val className: String,
    val totalStudentsEvaluated: Int,
    val averageMarks: Float,
    val highestMark: Int,
    val lowestMark: Int,
    val maxMarks: Int,
    val passPercentage: Float
)

data class StudentReportCard(
    val student: Student,
    val schoolClass: SchoolClass,
    val academicSession: String,
    val assessmentName: String,
    val subjectMarks: List<StudentMark>,
    val totalMarksObtained: Int,
    val totalMaxMarks: Int,
    val percentage: Float,
    val grade: String,
    val rankInClass: Int,
    val attendancePercentage: Float,
    val teacherRemarks: String
)

data class BackupDataModel(
    val exportDate: String,
    val version: Int = 2,
    val teachers: List<Teacher>,
    val classes: List<SchoolClass>,
    val students: List<Student>,
    val attendanceRecords: List<AttendanceRecord>,
    val attendanceItems: List<AttendanceItem>,
    val homework: List<Homework>,
    val marks: List<StudentMark>,
    val announcements: List<Announcement>,
    val leaves: List<LeaveApplication>,
    val timetables: List<TimetableEntry>,
    val exams: List<ExamSchedule>,
    val events: List<SchoolEvent>,
    val settings: SchoolSettingsEntity
)
