package com.example.data.local.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SchoolDao {

    // --- Teachers ---
    @Query("SELECT * FROM teachers ORDER BY name ASC")
    fun getAllTeachers(): Flow<List<Teacher>>

    @Query("SELECT * FROM teachers WHERE id = :id LIMIT 1")
    suspend fun getTeacherById(id: Long): Teacher?

    @Query("SELECT * FROM teachers WHERE (LOWER(username) = LOWER(:identifier) OR LOWER(email) = LOWER(:identifier)) LIMIT 1")
    suspend fun getTeacherByUsernameOrEmail(identifier: String): Teacher?

    @Query("SELECT * FROM teachers")
    suspend fun getAllTeachersSync(): List<Teacher>

    @Query("UPDATE teachers SET isActive = :isActive WHERE id = :teacherId")
    suspend fun updateTeacherStatus(teacherId: Long, isActive: Boolean)

    @Query("UPDATE teachers SET passwordHash = :passwordHash WHERE id = :teacherId")
    suspend fun updateTeacherPassword(teacherId: Long, passwordHash: String)

    @Query("UPDATE teachers SET lastLogin = :lastLogin WHERE id = :teacherId")
    suspend fun updateTeacherLastLogin(teacherId: Long, lastLogin: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeacher(teacher: Teacher): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeachers(teachers: List<Teacher>)

    @Update
    suspend fun updateTeacher(teacher: Teacher)

    @Delete
    suspend fun deleteTeacher(teacher: Teacher)

    @Query("DELETE FROM teachers")
    suspend fun deleteAllTeachers()

    // --- Classes ---
    @Query("SELECT * FROM classes ORDER BY name ASC, section ASC")
    fun getAllClasses(): Flow<List<SchoolClass>>

    @Query("SELECT * FROM classes")
    suspend fun getAllClassesSync(): List<SchoolClass>

    @Query("SELECT * FROM classes WHERE id = :id LIMIT 1")
    suspend fun getClassById(id: Long): SchoolClass?

    @Query("SELECT * FROM classes WHERE teacherId = :teacherId LIMIT 1")
    fun getClassForTeacher(teacherId: Long): Flow<SchoolClass?>

    @Query("SELECT * FROM classes WHERE teacherId = :teacherId LIMIT 1")
    suspend fun getClassForTeacherSync(teacherId: Long): SchoolClass?

    @Query("UPDATE classes SET teacherId = NULL WHERE teacherId = :teacherId")
    suspend fun unassignTeacherFromAllClasses(teacherId: Long)

    @Query("UPDATE classes SET teacherId = :teacherId WHERE id = :classId")
    suspend fun assignTeacherToClass(classId: Long, teacherId: Long?)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClass(schoolClass: SchoolClass): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClasses(classes: List<SchoolClass>)

    @Update
    suspend fun updateClass(schoolClass: SchoolClass)

    @Delete
    suspend fun deleteClass(schoolClass: SchoolClass)

    @Query("DELETE FROM classes")
    suspend fun deleteAllClasses()

    // --- Students ---
    @Query("SELECT * FROM students ORDER BY rollNumber ASC, name ASC")
    fun getAllStudents(): Flow<List<Student>>

    @Query("SELECT * FROM students")
    suspend fun getAllStudentsSync(): List<Student>

    @Query("SELECT * FROM students WHERE classId = :classId ORDER BY rollNumber ASC, name ASC")
    fun getStudentsByClass(classId: Long): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE classId = :classId ORDER BY rollNumber ASC, name ASC")
    suspend fun getStudentsByClassSync(classId: Long): List<Student>

    @Query("SELECT * FROM students WHERE id = :id LIMIT 1")
    suspend fun getStudentById(id: Long): Student?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: Student): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudents(students: List<Student>)

    @Update
    suspend fun updateStudent(student: Student)

    @Query("UPDATE students SET isActive = :isActive WHERE id = :studentId")
    suspend fun updateStudentStatus(studentId: Long, isActive: Boolean)

    @Delete
    suspend fun deleteStudent(student: Student)

    @Query("DELETE FROM students")
    suspend fun deleteAllStudents()

    // --- Attendance Records & Items ---
    @Query("SELECT * FROM attendance_records WHERE classId = :classId AND date = :date LIMIT 1")
    fun getAttendanceRecord(classId: Long, date: String): Flow<AttendanceRecord?>

    @Query("SELECT * FROM attendance_records WHERE classId = :classId AND date = :date LIMIT 1")
    suspend fun getAttendanceRecordSync(classId: Long, date: String): AttendanceRecord?

    @Query("SELECT * FROM attendance_records WHERE date = :date")
    fun getAttendanceRecordsByDate(date: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records WHERE date LIKE :monthPrefix || '%'")
    fun getAttendanceRecordsByMonth(monthPrefix: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records")
    fun getAllAttendanceRecords(): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records")
    suspend fun getAllAttendanceRecordsSync(): List<AttendanceRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendanceRecord(record: AttendanceRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendanceRecords(records: List<AttendanceRecord>)

    @Update
    suspend fun updateAttendanceRecord(record: AttendanceRecord)

    @Query("SELECT * FROM attendance_items WHERE attendanceRecordId = :recordId")
    fun getAttendanceItems(recordId: Long): Flow<List<AttendanceItem>>

    @Query("SELECT * FROM attendance_items WHERE attendanceRecordId = :recordId")
    suspend fun getAttendanceItemsSync(recordId: Long): List<AttendanceItem>

    @Query("SELECT * FROM attendance_items")
    fun getAllAttendanceItems(): Flow<List<AttendanceItem>>

    @Query("SELECT * FROM attendance_items")
    suspend fun getAllAttendanceItemsSync(): List<AttendanceItem>

    @Query("SELECT * FROM attendance_items WHERE studentId = :studentId")
    suspend fun getAttendanceItemsForStudent(studentId: Long): List<AttendanceItem>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendanceItems(items: List<AttendanceItem>)

    @Query("DELETE FROM attendance_items WHERE attendanceRecordId = :recordId")
    suspend fun deleteAttendanceItemsForRecord(recordId: Long)

    @Query("DELETE FROM attendance_records")
    suspend fun deleteAllAttendanceRecords()

    @Query("DELETE FROM attendance_items")
    suspend fun deleteAllAttendanceItems()

    // --- Teacher Attendance ---
    @Query("SELECT * FROM teacher_attendance WHERE date = :date")
    fun getTeacherAttendanceByDate(date: String): Flow<List<TeacherAttendanceRecord>>

    @Query("SELECT * FROM teacher_attendance WHERE teacherId = :teacherId ORDER BY date DESC")
    fun getTeacherAttendanceHistory(teacherId: Long): Flow<List<TeacherAttendanceRecord>>

    @Query("SELECT * FROM teacher_attendance WHERE date = :date AND teacherId = :teacherId LIMIT 1")
    suspend fun getTeacherAttendanceForDate(teacherId: Long, date: String): TeacherAttendanceRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeacherAttendance(record: TeacherAttendanceRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeacherAttendances(records: List<TeacherAttendanceRecord>)

    @Query("DELETE FROM teacher_attendance")
    suspend fun deleteAllTeacherAttendance()

    // --- Homework ---
    @Query("SELECT * FROM homework ORDER BY createdAt DESC")
    fun getAllHomework(): Flow<List<Homework>>

    @Query("SELECT * FROM homework")
    suspend fun getAllHomeworkSync(): List<Homework>

    @Query("SELECT * FROM homework WHERE classId = :classId ORDER BY createdAt DESC")
    fun getHomeworkByClass(classId: Long): Flow<List<Homework>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomework(homework: Homework): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomeworkList(homework: List<Homework>)

    @Delete
    suspend fun deleteHomework(homework: Homework)

    @Query("DELETE FROM homework")
    suspend fun deleteAllHomework()

    // --- Student Marks ---
    @Query("SELECT * FROM student_marks ORDER BY date DESC")
    fun getAllMarks(): Flow<List<StudentMark>>

    @Query("SELECT * FROM student_marks")
    suspend fun getAllMarksSync(): List<StudentMark>

    @Query("SELECT * FROM student_marks WHERE classId = :classId ORDER BY date DESC")
    fun getMarksByClass(classId: Long): Flow<List<StudentMark>>

    @Query("SELECT * FROM student_marks WHERE studentId = :studentId ORDER BY date DESC")
    fun getMarksForStudent(studentId: Long): Flow<List<StudentMark>>

    @Query("SELECT * FROM student_marks WHERE studentId = :studentId")
    suspend fun getMarksForStudentSync(studentId: Long): List<StudentMark>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMark(mark: StudentMark): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMarks(marks: List<StudentMark>)

    @Delete
    suspend fun deleteMark(mark: StudentMark)

    @Query("DELETE FROM student_marks")
    suspend fun deleteAllMarks()

    // --- Announcements ---
    @Query("SELECT * FROM announcements ORDER BY createdAt DESC")
    fun getAllAnnouncements(): Flow<List<Announcement>>

    @Query("SELECT * FROM announcements")
    suspend fun getAllAnnouncementsSync(): List<Announcement>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncement(announcement: Announcement): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncements(announcements: List<Announcement>)

    @Delete
    suspend fun deleteAnnouncement(announcement: Announcement)

    @Query("DELETE FROM announcements")
    suspend fun deleteAllAnnouncements()

    // --- Leave Applications ---
    @Query("SELECT * FROM leave_applications ORDER BY appliedAt DESC")
    fun getAllLeaves(): Flow<List<LeaveApplication>>

    @Query("SELECT * FROM leave_applications")
    suspend fun getAllLeavesSync(): List<LeaveApplication>

    @Query("SELECT * FROM leave_applications WHERE teacherId = :teacherId ORDER BY appliedAt DESC")
    fun getLeavesForTeacher(teacherId: Long): Flow<List<LeaveApplication>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeave(leave: LeaveApplication): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeaves(leaves: List<LeaveApplication>)

    @Update
    suspend fun updateLeave(leave: LeaveApplication)

    @Delete
    suspend fun deleteLeave(leave: LeaveApplication)

    @Query("DELETE FROM leave_applications")
    suspend fun deleteAllLeaves()

    // --- Timetable ---
    @Query("SELECT * FROM timetable_entries ORDER BY dayOfWeek ASC, periodNumber ASC")
    fun getAllTimetableEntries(): Flow<List<TimetableEntry>>

    @Query("SELECT * FROM timetable_entries")
    suspend fun getAllTimetableEntriesSync(): List<TimetableEntry>

    @Query("SELECT * FROM timetable_entries WHERE classId = :classId ORDER BY dayOfWeek ASC, periodNumber ASC")
    fun getTimetableForClass(classId: Long): Flow<List<TimetableEntry>>

    @Query("SELECT * FROM timetable_entries WHERE teacherId = :teacherId ORDER BY dayOfWeek ASC, periodNumber ASC")
    fun getTimetableForTeacher(teacherId: Long): Flow<List<TimetableEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimetableEntry(entry: TimetableEntry): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimetableEntries(entries: List<TimetableEntry>)

    @Delete
    suspend fun deleteTimetableEntry(entry: TimetableEntry)

    @Query("DELETE FROM timetable_entries")
    suspend fun deleteAllTimetable()

    // --- Exam Schedules ---
    @Query("SELECT * FROM exam_schedules ORDER BY examDate ASC, startTime ASC")
    fun getAllExamSchedules(): Flow<List<ExamSchedule>>

    @Query("SELECT * FROM exam_schedules")
    suspend fun getAllExamSchedulesSync(): List<ExamSchedule>

    @Query("SELECT * FROM exam_schedules WHERE classId = :classId ORDER BY examDate ASC, startTime ASC")
    fun getExamSchedulesByClass(classId: Long): Flow<List<ExamSchedule>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExamSchedule(exam: ExamSchedule): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExamSchedules(exams: List<ExamSchedule>)

    @Delete
    suspend fun deleteExamSchedule(exam: ExamSchedule)

    @Query("DELETE FROM exam_schedules")
    suspend fun deleteAllExamSchedules()

    // --- School Events & Holidays ---
    @Query("SELECT * FROM school_events ORDER BY date ASC")
    fun getAllSchoolEvents(): Flow<List<SchoolEvent>>

    @Query("SELECT * FROM school_events")
    suspend fun getAllSchoolEventsSync(): List<SchoolEvent>

    @Query("SELECT * FROM school_events WHERE isHoliday = 1 ORDER BY date ASC")
    fun getAllHolidays(): Flow<List<SchoolEvent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchoolEvent(event: SchoolEvent): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchoolEvents(events: List<SchoolEvent>)

    @Delete
    suspend fun deleteSchoolEvent(event: SchoolEvent)

    @Query("DELETE FROM school_events")
    suspend fun deleteAllSchoolEvents()

    // --- School Settings ---
    @Query("SELECT * FROM school_settings WHERE id = 1 LIMIT 1")
    fun getSchoolSettings(): Flow<SchoolSettingsEntity?>

    @Query("SELECT * FROM school_settings WHERE id = 1 LIMIT 1")
    suspend fun getSchoolSettingsSync(): SchoolSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSchoolSettings(settings: SchoolSettingsEntity)

    // --- Absence Notifications Log ---
    @Query("SELECT * FROM absence_notification_logs ORDER BY sentAt DESC")
    fun getAllAbsenceLogs(): Flow<List<AbsenceNotificationLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAbsenceLog(log: AbsenceNotificationLog): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAbsenceLogs(logs: List<AbsenceNotificationLog>)
}
