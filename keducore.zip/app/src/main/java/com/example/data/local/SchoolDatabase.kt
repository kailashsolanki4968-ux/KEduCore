package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.SchoolDao
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Database(
    entities = [
        Teacher::class,
        SchoolClass::class,
        Student::class,
        AttendanceRecord::class,
        AttendanceItem::class,
        TeacherAttendanceRecord::class,
        Homework::class,
        StudentMark::class,
        Announcement::class,
        LeaveApplication::class,
        TimetableEntry::class,
        ExamSchedule::class,
        SchoolEvent::class,
        SchoolSettingsEntity::class,
        AbsenceNotificationLog::class
    ],
    version = 2,
    exportSchema = false
)
abstract class SchoolDatabase : RoomDatabase() {
    abstract fun schoolDao(): SchoolDao

    companion object {
        @Volatile
        private var INSTANCE: SchoolDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): SchoolDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SchoolDatabase::class.java,
                    "school_management_database"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(SchoolDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class SchoolDatabaseCallback(
        private val scope: CoroutineScope
    ) : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database.schoolDao())
                }
            }
        }

        private suspend fun populateInitialData(dao: SchoolDao) {
            val todayDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

            // 1. Initial School Settings
            dao.insertOrUpdateSchoolSettings(
                SchoolSettingsEntity(
                    id = 1,
                    schoolName = "KEduCore Academy",
                    schoolAddress = "124 Education Boulevard, Academic City",
                    schoolPhone = "+1 (555) 019-2834",
                    schoolEmail = "admin@keducore.edu",
                    academicSession = "2026 - 2027",
                    principalName = "Dr. Arthur Vance, Ph.D",
                    principalUsername = "admin",
                    principalPassword = "admin123",
                    principalPin = "1234",
                    isPinEnabled = false,
                    isBiometricEnabled = false
                )
            )

            // 2. Initial Teachers
            val t1Id = dao.insertTeacher(
                Teacher(
                    id = 1,
                    name = "Robert Smith",
                    email = "robert.smith@school.edu",
                    phone = "+1 (555) 234-5678",
                    subject = "Mathematics",
                    employeeId = "EMP-101",
                    qualification = "M.Sc Mathematics, B.Ed",
                    joinDate = "2021-06-15",
                    address = "45 Maplewood Avenue, North District",
                    photoAvatar = "avatar_teacher_1",
                    assignedSubjects = "Algebra, Trigonometry, Calculus",
                    username = "robert.smith",
                    passwordHash = "teacher123",
                    isActive = true
                )
            )
            val t2Id = dao.insertTeacher(
                Teacher(
                    id = 2,
                    name = "Sarah Jenkins",
                    email = "sarah.jenkins@school.edu",
                    phone = "+1 (555) 345-6789",
                    subject = "Science & Physics",
                    employeeId = "EMP-102",
                    qualification = "M.Sc Applied Physics",
                    joinDate = "2022-01-10",
                    address = "78 Oakridge Blvd, Westside",
                    photoAvatar = "avatar_teacher_2",
                    assignedSubjects = "General Science, Physics, Chemistry",
                    username = "sarah.jenkins",
                    passwordHash = "teacher123",
                    isActive = true
                )
            )
            val t3Id = dao.insertTeacher(
                Teacher(
                    id = 3,
                    name = "David Wilson",
                    email = "david.wilson@school.edu",
                    phone = "+1 (555) 456-7890",
                    subject = "English Literature",
                    employeeId = "EMP-103",
                    qualification = "M.A. English Literature, B.Ed",
                    joinDate = "2020-08-20",
                    address = "12 Greenfield Lane, South City",
                    photoAvatar = "avatar_teacher_3",
                    assignedSubjects = "English Grammar, World Literature",
                    username = "david.wilson",
                    passwordHash = "teacher123",
                    isActive = true
                )
            )
            val t4Id = dao.insertTeacher(
                Teacher(
                    id = 4,
                    name = "Elena Rostova",
                    email = "elena.rostova@school.edu",
                    phone = "+1 (555) 567-8901",
                    subject = "Social Studies",
                    employeeId = "EMP-104",
                    qualification = "M.A. World History & Civics",
                    joinDate = "2023-04-12",
                    address = "90 Pine Valley Drive",
                    photoAvatar = "avatar_teacher_4",
                    assignedSubjects = "History, Geography, Civics",
                    username = "elena.rostova",
                    passwordHash = "teacher123",
                    isActive = true
                )
            )

            // 3. Initial Classes
            val c1Id = dao.insertClass(
                SchoolClass(
                    id = 1,
                    name = "Grade 10",
                    section = "A",
                    roomNumber = "Room 301",
                    teacherId = t1Id
                )
            )
            val c2Id = dao.insertClass(
                SchoolClass(
                    id = 2,
                    name = "Grade 9",
                    section = "B",
                    roomNumber = "Room 204",
                    teacherId = t2Id
                )
            )
            val c3Id = dao.insertClass(
                SchoolClass(
                    id = 3,
                    name = "Grade 8",
                    section = "A",
                    roomNumber = "Room 105",
                    teacherId = t3Id
                )
            )

            // 4. Initial Students for Grade 10-A
            val s1 = dao.insertStudent(
                Student(
                    id = 1,
                    name = "Alexander Hayes",
                    rollNumber = "101",
                    classId = c1Id,
                    parentContact = "+1 (555) 010-1001",
                    gender = "Male",
                    parentName = "Michael Hayes",
                    parentEmail = "m.hayes@parentmail.com",
                    guardianRelation = "Father",
                    address = "231 Birch Street, City Center",
                    emergencyContact = "+1 (555) 010-1002",
                    bloodGroup = "O+",
                    dateOfBirth = "2010-03-14",
                    admissionDate = "2022-04-01",
                    photoAvatar = "avatar_student_1"
                )
            )
            val s2 = dao.insertStudent(
                Student(
                    id = 2,
                    name = "Sophia Martinez",
                    rollNumber = "102",
                    classId = c1Id,
                    parentContact = "+1 (555) 010-1002",
                    gender = "Female",
                    parentName = "Carlos & Maria Martinez",
                    parentEmail = "carlos.m@parentmail.com",
                    guardianRelation = "Parents",
                    address = "56 Meadow Creek Road",
                    emergencyContact = "+1 (555) 010-1003",
                    bloodGroup = "A+",
                    dateOfBirth = "2010-07-22",
                    admissionDate = "2022-04-01",
                    photoAvatar = "avatar_student_2"
                )
            )
            val s3 = dao.insertStudent(
                Student(
                    id = 3,
                    name = "Liam Johnson",
                    rollNumber = "103",
                    classId = c1Id,
                    parentContact = "+1 (555) 010-1003",
                    gender = "Male",
                    parentName = "Gregory Johnson",
                    parentEmail = "greg.johnson@parentmail.com",
                    guardianRelation = "Father",
                    address = "89 Sunset Boulevard, Apt 4B",
                    emergencyContact = "+1 (555) 010-1004",
                    bloodGroup = "B+",
                    dateOfBirth = "2010-11-05",
                    admissionDate = "2022-04-01",
                    photoAvatar = "avatar_student_3"
                )
            )
            val s4 = dao.insertStudent(
                Student(
                    id = 4,
                    name = "Emma Watson",
                    rollNumber = "104",
                    classId = c1Id,
                    parentContact = "+1 (555) 010-1004",
                    gender = "Female",
                    parentName = "Claire Watson",
                    parentEmail = "claire.watson@parentmail.com",
                    guardianRelation = "Mother",
                    address = "14 Highland Terrace",
                    emergencyContact = "+1 (555) 010-1005",
                    bloodGroup = "AB+",
                    dateOfBirth = "2010-09-18",
                    admissionDate = "2022-04-01",
                    photoAvatar = "avatar_student_4"
                )
            )
            val s5 = dao.insertStudent(
                Student(
                    id = 5,
                    name = "Lucas Garcia",
                    rollNumber = "105",
                    classId = c1Id,
                    parentContact = "+1 (555) 010-1005",
                    gender = "Male",
                    parentName = "Diego Garcia",
                    parentEmail = "diego.g@parentmail.com",
                    guardianRelation = "Father",
                    address = "302 Riverview Way",
                    emergencyContact = "+1 (555) 010-1006",
                    bloodGroup = "O-",
                    dateOfBirth = "2010-01-30",
                    admissionDate = "2022-04-01",
                    photoAvatar = "avatar_student_5"
                )
            )
            val s6 = dao.insertStudent(
                Student(
                    id = 6,
                    name = "Olivia Brown",
                    rollNumber = "106",
                    classId = c1Id,
                    parentContact = "+1 (555) 010-1006",
                    gender = "Female",
                    parentName = "Howard Brown",
                    parentEmail = "h.brown@parentmail.com",
                    guardianRelation = "Father",
                    address = "67 Willow Creek Lane",
                    emergencyContact = "+1 (555) 010-1007",
                    bloodGroup = "A-",
                    dateOfBirth = "2010-04-12",
                    admissionDate = "2022-04-01",
                    photoAvatar = "avatar_student_6"
                )
            )

            // Students for Grade 9-B
            dao.insertStudent(Student(id = 7, name = "Ethan Davis", rollNumber = "201", classId = c2Id, parentContact = "+1 (555) 020-2001", gender = "Male", parentName = "Samuel Davis", bloodGroup = "B+"))
            dao.insertStudent(Student(id = 8, name = "Mia Taylor", rollNumber = "202", classId = c2Id, parentContact = "+1 (555) 020-2002", gender = "Female", parentName = "Rachel Taylor", bloodGroup = "O+"))
            dao.insertStudent(Student(id = 9, name = "Noah Anderson", rollNumber = "203", classId = c2Id, parentContact = "+1 (555) 020-2003", gender = "Male", parentName = "Paul Anderson", bloodGroup = "A+"))
            dao.insertStudent(Student(id = 10, name = "Ava Thomas", rollNumber = "204", classId = c2Id, parentContact = "+1 (555) 020-2004", gender = "Female", parentName = "Karen Thomas", bloodGroup = "AB-"))

            // Students for Grade 8-A
            dao.insertStudent(Student(id = 11, name = "Mason Jackson", rollNumber = "301", classId = c3Id, parentContact = "+1 (555) 030-3001", gender = "Male", parentName = "Benjamin Jackson", bloodGroup = "O+"))
            dao.insertStudent(Student(id = 12, name = "Isabella White", rollNumber = "302", classId = c3Id, parentContact = "+1 (555) 030-3002", gender = "Female", parentName = "Laura White", bloodGroup = "A+"))
            dao.insertStudent(Student(id = 13, name = "James Harris", rollNumber = "303", classId = c3Id, parentContact = "+1 (555) 030-3003", gender = "Male", parentName = "Peter Harris", bloodGroup = "B-"))

            // 5. Initial Attendance Records (Today & Previous Dates for meaningful reports)
            val recId = dao.insertAttendanceRecord(
                AttendanceRecord(
                    id = 1,
                    classId = c1Id,
                    date = todayDate,
                    teacherId = t1Id,
                    isSubmitted = true,
                    submittedAt = System.currentTimeMillis() - 3600000,
                    notes = "Morning attendance completed. 2 absent students notified."
                )
            )
            dao.insertAttendanceItems(
                listOf(
                    AttendanceItem(attendanceRecordId = recId, studentId = s1, isPresent = true),
                    AttendanceItem(attendanceRecordId = recId, studentId = s2, isPresent = true),
                    AttendanceItem(attendanceRecordId = recId, studentId = s3, isPresent = false, absentReason = "Medical appointment (informed)"),
                    AttendanceItem(attendanceRecordId = recId, studentId = s4, isPresent = true),
                    AttendanceItem(attendanceRecordId = recId, studentId = s5, isPresent = false, absentReason = "Mild fever"),
                    AttendanceItem(attendanceRecordId = recId, studentId = s6, isPresent = true)
                )
            )

            // Past Attendance Records for History & Reports
            val pastDates = listOf("2026-08-21", "2026-08-20", "2026-08-19", "2026-08-18")
            pastDates.forEachIndexed { index, dateStr ->
                val pRec = dao.insertAttendanceRecord(
                    AttendanceRecord(
                        classId = c1Id,
                        date = dateStr,
                        teacherId = t1Id,
                        isSubmitted = true,
                        submittedAt = System.currentTimeMillis() - (index + 1) * 86400000L,
                        notes = "Completed on time."
                    )
                )
                dao.insertAttendanceItems(
                    listOf(
                        AttendanceItem(attendanceRecordId = pRec, studentId = s1, isPresent = true),
                        AttendanceItem(attendanceRecordId = pRec, studentId = s2, isPresent = true),
                        AttendanceItem(attendanceRecordId = pRec, studentId = s3, isPresent = (index % 2 == 0)),
                        AttendanceItem(attendanceRecordId = pRec, studentId = s4, isPresent = true),
                        AttendanceItem(attendanceRecordId = pRec, studentId = s5, isPresent = true),
                        AttendanceItem(attendanceRecordId = pRec, studentId = s6, isPresent = (index != 1))
                    )
                )
            }

            // 6. Initial Teacher Attendance
            dao.insertTeacherAttendance(TeacherAttendanceRecord(teacherId = t1Id, date = todayDate, status = "PRESENT", notes = "On-time arrival"))
            dao.insertTeacherAttendance(TeacherAttendanceRecord(teacherId = t2Id, date = todayDate, status = "PRESENT", notes = "On-time arrival"))
            dao.insertTeacherAttendance(TeacherAttendanceRecord(teacherId = t3Id, date = todayDate, status = "PRESENT", notes = "On-time arrival"))
            dao.insertTeacherAttendance(TeacherAttendanceRecord(teacherId = t4Id, date = todayDate, status = "ON_LEAVE", notes = "Approved Casual Leave"))

            // 7. Initial Timetable Entries for Grade 10-A
            val days = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday")
            days.forEach { day ->
                dao.insertTimetableEntry(TimetableEntry(classId = c1Id, dayOfWeek = day, periodNumber = 1, startTime = "08:30 AM", endTime = "09:15 AM", subject = "Mathematics", teacherId = t1Id, roomNumber = "301"))
                dao.insertTimetableEntry(TimetableEntry(classId = c1Id, dayOfWeek = day, periodNumber = 2, startTime = "09:20 AM", endTime = "10:05 AM", subject = "Physics", teacherId = t2Id, roomNumber = "Lab 1"))
                dao.insertTimetableEntry(TimetableEntry(classId = c1Id, dayOfWeek = day, periodNumber = 3, startTime = "10:15 AM", endTime = "11:00 AM", subject = "English", teacherId = t3Id, roomNumber = "301"))
                dao.insertTimetableEntry(TimetableEntry(classId = c1Id, dayOfWeek = day, periodNumber = 4, startTime = "11:05 AM", endTime = "11:50 AM", subject = "Social Studies", teacherId = t4Id, roomNumber = "301"))
                dao.insertTimetableEntry(TimetableEntry(classId = c1Id, dayOfWeek = day, periodNumber = 5, startTime = "12:30 PM", endTime = "01:15 PM", subject = "Computer Science", teacherId = t1Id, roomNumber = "IT Lab"))
                dao.insertTimetableEntry(TimetableEntry(classId = c1Id, dayOfWeek = day, periodNumber = 6, startTime = "01:20 PM", endTime = "02:05 PM", subject = "Physical Education", teacherId = t3Id, roomNumber = "Ground"))
            }

            // Timetable for Grade 9-B
            days.forEach { day ->
                dao.insertTimetableEntry(TimetableEntry(classId = c2Id, dayOfWeek = day, periodNumber = 1, startTime = "08:30 AM", endTime = "09:15 AM", subject = "General Science", teacherId = t2Id, roomNumber = "204"))
                dao.insertTimetableEntry(TimetableEntry(classId = c2Id, dayOfWeek = day, periodNumber = 2, startTime = "09:20 AM", endTime = "10:05 AM", subject = "Mathematics", teacherId = t1Id, roomNumber = "204"))
                dao.insertTimetableEntry(TimetableEntry(classId = c2Id, dayOfWeek = day, periodNumber = 3, startTime = "10:15 AM", endTime = "11:00 AM", subject = "Social Studies", teacherId = t4Id, roomNumber = "204"))
                dao.insertTimetableEntry(TimetableEntry(classId = c2Id, dayOfWeek = day, periodNumber = 4, startTime = "11:05 AM", endTime = "11:50 AM", subject = "English", teacherId = t3Id, roomNumber = "204"))
            }

            // 8. Initial Exam Schedules
            dao.insertExamSchedule(ExamSchedule(examName = "Mid-Term Examination 2026", classId = c1Id, subject = "Mathematics", examDate = "2026-09-15", startTime = "09:00 AM", endTime = "12:00 PM", roomNumber = "Hall A", maxMarks = 100, instructions = "Calculators are permitted for Section B."))
            dao.insertExamSchedule(ExamSchedule(examName = "Mid-Term Examination 2026", classId = c1Id, subject = "Physics", examDate = "2026-09-17", startTime = "09:00 AM", endTime = "12:00 PM", roomNumber = "Hall A", maxMarks = 100, instructions = "Bring geometry box and formula sheet."))
            dao.insertExamSchedule(ExamSchedule(examName = "Mid-Term Examination 2026", classId = c1Id, subject = "English Literature", examDate = "2026-09-20", startTime = "09:00 AM", endTime = "12:00 PM", roomNumber = "Hall A", maxMarks = 100, instructions = "Essay writing Section C is mandatory."))
            dao.insertExamSchedule(ExamSchedule(examName = "Mid-Term Examination 2026", classId = c1Id, subject = "Social Studies", examDate = "2026-09-22", startTime = "09:00 AM", endTime = "12:00 PM", roomNumber = "Hall A", maxMarks = 100, instructions = "World map attachment provided."))

            // 9. Initial School Events & Holidays Calendar
            dao.insertSchoolEvent(SchoolEvent(title = "Labor Day Holiday", description = "School closed for national public holiday", date = "2026-09-07", eventType = "HOLIDAY", isHoliday = true))
            dao.insertSchoolEvent(SchoolEvent(title = "Annual Science Exhibition", description = "Student project displays in the main auditorium. Parents welcome at 10 AM.", date = "2026-09-10", eventType = "EVENT", isHoliday = false))
            dao.insertSchoolEvent(SchoolEvent(title = "Mid-Term Exams Begin", description = "Term assessments for all grades 6 through 12.", date = "2026-09-15", eventType = "EXAM", isHoliday = false))
            dao.insertSchoolEvent(SchoolEvent(title = "Parent-Teacher Meeting (PTM)", description = "Discussion of mid-term progress and report card distribution.", date = "2026-09-28", eventType = "MEETING", isHoliday = false))
            dao.insertSchoolEvent(SchoolEvent(title = "Autumn Break", description = "Mid-semester break for students and faculty.", date = "2026-10-12", endDate = "2026-10-16", eventType = "HOLIDAY", isHoliday = true))
            dao.insertSchoolEvent(SchoolEvent(title = "Annual Sports Meet", description = "Track & field competitions, relay races, and awards ceremony.", date = "2026-11-05", eventType = "EVENT", isHoliday = false))

            // 10. Initial Homework
            dao.insertHomework(
                Homework(
                    id = 1,
                    classId = c1Id,
                    teacherId = t1Id,
                    subject = "Mathematics",
                    title = "Quadratic Equations Problem Set 4.2",
                    description = "Solve exercises 1 through 15 on page 142 of textbook. Show all working steps.",
                    dueDate = "Tomorrow"
                )
            )
            dao.insertHomework(
                Homework(
                    id = 2,
                    classId = c1Id,
                    teacherId = t1Id,
                    subject = "Mathematics",
                    title = "Trigonometry Basics Worksheet",
                    description = "Complete sine/cosine ratio table and word problem proofs.",
                    dueDate = "Friday"
                )
            )
            dao.insertHomework(
                Homework(
                    id = 3,
                    classId = c1Id,
                    teacherId = t2Id,
                    subject = "Physics",
                    title = "Newton's Laws of Motion Lab Report",
                    description = "Write formal conclusion on acceleration vs force experiment data.",
                    dueDate = "Next Monday"
                )
            )

            // 11. Initial Marks for Assessments (Unit Test 1 & Midterm)
            val subjects = listOf("Mathematics", "Physics", "English", "Social Studies")
            val scoresList = mapOf(
                s1 to listOf(94, 90, 86, 92),
                s2 to listOf(88, 92, 95, 89),
                s3 to listOf(76, 70, 80, 75),
                s4 to listOf(98, 96, 94, 95),
                s5 to listOf(68, 72, 70, 74),
                s6 to listOf(85, 88, 90, 82)
            )

            scoresList.forEach { (studentId, scores) ->
                subjects.forEachIndexed { idx, subj ->
                    val mark = scores[idx]
                    dao.insertMark(
                        StudentMark(
                            classId = c1Id,
                            studentId = studentId,
                            subject = subj,
                            assessmentName = "Unit Test 1",
                            maxMarks = 100,
                            obtainedMarks = mark,
                            remarks = if (mark >= 90) "Outstanding conceptual clarity" else if (mark >= 75) "Good effort, maintain consistency" else "Needs additional revision",
                            date = todayDate
                        )
                    )
                }
            }

            // 12. Announcements (including targeted class announcements)
            dao.insertAnnouncement(
                Announcement(
                    id = 1,
                    title = "Annual Science Exhibition Next Week",
                    content = "All class teachers must guide their students to finalize their project models by this Thursday. Parents are invited on Friday at 10 AM.",
                    authorName = "Principal Office",
                    targetAudience = "ALL",
                    category = "EVENT",
                    isImportant = true
                )
            )
            dao.insertAnnouncement(
                Announcement(
                    id = 2,
                    title = "Faculty Meeting on Friday at 3:30 PM",
                    content = "Staff meeting in Conference Hall B to review mid-term syllabus progress and upcoming sports day schedule.",
                    authorName = "Principal Office",
                    targetAudience = "TEACHERS",
                    category = "CIRCULAR",
                    isImportant = false
                )
            )
            dao.insertAnnouncement(
                Announcement(
                    id = 3,
                    title = "Grade 10 Mathematics Revision Camp",
                    content = "Special remedial and problem-solving sessions will be held after school from 3:15 PM to 4:30 PM for all Grade 10 students.",
                    authorName = "Robert Smith (Math Dept)",
                    targetAudience = "CLASS_SPECIFIC",
                    targetClassId = c1Id,
                    targetClassName = "Grade 10 - A",
                    category = "CIRCULAR",
                    isImportant = true
                )
            )

            // 13. Initial Leave Applications
            dao.insertLeave(
                LeaveApplication(
                    id = 1,
                    teacherId = t2Id,
                    leaveType = "Casual Leave",
                    startDate = "2026-08-28",
                    endDate = "2026-08-29",
                    reason = "Attending family wedding ceremony out of town.",
                    status = "PENDING",
                    principalRemark = ""
                )
            )
            dao.insertLeave(
                LeaveApplication(
                    id = 2,
                    teacherId = t3Id,
                    leaveType = "Sick Leave",
                    startDate = "2026-08-21",
                    endDate = "2026-08-21",
                    reason = "Dental surgery and recovery.",
                    status = "APPROVED",
                    principalRemark = "Approved. Substitute teacher arranged for Grade 8."
                )
            )
            dao.insertLeave(
                LeaveApplication(
                    id = 3,
                    teacherId = t4Id,
                    leaveType = "Personal Leave",
                    startDate = todayDate,
                    endDate = todayDate,
                    reason = "Urgent official documentation at municipal registry.",
                    status = "APPROVED",
                    principalRemark = "Approved for half day."
                )
            )
        }
    }
}
