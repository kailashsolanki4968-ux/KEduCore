package com.example.data.repository

import com.example.data.local.dao.SchoolDao
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SchoolRepository(private val dao: SchoolDao) {

    // --- Teachers ---
    val allTeachers: Flow<List<Teacher>> = dao.getAllTeachers()

    suspend fun getTeacherById(id: Long): Teacher? = dao.getTeacherById(id)

    suspend fun getTeacherByUsernameOrEmail(identifier: String): Teacher? = withContext(Dispatchers.IO) {
        dao.getTeacherByUsernameOrEmail(identifier)
    }

    suspend fun saveTeacher(teacher: Teacher): Long = withContext(Dispatchers.IO) {
        if (teacher.id == 0L) {
            dao.insertTeacher(teacher)
        } else {
            dao.updateTeacher(teacher)
            teacher.id
        }
    }

    suspend fun updateTeacherPassword(teacherId: Long, newPasswordHash: String) = withContext(Dispatchers.IO) {
        dao.updateTeacherPassword(teacherId, newPasswordHash)
    }

    suspend fun updateTeacherStatus(teacherId: Long, isActive: Boolean) = withContext(Dispatchers.IO) {
        dao.updateTeacherStatus(teacherId, isActive)
    }

    suspend fun updateTeacherLastLogin(teacherId: Long) = withContext(Dispatchers.IO) {
        dao.updateTeacherLastLogin(teacherId, System.currentTimeMillis())
    }

    suspend fun assignTeacherToClass(teacherId: Long, classId: Long?) = withContext(Dispatchers.IO) {
        dao.unassignTeacherFromAllClasses(teacherId)
        if (classId != null && classId != 0L) {
            dao.assignTeacherToClass(classId, teacherId)
        }
    }

    suspend fun deleteTeacher(teacher: Teacher) = withContext(Dispatchers.IO) {
        dao.unassignTeacherFromAllClasses(teacher.id)
        dao.deleteTeacher(teacher)
    }

    // --- Classes ---
    val allClasses: Flow<List<SchoolClass>> = dao.getAllClasses()

    fun getClassForTeacher(teacherId: Long): Flow<SchoolClass?> = dao.getClassForTeacher(teacherId)

    suspend fun getClassById(id: Long): SchoolClass? = dao.getClassById(id)

    suspend fun saveClass(schoolClass: SchoolClass): Long = withContext(Dispatchers.IO) {
        if (schoolClass.id == 0L) {
            dao.insertClass(schoolClass)
        } else {
            dao.updateClass(schoolClass)
            schoolClass.id
        }
    }

    suspend fun deleteClass(schoolClass: SchoolClass) = withContext(Dispatchers.IO) {
        dao.deleteClass(schoolClass)
    }

    // --- Students ---
    val allStudents: Flow<List<Student>> = dao.getAllStudents()

    fun getStudentsByClass(classId: Long): Flow<List<Student>> = dao.getStudentsByClass(classId)

    suspend fun getStudentById(id: Long): Student? = dao.getStudentById(id)

    suspend fun saveStudent(student: Student): Long = withContext(Dispatchers.IO) {
        if (student.id == 0L) {
            dao.insertStudent(student)
        } else {
            dao.updateStudent(student)
            student.id
        }
    }

    suspend fun deleteStudent(student: Student) = withContext(Dispatchers.IO) {
        dao.deleteStudent(student)
    }

    suspend fun updateStudentStatus(studentId: Long, isActive: Boolean) = withContext(Dispatchers.IO) {
        dao.updateStudentStatus(studentId, isActive)
    }

    // --- Attendance ---
    val allAttendanceRecords: Flow<List<AttendanceRecord>> = dao.getAllAttendanceRecords()

    fun getAttendanceRecord(classId: Long, date: String): Flow<AttendanceRecord?> =
        dao.getAttendanceRecord(classId, date)

    fun getAttendanceItems(recordId: Long): Flow<List<AttendanceItem>> =
        dao.getAttendanceItems(recordId)

    suspend fun saveAndSubmitAttendance(
        classId: Long,
        teacherId: Long,
        date: String,
        isSubmitted: Boolean,
        notes: String,
        studentStatuses: List<Pair<Student, Pair<Boolean, String>>> // Student -> (isPresent, absentReason)
    ) = withContext(Dispatchers.IO) {
        val existingRecord = dao.getAttendanceRecordSync(classId, date)
        val recordId: Long
        if (existingRecord == null) {
            val newRecord = AttendanceRecord(
                classId = classId,
                date = date,
                teacherId = teacherId,
                isSubmitted = isSubmitted,
                submittedAt = if (isSubmitted) System.currentTimeMillis() else null,
                notes = notes
            )
            recordId = dao.insertAttendanceRecord(newRecord)
        } else {
            val updatedRecord = existingRecord.copy(
                teacherId = teacherId,
                isSubmitted = isSubmitted,
                submittedAt = if (isSubmitted) (existingRecord.submittedAt ?: System.currentTimeMillis()) else existingRecord.submittedAt,
                notes = notes
            )
            dao.updateAttendanceRecord(updatedRecord)
            recordId = existingRecord.id
        }

        // Delete old items and insert fresh ones
        dao.deleteAttendanceItemsForRecord(recordId)
        val items = studentStatuses.map { (student, status) ->
            AttendanceItem(
                attendanceRecordId = recordId,
                studentId = student.id,
                isPresent = status.first,
                absentReason = if (!status.first) status.second else ""
            )
        }
        dao.insertAttendanceItems(items)
    }

    // Comprehensive attendance summary for all classes on a date (used by Principal)
    fun getAllClassesAttendanceSummary(date: String): Flow<List<ClassAttendanceSummary>> {
        return combine(
            dao.getAllClasses(),
            dao.getAllTeachers(),
            dao.getAllStudents(),
            dao.getAttendanceRecordsByDate(date)
        ) { classes, teachers, students, records ->
            classes.map { schoolClass ->
                val teacher = teachers.find { it.id == schoolClass.teacherId }
                val teacherName = teacher?.name ?: "Not Assigned"
                val classStudents = students.filter { it.classId == schoolClass.id }
                val record = records.find { it.classId == schoolClass.id }

                if (record == null) {
                    ClassAttendanceSummary(
                        classItem = schoolClass,
                        teacherName = teacherName,
                        totalStudents = classStudents.size,
                        presentCount = 0,
                        absentCount = 0,
                        absentStudentsWithNotes = emptyList(),
                        date = date,
                        isSubmitted = false,
                        submittedAt = null
                    )
                } else {
                    val items = dao.getAttendanceItemsSync(record.id)
                    val absentList = mutableListOf<AbsentStudentDetail>()
                    var presentCount = 0
                    var absentCount = 0

                    classStudents.forEach { student ->
                        val item = items.find { it.studentId == student.id }
                        if (item == null || item.isPresent) {
                            if (item?.isPresent == false) {
                                absentCount++
                                absentList.add(
                                    AbsentStudentDetail(
                                        studentId = student.id,
                                        studentName = student.name,
                                        rollNumber = student.rollNumber,
                                        parentContact = student.parentContact,
                                        reason = item.absentReason
                                    )
                                )
                            } else {
                                presentCount++
                            }
                        } else {
                            absentCount++
                            absentList.add(
                                AbsentStudentDetail(
                                    studentId = student.id,
                                    studentName = student.name,
                                    rollNumber = student.rollNumber,
                                    parentContact = student.parentContact,
                                    reason = item.absentReason
                                )
                            )
                        }
                    }

                    ClassAttendanceSummary(
                        classItem = schoolClass,
                        teacherName = teacherName,
                        totalStudents = classStudents.size,
                        presentCount = presentCount,
                        absentCount = absentCount,
                        absentStudentsWithNotes = absentList,
                        date = date,
                        isSubmitted = record.isSubmitted,
                        submittedAt = record.submittedAt
                    )
                }
            }
        }
    }

    // Student-wise attendance stats calculation
    suspend fun getStudentAttendanceStats(studentId: Long): StudentAttendanceStats = withContext(Dispatchers.IO) {
        val student = dao.getStudentById(studentId)
        val defaultStudent = student ?: Student(id = studentId, name = "Student #$studentId", rollNumber = "", classId = 0)
        val schoolClass = student?.let { dao.getClassById(it.classId) }
        val className = schoolClass?.displayName ?: "Unassigned"

        val allRecords = dao.getAllAttendanceRecordsSync().filter { it.classId == student?.classId }
        val items = dao.getAttendanceItemsForStudent(studentId)

        var presentCount = 0
        var absentCount = 0
        val historyList = mutableListOf<StudentDailyAttendanceRecord>()

        allRecords.forEach { record ->
            val item = items.find { it.attendanceRecordId == record.id }
            if (item != null) {
                if (item.isPresent) {
                    presentCount++
                } else {
                    absentCount++
                }
                historyList.add(
                    StudentDailyAttendanceRecord(
                        date = record.date,
                        isPresent = item.isPresent,
                        absentReason = item.absentReason
                    )
                )
            }
        }

        val totalDays = presentCount + absentCount
        val percentage = if (totalDays > 0) (presentCount.toFloat() / totalDays.toFloat()) * 100f else 100f

        StudentAttendanceStats(
            student = defaultStudent,
            className = className,
            totalRecordedDays = totalDays,
            presentDays = presentCount,
            absentDays = absentCount,
            attendancePercentage = percentage,
            recentRecords = historyList.sortedByDescending { it.date }
        )
    }

    // --- Teacher Attendance ---
    fun getTeacherAttendanceByDate(date: String): Flow<List<TeacherAttendanceRecord>> =
        dao.getTeacherAttendanceByDate(date)

    fun getTeacherAttendanceHistory(teacherId: Long): Flow<List<TeacherAttendanceRecord>> =
        dao.getTeacherAttendanceHistory(teacherId)

    suspend fun saveTeacherAttendance(record: TeacherAttendanceRecord) = withContext(Dispatchers.IO) {
        dao.insertTeacherAttendance(record)
    }

    // --- Homework ---
    val allHomework: Flow<List<Homework>> = dao.getAllHomework()
    fun getHomeworkByClass(classId: Long): Flow<List<Homework>> = dao.getHomeworkByClass(classId)

    suspend fun saveHomework(homework: Homework): Long = withContext(Dispatchers.IO) {
        dao.insertHomework(homework)
    }

    suspend fun deleteHomework(homework: Homework) = withContext(Dispatchers.IO) {
        dao.deleteHomework(homework)
    }

    // --- Student Marks ---
    val allMarks: Flow<List<StudentMark>> = dao.getAllMarks()
    fun getMarksByClass(classId: Long): Flow<List<StudentMark>> = dao.getMarksByClass(classId)
    fun getMarksForStudent(studentId: Long): Flow<List<StudentMark>> = dao.getMarksForStudent(studentId)

    suspend fun saveMark(mark: StudentMark): Long = withContext(Dispatchers.IO) {
        dao.insertMark(mark)
    }

    suspend fun saveMarks(marks: List<StudentMark>) = withContext(Dispatchers.IO) {
        dao.insertMarks(marks)
    }

    suspend fun deleteMark(mark: StudentMark) = withContext(Dispatchers.IO) {
        dao.deleteMark(mark)
    }

    // --- Announcements ---
    val allAnnouncements: Flow<List<Announcement>> = dao.getAllAnnouncements()

    suspend fun saveAnnouncement(announcement: Announcement): Long = withContext(Dispatchers.IO) {
        dao.insertAnnouncement(announcement)
    }

    suspend fun deleteAnnouncement(announcement: Announcement) = withContext(Dispatchers.IO) {
        dao.deleteAnnouncement(announcement)
    }

    // --- Leaves ---
    val allLeaves: Flow<List<LeaveApplication>> = dao.getAllLeaves()
    fun getLeavesForTeacher(teacherId: Long): Flow<List<LeaveApplication>> = dao.getLeavesForTeacher(teacherId)

    suspend fun applyLeave(leave: LeaveApplication): Long = withContext(Dispatchers.IO) {
        dao.insertLeave(leave)
    }

    suspend fun updateLeaveStatus(
        leaveId: Long,
        status: String,
        principalRemark: String
    ) = withContext(Dispatchers.IO) {
        val leaves = dao.getAllLeaves().first()
        val existing = leaves.find { it.id == leaveId }
        if (existing != null) {
            dao.updateLeave(
                existing.copy(
                    status = status,
                    principalRemark = principalRemark
                )
            )
        }
    }

    suspend fun deleteLeave(leave: LeaveApplication) = withContext(Dispatchers.IO) {
        dao.deleteLeave(leave)
    }

    // --- Timetables ---
    val allTimetables: Flow<List<TimetableEntry>> = dao.getAllTimetableEntries()
    fun getTimetableForClass(classId: Long): Flow<List<TimetableEntry>> = dao.getTimetableForClass(classId)
    fun getTimetableForTeacher(teacherId: Long): Flow<List<TimetableEntry>> = dao.getTimetableForTeacher(teacherId)

    suspend fun saveTimetableEntry(entry: TimetableEntry): Long = withContext(Dispatchers.IO) {
        dao.insertTimetableEntry(entry)
    }

    suspend fun deleteTimetableEntry(entry: TimetableEntry) = withContext(Dispatchers.IO) {
        dao.deleteTimetableEntry(entry)
    }

    // --- Exam Schedules ---
    val allExams: Flow<List<ExamSchedule>> = dao.getAllExamSchedules()
    fun getExamsByClass(classId: Long): Flow<List<ExamSchedule>> = dao.getExamSchedulesByClass(classId)

    suspend fun saveExamSchedule(exam: ExamSchedule): Long = withContext(Dispatchers.IO) {
        dao.insertExamSchedule(exam)
    }

    suspend fun deleteExamSchedule(exam: ExamSchedule) = withContext(Dispatchers.IO) {
        dao.deleteExamSchedule(exam)
    }

    // --- School Events & Holidays ---
    val allSchoolEvents: Flow<List<SchoolEvent>> = dao.getAllSchoolEvents()
    val allHolidays: Flow<List<SchoolEvent>> = dao.getAllHolidays()

    suspend fun saveSchoolEvent(event: SchoolEvent): Long = withContext(Dispatchers.IO) {
        dao.insertSchoolEvent(event)
    }

    suspend fun deleteSchoolEvent(event: SchoolEvent) = withContext(Dispatchers.IO) {
        dao.deleteSchoolEvent(event)
    }

    // --- School Settings ---
    val schoolSettings: Flow<SchoolSettingsEntity?> = dao.getSchoolSettings()

    suspend fun getSchoolSettingsSync(): SchoolSettingsEntity {
        return withContext(Dispatchers.IO) {
            dao.getSchoolSettingsSync() ?: SchoolSettingsEntity()
        }
    }

    suspend fun updateSchoolSettings(settings: SchoolSettingsEntity) = withContext(Dispatchers.IO) {
        dao.insertOrUpdateSchoolSettings(settings)
    }

    // --- Absence Notification Logs ---
    val allAbsenceLogs: Flow<List<AbsenceNotificationLog>> = dao.getAllAbsenceLogs()

    suspend fun logAbsenceNotifications(logs: List<AbsenceNotificationLog>) = withContext(Dispatchers.IO) {
        dao.insertAbsenceLogs(logs)
    }

    // --- Backup & Restore JSON Serialization ---
    suspend fun exportDataAsJson(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        val today = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        root.put("exportDate", today)
        root.put("version", 2)

        // Settings
        val settings = dao.getSchoolSettingsSync() ?: SchoolSettingsEntity()
        val setObj = JSONObject().apply {
            put("schoolName", settings.schoolName)
            put("schoolAddress", settings.schoolAddress)
            put("schoolPhone", settings.schoolPhone)
            put("schoolEmail", settings.schoolEmail)
            put("academicSession", settings.academicSession)
            put("principalName", settings.principalName)
        }
        root.put("settings", setObj)

        // Teachers
        val teachersArr = JSONArray()
        dao.getAllTeachersSync().forEach { t ->
            val obj = JSONObject().apply {
                put("id", t.id)
                put("name", t.name)
                put("email", t.email)
                put("phone", t.phone)
                put("subject", t.subject)
                put("employeeId", t.employeeId)
                put("qualification", t.qualification)
            }
            teachersArr.put(obj)
        }
        root.put("teachers", teachersArr)

        // Classes
        val classesArr = JSONArray()
        dao.getAllClassesSync().forEach { c ->
            val obj = JSONObject().apply {
                put("id", c.id)
                put("name", c.name)
                put("section", c.section)
                put("roomNumber", c.roomNumber)
                put("teacherId", c.teacherId ?: -1)
            }
            classesArr.put(obj)
        }
        root.put("classes", classesArr)

        // Students
        val studentsArr = JSONArray()
        dao.getAllStudentsSync().forEach { s ->
            val obj = JSONObject().apply {
                put("id", s.id)
                put("name", s.name)
                put("rollNumber", s.rollNumber)
                put("classId", s.classId)
                put("parentContact", s.parentContact)
                put("parentName", s.parentName)
                put("gender", s.gender)
                put("bloodGroup", s.bloodGroup)
            }
            studentsArr.put(obj)
        }
        root.put("students", studentsArr)

        root.toString(2)
    }

    suspend fun importDataFromJson(jsonStr: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonStr)
            if (root.has("teachers")) {
                val arr = root.getJSONArray("teachers")
                val list = mutableListOf<Teacher>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    list.add(
                        Teacher(
                            id = obj.optLong("id", 0),
                            name = obj.optString("name", "Teacher"),
                            email = obj.optString("email", ""),
                            phone = obj.optString("phone", ""),
                            subject = obj.optString("subject", "General"),
                            employeeId = obj.optString("employeeId", "EMP-${i + 1}"),
                            qualification = obj.optString("qualification", "Degree")
                        )
                    )
                }
                if (list.isNotEmpty()) dao.insertTeachers(list)
            }

            if (root.has("classes")) {
                val arr = root.getJSONArray("classes")
                val list = mutableListOf<SchoolClass>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val tId = obj.optLong("teacherId", -1)
                    list.add(
                        SchoolClass(
                            id = obj.optLong("id", 0),
                            name = obj.optString("name", "Class"),
                            section = obj.optString("section", "A"),
                            roomNumber = obj.optString("roomNumber", "101"),
                            teacherId = if (tId > 0) tId else null
                        )
                    )
                }
                if (list.isNotEmpty()) dao.insertClasses(list)
            }

            if (root.has("students")) {
                val arr = root.getJSONArray("students")
                val list = mutableListOf<Student>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    list.add(
                        Student(
                            id = obj.optLong("id", 0),
                            name = obj.optString("name", "Student"),
                            rollNumber = obj.optString("rollNumber", "${i + 1}"),
                            classId = obj.optLong("classId", 1),
                            parentContact = obj.optString("parentContact", ""),
                            parentName = obj.optString("parentName", ""),
                            gender = obj.optString("gender", "Male"),
                            bloodGroup = obj.optString("bloodGroup", "O+")
                        )
                    )
                }
                if (list.isNotEmpty()) dao.insertStudents(list)
            }
            true
        } catch (_: Exception) {
            false
        }
    }
}
