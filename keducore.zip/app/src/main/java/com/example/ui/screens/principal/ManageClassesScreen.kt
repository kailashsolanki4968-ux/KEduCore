package com.example.ui.screens.principal

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SchoolClass
import com.example.data.model.Teacher
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel

@Composable
fun ManageClassesScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val classes by viewModel.classes.collectAsState()
    val teachers by viewModel.teachers.collectAsState()
    val students by viewModel.students.collectAsState()

    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingClass by remember { mutableStateOf<SchoolClass?>(null) }
    var classToDelete by remember { mutableStateOf<SchoolClass?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "All Classes (${classes.size})",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Assign teachers and organize students",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (classes.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.MeetingRoom,
                    title = "No Classes Created Yet",
                    description = "Create classes (e.g. Grade 10-A) and assign faculty to manage attendance.",
                    actionButton = {
                        Button(
                            onClick = {
                                editingClass = null
                                showAddEditDialog = true
                            },
                            modifier = Modifier.testTag("create_first_class_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Create Class")
                        }
                    }
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(classes, key = { it.id }) { schoolClass ->
                        val assignedTeacher = teachers.find { it.id == schoolClass.teacherId }
                        val studentCount = students.count { it.classId == schoolClass.id }

                        ClassManagementCard(
                            schoolClass = schoolClass,
                            assignedTeacher = assignedTeacher,
                            studentCount = studentCount,
                            allTeachers = teachers,
                            onAssignTeacher = { teacherId ->
                                viewModel.assignClassTeacher(schoolClass.id, teacherId)
                            },
                            onEdit = {
                                editingClass = schoolClass
                                showAddEditDialog = true
                            },
                            onDelete = {
                                classToDelete = schoolClass
                            }
                        )
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = {
                editingClass = null
                showAddEditDialog = true
            },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("add_class_fab")
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Class")
        }
    }

    if (showAddEditDialog) {
        AddEditClassDialog(
            schoolClass = editingClass,
            teachers = teachers,
            onDismiss = { showAddEditDialog = false },
            onSave = { updatedClass ->
                viewModel.saveClass(updatedClass)
                showAddEditDialog = false
            }
        )
    }

    if (classToDelete != null) {
        ConfirmDeleteDialog(
            title = "Delete Class?",
            message = "Are you sure you want to delete ${classToDelete?.displayName}? Students and records linked to this class will be affected.",
            onConfirm = {
                classToDelete?.let { viewModel.deleteClass(it) }
                classToDelete = null
            },
            onDismiss = { classToDelete = null }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClassManagementCard(
    schoolClass: SchoolClass,
    assignedTeacher: Teacher?,
    studentCount: Int,
    allTeachers: List<Teacher>,
    onAssignTeacher: (Long?) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isTeacherDropdownExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("class_card_${schoolClass.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Text(
                            text = schoolClass.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (schoolClass.roomNumber.isNotBlank()) {
                            Text(
                                text = schoolClass.roomNumber,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Row {
                    IconButton(onClick = onEdit, modifier = Modifier.testTag("edit_class_${schoolClass.id}")) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Class", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.testTag("delete_class_${schoolClass.id}")) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Class", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Info chips row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusBadge(
                    text = "$studentCount Enrolled Students",
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    icon = Icons.Default.People
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Class Teacher Assignment Dropdown
            Text(
                text = "Assigned Class Teacher",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))

            ExposedDropdownMenuBox(
                expanded = isTeacherDropdownExpanded,
                onExpandedChange = { isTeacherDropdownExpanded = !isTeacherDropdownExpanded },
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = assignedTeacher?.name ?: "— None (Unassigned) —",
                    onValueChange = {},
                    readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isTeacherDropdownExpanded) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = if (assignedTeacher != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        )
                    },
                    colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                        .testTag("class_teacher_dropdown_${schoolClass.id}")
                )

                ExposedDropdownMenu(
                    expanded = isTeacherDropdownExpanded,
                    onDismissRequest = { isTeacherDropdownExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("— None (Unassigned) —", color = MaterialTheme.colorScheme.error) },
                        onClick = {
                            onAssignTeacher(null)
                            isTeacherDropdownExpanded = false
                        }
                    )
                    allTeachers.forEach { teacher ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(teacher.name, fontWeight = FontWeight.SemiBold)
                                    Text(teacher.subject, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            },
                            onClick = {
                                onAssignTeacher(teacher.id)
                                isTeacherDropdownExpanded = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditClassDialog(
    schoolClass: SchoolClass?,
    teachers: List<Teacher>,
    onDismiss: () -> Unit,
    onSave: (SchoolClass) -> Unit
) {
    var name by remember { mutableStateOf(schoolClass?.name ?: "") }
    var section by remember { mutableStateOf(schoolClass?.section ?: "") }
    var roomNumber by remember { mutableStateOf(schoolClass?.roomNumber ?: "") }
    var selectedTeacherId by remember { mutableStateOf(schoolClass?.teacherId) }
    var nameError by remember { mutableStateOf(false) }
    var isTeacherDropdownExpanded by remember { mutableStateOf(false) }

    val selectedTeacher = teachers.find { it.id == selectedTeacherId }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (schoolClass == null) "Create New Class" else "Edit Class Details",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        nameError = it.isBlank()
                    },
                    label = { Text("Class / Grade Name *") },
                    placeholder = { Text("e.g. Grade 10, Class 8") },
                    isError = nameError,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_class_name_field")
                )

                OutlinedTextField(
                    value = section,
                    onValueChange = { section = it },
                    label = { Text("Section") },
                    placeholder = { Text("e.g. A, B, Blue") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_class_section_field")
                )

                OutlinedTextField(
                    value = roomNumber,
                    onValueChange = { roomNumber = it },
                    label = { Text("Room / Block") },
                    placeholder = { Text("e.g. Room 301, Block B") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Assign Class Teacher",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )

                ExposedDropdownMenuBox(
                    expanded = isTeacherDropdownExpanded,
                    onExpandedChange = { isTeacherDropdownExpanded = !isTeacherDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedTeacher?.name ?: "— None (Unassigned) —",
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isTeacherDropdownExpanded) },
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )

                    ExposedDropdownMenu(
                        expanded = isTeacherDropdownExpanded,
                        onDismissRequest = { isTeacherDropdownExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("— None (Unassigned) —") },
                            onClick = {
                                selectedTeacherId = null
                                isTeacherDropdownExpanded = false
                            }
                        )
                        teachers.forEach { teacher ->
                            DropdownMenuItem(
                                text = { Text("${teacher.name} (${teacher.subject})") },
                                onClick = {
                                    selectedTeacherId = teacher.id
                                    isTeacherDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        nameError = true
                    } else {
                        onSave(
                            SchoolClass(
                                id = schoolClass?.id ?: 0L,
                                name = name.trim(),
                                section = section.trim(),
                                roomNumber = roomNumber.trim(),
                                teacherId = selectedTeacherId
                            )
                        )
                    }
                },
                modifier = Modifier.testTag("dialog_class_save_button")
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
