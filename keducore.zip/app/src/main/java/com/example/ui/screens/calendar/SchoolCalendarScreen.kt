package com.example.ui.screens.calendar

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SchoolEvent
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel
import com.example.ui.viewmodel.UserRole
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SchoolCalendarScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentRole by viewModel.currentRole.collectAsState()
    val allEvents by viewModel.allEvents.collectAsState()

    var selectedFilter by remember { mutableStateOf("ALL") } // "ALL", "HOLIDAY", "EVENT", "EXAM", "MEETING"
    var showAddDialog by remember { mutableStateOf(false) }
    var editingEvent by remember { mutableStateOf<SchoolEvent?>(null) }

    val filteredEvents = remember(allEvents, selectedFilter) {
        allEvents.filter { event ->
            when (selectedFilter) {
                "ALL" -> true
                "HOLIDAY" -> event.isHoliday
                else -> event.eventType.equals(selectedFilter, ignoreCase = true)
            }
        }.sortedBy { it.date }
    }

    val holidaysCount = remember(allEvents) { allEvents.count { it.isHoliday } }
    val eventsCount = remember(allEvents) { allEvents.count { !it.isHoliday } }

    Scaffold(
        floatingActionButton = {
            if (currentRole == UserRole.PRINCIPAL) {
                FloatingActionButton(
                    onClick = {
                        editingEvent = null
                        showAddDialog = true
                    },
                    containerColor = PrimaryNavy,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("add_event_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Calendar Event")
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "School Calendar & Holidays",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "$holidaysCount Holidays • $eventsCount Scheduled Events",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                FilledTonalButton(
                    onClick = {
                        val content = buildString {
                            appendLine("=== ACADEMIC CALENDAR & HOLIDAYS ===")
                            appendLine("Generated: ${SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())}")
                            appendLine("----------------------------------------")
                            filteredEvents.forEach { ev ->
                                val endText = if (!ev.endDate.isNullOrBlank()) " to ${ev.endDate}" else ""
                                appendLine("${ev.date}$endText [${ev.eventType}]: ${ev.title}")
                                if (ev.description.isNotBlank()) appendLine("Details: ${ev.description}")
                                appendLine("----------------------------------------")
                            }
                        }
                        viewModel.shareTextReport(context, "School_Calendar", content)
                    },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("export_calendar_btn")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Export", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val filters = listOf(
                    "ALL" to "All Schedule",
                    "HOLIDAY" to "🏖️ Holidays",
                    "EVENT" to "🎉 School Events",
                    "EXAM" to "📝 Examinations",
                    "MEETING" to "👥 PTM & Meetings"
                )
                items(filters) { (key, label) ->
                    FilterChip(
                        selected = selectedFilter == key,
                        onClick = { selectedFilter = key },
                        label = { Text(label, fontSize = 12.sp) },
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (filteredEvents.isEmpty()) {
                EmptyStateView(
                    title = "No Calendar Events",
                    description = "Holidays, exam weeks, and school activities will appear here.",
                    icon = Icons.Default.CalendarToday
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredEvents) { event ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (event.isHoliday) AbsentRedContainer.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surface
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Date Box
                                Surface(
                                    color = if (event.isHoliday) AbsentRedContainer else MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.size(56.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.fillMaxSize(),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        val dayPart = event.date.split("-").lastOrNull() ?: "01"
                                        val monthPart = event.date.split("-").getOrNull(1) ?: "01"
                                        Text(
                                            text = dayPart,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp,
                                            color = if (event.isHoliday) AbsentRed else MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "M$monthPart",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (event.isHoliday) AbsentRed else MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = event.title,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(2.dp))

                                    if (event.description.isNotBlank()) {
                                        Text(
                                            text = event.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                    }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        StatusBadge(
                                            text = if (event.isHoliday) "Official Holiday" else event.eventType,
                                            containerColor = if (event.isHoliday) AbsentRedContainer else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                                            contentColor = if (event.isHoliday) AbsentRed else MaterialTheme.colorScheme.secondary
                                        )

                                        if (!event.endDate.isNullOrBlank()) {
                                            Text(
                                                text = "Through ${event.endDate}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }

                                if (currentRole == UserRole.PRINCIPAL) {
                                    IconButton(
                                        onClick = { viewModel.deleteSchoolEvent(event) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AbsentRed, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddEditEventDialog(
            event = editingEvent,
            onDismiss = { showAddDialog = false },
            onSave = { newEvent ->
                viewModel.saveSchoolEvent(newEvent) {
                    showAddDialog = false
                }
            }
        )
    }
}

@Composable
fun AddEditEventDialog(
    event: SchoolEvent?,
    onDismiss: () -> Unit,
    onSave: (SchoolEvent) -> Unit
) {
    var title by remember { mutableStateOf(event?.title ?: "") }
    var description by remember { mutableStateOf(event?.description ?: "") }
    var date by remember { mutableStateOf(event?.date ?: SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }
    var endDate by remember { mutableStateOf(event?.endDate ?: "") }
    var eventType by remember { mutableStateOf(event?.eventType ?: "EVENT") }
    var isHoliday by remember { mutableStateOf(event?.isHoliday ?: false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (event == null) "Add Calendar Event" else "Edit Event", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Event / Holiday Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description & Notes") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("Start Date (YYYY-MM-DD)") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = endDate,
                        onValueChange = { endDate = it },
                        label = { Text("End Date (Optional)") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Checkbox(
                        checked = isHoliday,
                        onCheckedChange = {
                            isHoliday = it
                            if (it) eventType = "HOLIDAY"
                        }
                    )
                    Text("Is Official Holiday (School Closed)", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }

                if (!isHoliday) {
                    Text("Event Type:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("EVENT", "EXAM", "MEETING").forEach { type ->
                            FilterChip(
                                selected = eventType == type,
                                onClick = { eventType = type },
                                label = { Text(type, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onSave(
                            SchoolEvent(
                                id = event?.id ?: 0L,
                                title = title.trim(),
                                description = description.trim(),
                                date = date.trim(),
                                endDate = if (endDate.isNotBlank()) endDate.trim() else null,
                                eventType = if (isHoliday) "HOLIDAY" else eventType,
                                isHoliday = isHoliday
                            )
                        )
                    }
                },
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Save to Calendar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
