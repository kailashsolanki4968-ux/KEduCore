package com.example.ui.components

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.AbsentStudentDetail
import com.example.data.model.ClassAttendanceSummary
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel

@Composable
fun ParentAbsenceAlertsDialog(
    dailySummaries: List<ClassAttendanceSummary>,
    viewModel: SchoolViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val selectedDate by viewModel.selectedDate.collectAsState()
    val absenceLogs by viewModel.absenceLogs.collectAsState()

    // Aggregate all absent students across submitted class attendance
    val allAbsentStudents = remember(dailySummaries) {
        val list = mutableListOf<Pair<String, AbsentStudentDetail>>()
        dailySummaries.forEach { summary ->
            summary.absentStudentsWithNotes.forEach { absent ->
                list.add(Pair(summary.classItem.displayName, absent))
            }
        }
        list
    }

    var customMessageTemplate by remember {
        mutableStateOf("Dear Parent, your child was marked ABSENT today from St. Jude Academy. Please verify and contact the school office if unplanned.")
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.85f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Parent Absence Alerts",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${allAbsentStudents.size} Absent Students on $selectedDate",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    // Alert Banner & Broadcast button
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = AbsentRedContainer.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = AbsentRed)
                                    Text("Automated Parent Notification", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Send instant SMS/app alerts to guardians of all absent students for this date with one tap.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        if (allAbsentStudents.isNotEmpty()) {
                                            dailySummaries.forEach { summary ->
                                                if (summary.absentStudentsWithNotes.isNotEmpty()) {
                                                    viewModel.sendAbsenceNotifications(
                                                        summary.absentStudentsWithNotes,
                                                        summary.classItem.displayName,
                                                        selectedDate
                                                    )
                                                }
                                            }
                                        }
                                    },
                                    enabled = allAbsentStudents.isNotEmpty(),
                                    colors = ButtonDefaults.buttonColors(containerColor = AbsentRed),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("broadcast_absence_alerts_btn")
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Broadcast to ${allAbsentStudents.size} Parents", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Absent Students List
                    item {
                        Text("Absent Students Today", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    if (allAbsentStudents.isEmpty()) {
                        item {
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = PresentGreenContainer.copy(alpha = 0.3f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PresentGreen)
                                    Text("All students are present or no absences recorded today!", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    } else {
                        items(allAbsentStudents) { (className, absent) ->
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(AbsentRedContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(absent.rollNumber, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AbsentRed)
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(absent.studentName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("$className • Parent: ${absent.parentContact.ifBlank { "No number" }}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        if (absent.reason.isNotBlank()) {
                                            Text("Reason: ${absent.reason}", fontSize = 11.sp, color = PendingAmber, fontWeight = FontWeight.Medium)
                                        }
                                    }

                                    if (absent.parentContact.isNotBlank()) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            FilledTonalIconButton(
                                                onClick = { viewModel.makePhoneCall(context, absent.parentContact) },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Default.Phone, contentDescription = "Call", modifier = Modifier.size(16.dp))
                                            }
                                            FilledTonalIconButton(
                                                onClick = {
                                                    val smsText = "Dear Parent, ${absent.studentName} was marked ABSENT on $selectedDate from $className.${if (absent.reason.isNotBlank()) " Reason noted: ${absent.reason}." else ""} St. Jude Academy."
                                                    viewModel.sendSms(context, absent.parentContact, smsText)
                                                },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Default.Chat, contentDescription = "SMS", modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Notification History
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Recent Absence Notification Logs (${absenceLogs.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    if (absenceLogs.isEmpty()) {
                        item {
                            Text("No previous notification logs.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        items(absenceLogs.take(5)) { log ->
                            Card(
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("${log.studentName} (${log.className})", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                        StatusBadge(text = log.status, containerColor = PresentGreenContainer, contentColor = PresentGreen)
                                    }
                                    Text(log.message, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Close")
                }
            }
        }
    }
}
