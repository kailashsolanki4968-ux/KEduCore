package com.example.ui.components

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.LeaveApplication
import com.example.data.model.SchoolClass
import com.example.data.model.Teacher
import com.example.data.model.TeacherAttendanceRecord
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel

@Composable
fun TeacherProfileDialog(
    teacher: Teacher,
    assignedClass: SchoolClass?,
    viewModel: SchoolViewModel,
    onDismiss: () -> Unit,
    onEdit: () -> Unit
) {
    val context = LocalContext.current
    val allLeaves by viewModel.allLeaves.collectAsState()
    val teacherLeaves = remember(allLeaves, teacher.id) {
        allLeaves.filter { it.teacherId == teacher.id }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Faculty Profile", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Row {
                        IconButton(onClick = onEdit) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.primary)
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    // Profile Header Card
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PrimaryNavy),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(teacher.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text(teacher.employeeId.ifBlank { "EMP-101" }, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Surface(
                                        color = SecondaryTeal,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = teacher.subject,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Assigned Class & Subjects
                    item {
                        Text("Academic Responsibilities", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Class Teacher Of:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(assignedClass?.displayName ?: "Not Assigned", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                                }
                                if (teacher.assignedSubjects.isNotBlank()) {
                                    Text("Teaching Subjects: ${teacher.assignedSubjects}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                }
                                if (teacher.qualification.isNotBlank()) {
                                    Text("Qualification: ${teacher.qualification}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    // Contact info
                    item {
                        Text("Contact Information", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column {
                                        Text("Phone Number", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(teacher.phone.ifBlank { "Not specified" }, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                    if (teacher.phone.isNotBlank()) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            FilledTonalIconButton(
                                                onClick = { viewModel.makePhoneCall(context, teacher.phone) },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(Icons.Default.Phone, contentDescription = "Call", modifier = Modifier.size(18.dp))
                                            }
                                            FilledTonalIconButton(
                                                onClick = { viewModel.sendSms(context, teacher.phone, "Hello ${teacher.name}, regarding school updates:") },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(Icons.Default.Chat, contentDescription = "SMS", modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }

                                if (teacher.email.isNotBlank()) {
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                                    Column {
                                        Text("Email Address", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(teacher.email, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }

                    // Leave Records
                    item {
                        Text("Leave History (${teacherLeaves.size} records)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        if (teacherLeaves.isEmpty()) {
                            Text("No leave applications on file.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            teacherLeaves.take(3).forEach { leave ->
                                Card(
                                    shape = RoundedCornerShape(8.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("${leave.leaveType} (${leave.startDate})", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                            Text(leave.reason, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        StatusBadge(
                                            text = leave.status,
                                            containerColor = if (leave.status == "APPROVED") PresentGreenContainer else if (leave.status == "REJECTED") AbsentRedContainer else PendingAmberContainer,
                                            contentColor = if (leave.status == "APPROVED") PresentGreen else if (leave.status == "REJECTED") AbsentRed else PendingAmber
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Account & Credentials Info
                    item {
                        Text("Account Credentials & Access", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Portal Username:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("@${teacher.username.ifBlank { teacher.email.substringBefore("@") }}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Account Status:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        text = if (teacher.isActive) "Active (Can Sign In)" else "Deactivated",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (teacher.isActive) PresentGreen else AbsentRed
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherAttendanceRegisterDialog(
    viewModel: SchoolViewModel,
    onDismiss: () -> Unit
) {
    val selectedDate by viewModel.selectedDate.collectAsState()
    val teachers by viewModel.teachers.collectAsState()
    val attendanceRecords by viewModel.teacherDailyAttendance.collectAsState()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.85f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                // Top Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Teacher Attendance Register", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Date: $selectedDate", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(teachers) { teacher ->
                        val record = attendanceRecords.find { it.teacherId == teacher.id }
                        val status = record?.status ?: "PRESENT"

                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(teacher.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text("${teacher.employeeId} • ${teacher.subject}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }

                                    StatusBadge(
                                        text = status,
                                        containerColor = when (status) {
                                            "PRESENT" -> PresentGreenContainer
                                            "ON_LEAVE" -> PendingAmberContainer
                                            else -> AbsentRedContainer
                                        },
                                        contentColor = when (status) {
                                            "PRESENT" -> PresentGreen
                                            "ON_LEAVE" -> PendingAmber
                                            else -> AbsentRed
                                        }
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // Status action chips
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf("PRESENT" to "Present", "ABSENT" to "Absent", "ON_LEAVE" to "On Leave").forEach { (st, label) ->
                                        FilterChip(
                                            selected = status == st,
                                            onClick = {
                                                viewModel.markTeacherAttendance(teacher.id, selectedDate, st)
                                            },
                                            label = { Text(label, fontSize = 11.sp) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Done")
                }
            }
        }
    }
}
