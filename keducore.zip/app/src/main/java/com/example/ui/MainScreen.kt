package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.SchoolClass
import com.example.data.model.Teacher
import com.example.ui.components.TeacherProfileDialog
import com.example.ui.screens.academics.AcademicResultsAndReportsScreen
import com.example.ui.screens.academics.ExamTimetableScreen
import com.example.ui.screens.academics.TimetableScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.calendar.SchoolCalendarScreen
import com.example.ui.screens.principal.*
import com.example.ui.screens.settings.SettingsAndSecurityScreen
import com.example.ui.screens.teacher.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthState
import com.example.ui.viewmodel.SchoolViewModel
import com.example.ui.viewmodel.UserRole
import kotlinx.coroutines.launch

sealed class PrincipalNavTab(val title: String, val icon: ImageVector, val tag: String) {
    object Attendance : PrincipalNavTab("Attendance", Icons.Default.FactCheck, "tab_nav_attendance")
    object Classes : PrincipalNavTab("Classes", Icons.Default.MeetingRoom, "tab_nav_classes")
    object Teachers : PrincipalNavTab("Teachers", Icons.Default.SupervisorAccount, "tab_nav_teachers")
    object Students : PrincipalNavTab("Students", Icons.Default.People, "tab_nav_students")
    object Academics : PrincipalNavTab("Academics", Icons.Default.MenuBook, "tab_nav_academics")
    object Calendar : PrincipalNavTab("Calendar", Icons.Default.CalendarMonth, "tab_nav_calendar")
    object Leaves : PrincipalNavTab("Leaves", Icons.Default.EventAvailable, "tab_nav_leaves")
    object Notices : PrincipalNavTab("Notices", Icons.Default.Campaign, "tab_nav_notices")
    object Settings : PrincipalNavTab("Settings", Icons.Default.Settings, "tab_nav_settings")
}

sealed class TeacherNavTab(val title: String, val icon: ImageVector, val tag: String) {
    object Attendance : TeacherNavTab("Attendance", Icons.Default.FactCheck, "teacher_tab_attendance")
    object Students : TeacherNavTab("Students", Icons.Default.People, "teacher_tab_students")
    object Timetable : TeacherNavTab("Timetable", Icons.Default.Schedule, "teacher_tab_timetable")
    object Homework : TeacherNavTab("Homework", Icons.Default.MenuBook, "teacher_tab_homework")
    object Marks : TeacherNavTab("Marks", Icons.Default.Grade, "teacher_tab_marks")
    object Calendar : TeacherNavTab("Calendar", Icons.Default.CalendarMonth, "teacher_tab_calendar")
    object Leaves : TeacherNavTab("Leaves", Icons.Default.EventNote, "teacher_tab_leaves")
    object Notices : TeacherNavTab("Notices", Icons.Default.Campaign, "teacher_tab_notices")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: SchoolViewModel) {
    val authState by viewModel.authState.collectAsState()
    val currentRole by viewModel.currentRole.collectAsState()
    val selectedTeacher by viewModel.selectedTeacher.collectAsState()
    val teachers by viewModel.teachers.collectAsState()
    val classes by viewModel.classes.collectAsState()
    val userMessage by viewModel.userMessage.collectAsState()
    val leaves by viewModel.allLeaves.collectAsState()
    val schoolSettings by viewModel.schoolSettings.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var principalTab by remember { mutableStateOf<PrincipalNavTab>(PrincipalNavTab.Attendance) }
    var teacherTab by remember { mutableStateOf<TeacherNavTab>(TeacherNavTab.Attendance) }
    var showTeacherMenu by remember { mutableStateOf(false) }
    var showTeacherChangePasswordDialog by remember { mutableStateOf(false) }
    var showTeacherProfileDialog by remember { mutableStateOf(false) }
    var showLogoutConfirmDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    val pendingLeavesCount = remember(leaves) {
        leaves.count { it.status == "PENDING" }
    }

    LaunchedEffect(userMessage) {
        userMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearUserMessage()
        }
    }

    // If user is not authenticated, display the unified secure Login Portal
    if (authState is AuthState.LoggedOut) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { innerPadding ->
            LoginScreen(
                viewModel = viewModel,
                modifier = Modifier.padding(innerPadding)
            )
        }
        return
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            shadowElevation = 2.dp,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_keducore_logo),
                                contentDescription = "KEduCore Logo",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(8.dp))
                            )
                        }

                        Column {
                            Text(
                                text = schoolSettings?.schoolName ?: "KEduCore",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            // Subtitle showing current role / assigned teacher
                            if (currentRole == UserRole.PRINCIPAL) {
                                Text(
                                    text = "Principal Portal • Admin (${schoolSettings?.principalUsername ?: "admin"})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            } else {
                                val assignedClass = classes.find { it.teacherId == selectedTeacher?.id }
                                val classText = assignedClass?.displayName ?: "Subject Teacher"
                                Text(
                                    text = "${selectedTeacher?.name ?: "Faculty"} • $classText",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                },
                actions = {
                    if (currentRole == UserRole.TEACHER) {
                        // Teacher Profile & Account Menu
                        Box {
                            IconButton(
                                onClick = { showTeacherMenu = true },
                                modifier = Modifier.testTag("teacher_account_menu_button")
                            ) {
                                Icon(Icons.Default.AccountCircle, contentDescription = "Teacher Account Menu")
                            }

                            DropdownMenu(
                                expanded = showTeacherMenu,
                                onDismissRequest = { showTeacherMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("My Faculty Profile") },
                                    onClick = {
                                        showTeacherMenu = false
                                        showTeacherProfileDialog = true
                                    },
                                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Change Password") },
                                    onClick = {
                                        showTeacherMenu = false
                                        showTeacherChangePasswordDialog = true
                                    },
                                    leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("Log Out", color = MaterialTheme.colorScheme.error) },
                                    onClick = {
                                        showTeacherMenu = false
                                        showLogoutConfirmDialog = true
                                    },
                                    leadingIcon = { Icon(Icons.Default.Logout, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                                )
                            }
                        }
                    } else {
                        // Principal Logout Action Button
                        IconButton(
                            onClick = { showLogoutConfirmDialog = true },
                            modifier = Modifier.testTag("principal_top_logout_btn")
                        ) {
                            Icon(Icons.Default.Logout, contentDescription = "Log Out", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                windowInsets = WindowInsets.navigationBars
            ) {
                if (currentRole == UserRole.PRINCIPAL) {
                    val primaryTabs = listOf(
                        PrincipalNavTab.Attendance,
                        PrincipalNavTab.Classes,
                        PrincipalNavTab.Teachers,
                        PrincipalNavTab.Students,
                        PrincipalNavTab.Academics,
                        PrincipalNavTab.Calendar,
                        PrincipalNavTab.Leaves,
                        PrincipalNavTab.Settings
                    )

                    primaryTabs.forEach { tab ->
                        NavigationBarItem(
                            selected = principalTab == tab,
                            onClick = { principalTab = tab },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (tab == PrincipalNavTab.Leaves && pendingLeavesCount > 0) {
                                            Badge { Text("$pendingLeavesCount") }
                                        }
                                    }
                                ) {
                                    Icon(tab.icon, contentDescription = tab.title)
                                }
                            },
                            label = { Text(tab.title, fontSize = 10.sp, maxLines = 1) },
                            modifier = Modifier.testTag(tab.tag)
                        )
                    }
                } else {
                    val teacherTabs = listOf(
                        TeacherNavTab.Attendance,
                        TeacherNavTab.Students,
                        TeacherNavTab.Timetable,
                        TeacherNavTab.Homework,
                        TeacherNavTab.Marks,
                        TeacherNavTab.Calendar,
                        TeacherNavTab.Leaves,
                        TeacherNavTab.Notices
                    )

                    teacherTabs.forEach { tab ->
                        NavigationBarItem(
                            selected = teacherTab == tab,
                            onClick = { teacherTab = tab },
                            icon = { Icon(tab.icon, contentDescription = tab.title) },
                            label = { Text(tab.title, fontSize = 10.sp, maxLines = 1) },
                            modifier = Modifier.testTag(tab.tag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // In Principal Mode, show quick notices bar if on other tab
            if (currentRole == UserRole.PRINCIPAL && principalTab != PrincipalNavTab.Notices) {
                PrincipalQuickNoticesBar(onOpenNotices = { principalTab = PrincipalNavTab.Notices })
            }

            // In Teacher Mode, show quick banner with assigned class info
            if (currentRole == UserRole.TEACHER) {
                val assignedClass = classes.find { it.teacherId == selectedTeacher?.id }
                TeacherClassBanner(
                    teacher = selectedTeacher,
                    assignedClass = assignedClass,
                    onChangePassword = { showTeacherChangePasswordDialog = true },
                    onViewProfile = { showTeacherProfileDialog = true }
                )
            }

            // Content Body based on current role and tab
            Crossfade(
                targetState = Pair(currentRole, if (currentRole == UserRole.PRINCIPAL) principalTab.title else teacherTab.title),
                label = "ScreenTransition"
            ) { (role, _) ->
                if (role == UserRole.PRINCIPAL) {
                    when (principalTab) {
                        PrincipalNavTab.Attendance -> PrincipalAttendanceScreen(viewModel)
                        PrincipalNavTab.Classes -> ManageClassesScreen(viewModel)
                        PrincipalNavTab.Teachers -> ManageTeachersScreen(viewModel)
                        PrincipalNavTab.Students -> ManageStudentsScreen(viewModel)
                        PrincipalNavTab.Academics -> PrincipalAcademicsHubScreen(viewModel)
                        PrincipalNavTab.Calendar -> SchoolCalendarScreen(viewModel)
                        PrincipalNavTab.Leaves -> PrincipalLeavesScreen(viewModel)
                        PrincipalNavTab.Notices -> PrincipalAnnouncementsScreen(viewModel)
                        PrincipalNavTab.Settings -> SettingsAndSecurityScreen(viewModel)
                    }
                } else {
                    when (teacherTab) {
                        TeacherNavTab.Attendance -> TeacherAttendanceScreen(viewModel)
                        TeacherNavTab.Students -> TeacherStudentsScreen(viewModel)
                        TeacherNavTab.Timetable -> TimetableScreen(viewModel)
                        TeacherNavTab.Homework -> TeacherHomeworkScreen(viewModel)
                        TeacherNavTab.Marks -> TeacherMarksScreen(viewModel)
                        TeacherNavTab.Calendar -> SchoolCalendarScreen(viewModel)
                        TeacherNavTab.Leaves -> TeacherLeavesScreen(viewModel)
                        TeacherNavTab.Notices -> TeacherAnnouncementsScreen(viewModel)
                    }
                }
            }
        }
    }

    // Teacher Change Password Dialog
    if (showTeacherChangePasswordDialog && selectedTeacher != null) {
        val teacher = selectedTeacher!!
        var currentPass by remember { mutableStateOf("") }
        var newPass by remember { mutableStateOf("") }
        var confirmPass by remember { mutableStateOf("") }
        var passVisible by remember { mutableStateOf(false) }
        var errorMsg by remember { mutableStateOf<String?>(null) }
        var isSaving by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showTeacherChangePasswordDialog = false },
            title = { Text("Change Password (${teacher.name})", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Update your portal login password. Username: @${teacher.username.ifBlank { teacher.email.substringBefore("@") }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (errorMsg != null) {
                        Text(errorMsg ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }

                    OutlinedTextField(
                        value = currentPass,
                        onValueChange = {
                            currentPass = it
                            errorMsg = null
                        },
                        label = { Text("Current Password") },
                        visualTransformation = if (passVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("teacher_current_pass_input")
                    )

                    OutlinedTextField(
                        value = newPass,
                        onValueChange = {
                            newPass = it
                            errorMsg = null
                        },
                        label = { Text("New Password (min 4 chars)") },
                        trailingIcon = {
                            IconButton(onClick = { passVisible = !passVisible }) {
                                Icon(if (passVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = null)
                            }
                        },
                        visualTransformation = if (passVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("teacher_new_pass_input")
                    )

                    OutlinedTextField(
                        value = confirmPass,
                        onValueChange = {
                            confirmPass = it
                            errorMsg = null
                        },
                        label = { Text("Confirm New Password") },
                        visualTransformation = if (passVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("teacher_confirm_pass_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPass != confirmPass) {
                            errorMsg = "New passwords do not match."
                        } else {
                            coroutineScope.launch {
                                isSaving = true
                                val err = viewModel.changeTeacherPassword(teacher.id, currentPass, newPass)
                                isSaving = false
                                if (err != null) {
                                    errorMsg = err
                                } else {
                                    showTeacherChangePasswordDialog = false
                                }
                            }
                        }
                    },
                    enabled = !isSaving
                ) {
                    Text("Save Password")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTeacherChangePasswordDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Teacher Profile Dialog
    if (showTeacherProfileDialog && selectedTeacher != null) {
        val assignedClass = classes.find { it.teacherId == selectedTeacher?.id }
        TeacherProfileDialog(
            teacher = selectedTeacher!!,
            assignedClass = assignedClass,
            viewModel = viewModel,
            onDismiss = { showTeacherProfileDialog = false },
            onEdit = {
                showTeacherProfileDialog = false
                showTeacherChangePasswordDialog = true
            }
        )
    }

    // Logout Confirmation Dialog
    if (showLogoutConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirmDialog = false },
            title = { Text("Log Out") },
            text = {
                Text(
                    if (currentRole == UserRole.PRINCIPAL)
                        "Are you sure you want to log out from the Principal / Admin portal?"
                    else
                        "Are you sure you want to log out from your Teacher account (${selectedTeacher?.name})?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutConfirmDialog = false
                        viewModel.logout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Log Out")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

/**
 * Teacher Banner showing current teacher credentials & assigned class
 */
@Composable
fun TeacherClassBanner(
    teacher: Teacher?,
    assignedClass: SchoolClass?,
    onChangePassword: () -> Unit,
    onViewProfile: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = SecondaryTealLight.copy(alpha = 0.12f),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Badge,
                    contentDescription = null,
                    tint = SecondaryTeal,
                    modifier = Modifier.size(18.dp)
                )
                Column {
                    Text(
                        text = "${teacher?.name ?: "Faculty"} (${teacher?.subject ?: "All Subjects"})",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (assignedClass != null) "Assigned Class: ${assignedClass.displayName}" else "No Class Assigned (Subject Faculty)",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (assignedClass != null) SecondaryTeal else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(
                    onClick = onViewProfile,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("Profile", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
                TextButton(
                    onClick = onChangePassword,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("Password", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/**
 * Principal Academics Hub Screen combining:
 * 1. Homework & Marks
 * 2. Class & Teacher Timetable
 * 3. Exam Timetable Datesheets
 * 4. Subject-Wise Results & Performance Reports
 */
@Composable
fun PrincipalAcademicsHubScreen(viewModel: SchoolViewModel) {
    var subTab by remember { mutableIntStateOf(0) } // 0: Results & Marks, 1: Timetable, 2: Exam Schedule, 3: Homework & Class Marks

    Column(modifier = Modifier.fillMaxSize()) {
        ScrollableTabRow(
            selectedTabIndex = subTab,
            edgePadding = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Tab(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                text = { Text("Results & Reports", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = { Text("Timetable", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = subTab == 2,
                onClick = { subTab = 2 },
                text = { Text("Exam Schedule", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = subTab == 3,
                onClick = { subTab = 3 },
                text = { Text("Homework & Marks", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.Assignment, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
        }

        when (subTab) {
            0 -> AcademicResultsAndReportsScreen(viewModel = viewModel)
            1 -> TimetableScreen(viewModel = viewModel)
            2 -> ExamTimetableScreen(viewModel = viewModel)
            3 -> PrincipalHomeworkMarksScreen(viewModel = viewModel)
        }
    }
}

@Composable
fun PrincipalQuickNoticesBar(onOpenNotices: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Campaign,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "School Announcements",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            TextButton(
                onClick = onOpenNotices,
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text("Manage Notices", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
