package com.example.ui.screens.teacher

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Student
import com.example.data.model.StudentMark
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherMarksScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val attendanceState by viewModel.teacherAttendanceState.collectAsState()
    val allMarks by viewModel.allMarks.collectAsState()
    val selectedTeacher by viewModel.selectedTeacher.collectAsState()
    val selectedDate by viewModel.selectedDate.collectAsState()

    val assignedClass = attendanceState.schoolClass
    val students = attendanceState.students

    val classMarks = remember(allMarks, assignedClass) {
        if (assignedClass == null) emptyList()
        else allMarks.filter { it.classId == assignedClass.id }
    }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: View Marks, 1: Enter Marks
    var showSingleMarkDialog by remember { mutableStateOf(false) }
    var markToDelete by remember { mutableStateOf<StudentMark?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        if (assignedClass == null) {
            EmptyStateView(
                icon = Icons.Default.Grade,
                title = "No Class Assigned",
                description = "You need an assigned class to record student assessment marks."
            )
        } else {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Marks: ${assignedClass.displayName}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${classMarks.size} Recorded Marks for ${students.size} students",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            PrimaryTabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.Transparent,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Recorded Marks (${classMarks.size})", fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(Icons.Default.ListAlt, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_view_marks")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Enter Batch Marks", fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_enter_marks")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (selectedTab == 0) {
                // View Recorded Marks
                if (classMarks.isEmpty()) {
                    EmptyStateView(
                        icon = Icons.Default.Assessment,
                        title = "No Marks Recorded Yet",
                        description = "Switch to the 'Enter Batch Marks' tab to grade an exam or test for ${assignedClass.displayName}."
                    )
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 80.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(classMarks, key = { it.id }) { mark ->
                            val student = students.find { it.id == mark.studentId }
                            val percentage = if (mark.maxMarks > 0) (mark.obtainedMarks * 100) / mark.maxMarks else 0
                            val scoreColor = when {
                                percentage >= 75 -> PresentGreen
                                percentage >= 50 -> PendingAmber
                                else -> AbsentRed
                            }

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("teacher_mark_card_${mark.id}"),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(CircleShape)
                                            .background(scoreColor.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(
                                                text = "${mark.obtainedMarks}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = scoreColor
                                            )
                                            Text(
                                                text = "/${mark.maxMarks}",
                                                fontSize = 10.sp,
                                                color = scoreColor
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${student?.rollNumber ?: ""}. ${student?.name ?: "Student"}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "${mark.subject} • ${mark.assessmentName}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (mark.remarks.isNotBlank()) {
                                            Text(
                                                text = "Remark: ${mark.remarks}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }

                                    IconButton(onClick = { markToDelete = mark }) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // Enter Batch Marks Mode
                BatchMarksEntryView(
                    students = students,
                    defaultSubject = selectedTeacher?.subject ?: "Subject",
                    date = selectedDate,
                    onSaveBatch = { batchMarks ->
                        viewModel.saveBatchMarks(batchMarks) {
                            selectedTab = 0
                        }
                    }
                )
            }
        }
    }

    if (markToDelete != null) {
        ConfirmDeleteDialog(
            title = "Delete Mark Record?",
            message = "Are you sure you want to remove this mark entry?",
            onConfirm = {
                markToDelete?.let { viewModel.deleteMark(it) }
                markToDelete = null
            },
            onDismiss = { markToDelete = null }
        )
    }
}

@Composable
fun BatchMarksEntryView(
    students: List<Student>,
    defaultSubject: String,
    date: String,
    onSaveBatch: (List<StudentMark>) -> Unit
) {
    var subject by remember { mutableStateOf(defaultSubject) }
    var assessmentName by remember { mutableStateOf("Unit Test 1") }
    var maxMarksText by remember { mutableStateOf("100") }

    // Map studentId -> (obtainedMarksText, remarks)
    val scoresMap = remember(students) {
        mutableStateMapOf<Long, Pair<String, String>>().apply {
            students.forEach { s ->
                this[s.id] = Pair("", "")
            }
        }
    }

    if (students.isEmpty()) {
        EmptyStateView(
            icon = Icons.Default.PeopleOutline,
            title = "No Students in Class",
            description = "Cannot enter marks because no students are enrolled in this class."
        )
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = assessmentName,
                            onValueChange = { assessmentName = it },
                            label = { Text("Assessment Name *") },
                            singleLine = true,
                            modifier = Modifier.weight(1.3f).testTag("assessment_name_input")
                        )
                        OutlinedTextField(
                            value = maxMarksText,
                            onValueChange = { maxMarksText = it },
                            label = { Text("Max Marks") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(0.7f).testTag("max_marks_input")
                        )
                    }

                    OutlinedTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text("Subject *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("marks_subject_input")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Enter Student Scores",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(students, key = { it.id }) { student ->
                    val (scoreText, remark) = scoresMap[student.id] ?: Pair("", "")

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = student.rollNumber,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 12.sp
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = student.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                OutlinedTextField(
                                    value = remark,
                                    onValueChange = { newRemark ->
                                        scoresMap[student.id] = Pair(scoreText, newRemark)
                                    },
                                    placeholder = { Text("Remark (optional)", fontSize = 11.sp) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            OutlinedTextField(
                                value = scoreText,
                                onValueChange = { newScore ->
                                    scoresMap[student.id] = Pair(newScore, remark)
                                },
                                placeholder = { Text("Marks") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.width(80.dp).testTag("student_mark_input_${student.id}")
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    val maxMarks = maxMarksText.toIntOrNull() ?: 100
                    val validEntries = students.mapNotNull { student ->
                        val (scoreText, remark) = scoresMap[student.id] ?: Pair("", "")
                        val obtained = scoreText.toIntOrNull()
                        if (obtained != null) {
                            StudentMark(
                                classId = student.classId,
                                studentId = student.id,
                                subject = subject.trim(),
                                assessmentName = assessmentName.trim(),
                                maxMarks = maxMarks,
                                obtainedMarks = obtained,
                                remarks = remark.trim(),
                                date = date
                            )
                        } else null
                    }
                    if (validEntries.isNotEmpty()) {
                        onSaveBatch(validEntries)
                    }
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryNavy),
                modifier = Modifier.fillMaxWidth().testTag("save_batch_marks_button")
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Save Marks for Class")
            }
        }
    }
}
