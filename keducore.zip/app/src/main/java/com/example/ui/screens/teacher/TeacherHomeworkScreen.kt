package com.example.ui.screens.teacher

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Homework
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel

@Composable
fun TeacherHomeworkScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val attendanceState by viewModel.teacherAttendanceState.collectAsState()
    val allHomework by viewModel.allHomework.collectAsState()
    val selectedTeacher by viewModel.selectedTeacher.collectAsState()

    val assignedClass = attendanceState.schoolClass
    val classHomework = remember(allHomework, assignedClass) {
        if (assignedClass == null) emptyList()
        else allHomework.filter { it.classId == assignedClass.id }
    }

    var showAddDialog by remember { mutableStateOf(false) }
    var homeworkToDelete by remember { mutableStateOf<Homework?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            if (assignedClass == null) {
                EmptyStateView(
                    icon = Icons.Default.MenuBook,
                    title = "No Class Assigned",
                    description = "You need an assigned class to post and manage homework."
                )
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Homework: ${assignedClass.displayName}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${classHomework.size} Assignments posted",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (classHomework.isEmpty()) {
                    EmptyStateView(
                        icon = Icons.Default.Assignment,
                        title = "No Homework Assigned Yet",
                        description = "Tap the '+' button below to create a new homework assignment for ${assignedClass.displayName}."
                    )
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 88.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(classHomework, key = { it.id }) { hw ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("teacher_hw_card_${hw.id}"),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        StatusBadge(
                                            text = hw.subject,
                                            containerColor = SecondaryTealLight.copy(alpha = 0.15f),
                                            contentColor = SecondaryTeal
                                        )

                                        IconButton(
                                            onClick = { homeworkToDelete = hw },
                                            modifier = Modifier.size(28.dp).testTag("delete_hw_${hw.id}")
                                        ) {
                                            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = hw.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )

                                    if (hw.description.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = hw.description,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.Event, contentDescription = null, tint = AccentGoldDark, modifier = Modifier.size(14.dp))
                                        Text(
                                            text = "Due Date: ${hw.dueDate}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = AccentGoldDark
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (assignedClass != null) {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .testTag("add_homework_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Homework")
            }
        }
    }

    if (showAddDialog && assignedClass != null && selectedTeacher != null) {
        AddHomeworkDialog(
            defaultSubject = selectedTeacher?.subject ?: "",
            onDismiss = { showAddDialog = false },
            onSave = { subject, title, desc, dueDate ->
                viewModel.addHomework(
                    Homework(
                        classId = assignedClass.id,
                        teacherId = selectedTeacher!!.id,
                        subject = subject,
                        title = title,
                        description = desc,
                        dueDate = dueDate
                    )
                )
                showAddDialog = false
            }
        )
    }

    if (homeworkToDelete != null) {
        ConfirmDeleteDialog(
            title = "Delete Assignment?",
            message = "Are you sure you want to remove \"${homeworkToDelete?.title}\"?",
            onConfirm = {
                homeworkToDelete?.let { viewModel.deleteHomework(it) }
                homeworkToDelete = null
            },
            onDismiss = { homeworkToDelete = null }
        )
    }
}

@Composable
fun AddHomeworkDialog(
    defaultSubject: String,
    onDismiss: () -> Unit,
    onSave: (subject: String, title: String, description: String, dueDate: String) -> Unit
) {
    var subject by remember { mutableStateOf(defaultSubject) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf("Tomorrow") }
    var titleError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Homework Assignment", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("dialog_hw_subject_field")
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        titleError = it.isBlank()
                    },
                    label = { Text("Homework Title / Chapter *") },
                    placeholder = { Text("e.g. Chapter 5 Exercises") },
                    isError = titleError,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("dialog_hw_title_field")
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Instructions / Details") },
                    placeholder = { Text("Solve Q 1-10 on page 78...") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth().testTag("dialog_hw_desc_field")
                )

                OutlinedTextField(
                    value = dueDate,
                    onValueChange = { dueDate = it },
                    label = { Text("Due Date *") },
                    placeholder = { Text("e.g. Tomorrow, Friday, 28 Aug") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("dialog_hw_due_field")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank()) titleError = true
                    if (title.isNotBlank() && subject.isNotBlank()) {
                        onSave(subject.trim(), title.trim(), description.trim(), dueDate.trim())
                    }
                },
                modifier = Modifier.testTag("dialog_hw_save_button")
            ) {
                Text("Post Assignment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
