package com.example.ui.screens.principal

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Homework
import com.example.data.model.StudentMark
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrincipalHomeworkMarksScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val homeworkList by viewModel.allHomework.collectAsState()
    val marksList by viewModel.allMarks.collectAsState()
    val classes by viewModel.classes.collectAsState()
    val students by viewModel.students.collectAsState()
    val teachers by viewModel.teachers.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Homework, 1: Marks
    var selectedClassFilter by remember { mutableStateOf<Long?>(null) }
    var isFilterMenuExpanded by remember { mutableStateOf(false) }
    var homeworkToDelete by remember { mutableStateOf<Homework?>(null) }
    var markToDelete by remember { mutableStateOf<StudentMark?>(null) }

    val filteredHomework = remember(homeworkList, selectedClassFilter) {
        if (selectedClassFilter == null) homeworkList
        else homeworkList.filter { it.classId == selectedClassFilter }
    }

    val filteredMarks = remember(marksList, selectedClassFilter) {
        if (selectedClassFilter == null) marksList
        else marksList.filter { it.classId == selectedClassFilter }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Tab selector
        PrimaryTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.Transparent,
            modifier = Modifier.fillMaxWidth()
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Homework (${filteredHomework.size})", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.testTag("tab_principal_homework")
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Student Marks (${filteredMarks.size})", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.Grade, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.testTag("tab_principal_marks")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Class Filter
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ExposedDropdownMenuBox(
                expanded = isFilterMenuExpanded,
                onExpandedChange = { isFilterMenuExpanded = !isFilterMenuExpanded }
            ) {
                val currentName = if (selectedClassFilter == null) "All Classes" else {
                    classes.find { it.id == selectedClassFilter }?.displayName ?: "Selected Class"
                }
                FilterChip(
                    selected = selectedClassFilter != null,
                    onClick = { isFilterMenuExpanded = true },
                    label = { Text("Filter: $currentName") },
                    leadingIcon = { Icon(Icons.Default.FilterAlt, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) },
                    modifier = Modifier.menuAnchor()
                )

                ExposedDropdownMenu(
                    expanded = isFilterMenuExpanded,
                    onDismissRequest = { isFilterMenuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("All Classes") },
                        onClick = {
                            selectedClassFilter = null
                            isFilterMenuExpanded = false
                        }
                    )
                    classes.forEach { c ->
                        DropdownMenuItem(
                            text = { Text(c.displayName) },
                            onClick = {
                                selectedClassFilter = c.id
                                isFilterMenuExpanded = false
                            }
                        )
                    }
                }
            }

            Text(
                text = if (selectedTab == 0) "${filteredHomework.size} Assignments" else "${filteredMarks.size} Results",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (selectedTab == 0) {
            if (filteredHomework.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Assignment,
                    title = "No Homework Found",
                    description = "Teachers post homework for their assigned classes which will appear here."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredHomework, key = { it.id }) { hw ->
                        val targetClass = classes.find { it.id == hw.classId }
                        val teacher = teachers.find { it.id == hw.teacherId }

                        PrincipalHomeworkCard(
                            homework = hw,
                            className = targetClass?.displayName ?: "Class",
                            teacherName = teacher?.name ?: "Teacher",
                            onDelete = { homeworkToDelete = hw }
                        )
                    }
                }
            }
        } else {
            if (filteredMarks.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Assessment,
                    title = "No Student Marks Recorded",
                    description = "Entered student assessment marks will be listed here."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 80.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredMarks, key = { it.id }) { mark ->
                        val student = students.find { it.id == mark.studentId }
                        val studentClass = classes.find { it.id == mark.classId }

                        PrincipalMarkCard(
                            mark = mark,
                            studentName = student?.name ?: "Student",
                            rollNumber = student?.rollNumber ?: "—",
                            className = studentClass?.displayName ?: "Class",
                            onDelete = { markToDelete = mark }
                        )
                    }
                }
            }
        }
    }

    if (homeworkToDelete != null) {
        ConfirmDeleteDialog(
            title = "Delete Homework?",
            message = "Remove assignment \"${homeworkToDelete?.title}\"?",
            onConfirm = {
                homeworkToDelete?.let { viewModel.deleteHomework(it) }
                homeworkToDelete = null
            },
            onDismiss = { homeworkToDelete = null }
        )
    }

    if (markToDelete != null) {
        ConfirmDeleteDialog(
            title = "Delete Mark Entry?",
            message = "Remove mark entry for this student?",
            onConfirm = {
                markToDelete?.let { viewModel.deleteMark(it) }
                markToDelete = null
            },
            onDismiss = { markToDelete = null }
        )
    }
}

@Composable
fun PrincipalHomeworkCard(
    homework: Homework,
    className: String,
    teacherName: String,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    StatusBadge(
                        text = className,
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.primary,
                        icon = Icons.Default.School
                    )
                    StatusBadge(
                        text = homework.subject,
                        containerColor = SecondaryTealLight.copy(alpha = 0.15f),
                        contentColor = SecondaryTeal
                    )
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = homework.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (homework.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = homework.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Teacher: $teacherName",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.Event, contentDescription = null, tint = AccentGoldDark, modifier = Modifier.size(14.dp))
                    Text(
                        text = "Due: ${homework.dueDate}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = AccentGoldDark
                    )
                }
            }
        }
    }
}

@Composable
fun PrincipalMarkCard(
    mark: StudentMark,
    studentName: String,
    rollNumber: String,
    className: String,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val percentage = if (mark.maxMarks > 0) (mark.obtainedMarks * 100) / mark.maxMarks else 0
    val scoreColor = when {
        percentage >= 75 -> PresentGreen
        percentage >= 50 -> PendingAmber
        else -> AbsentRed
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(scoreColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${mark.obtainedMarks}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = scoreColor
                    )
                    Text(
                        text = "/${mark.maxMarks}",
                        fontSize = 10.sp,
                        color = scoreColor
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "$rollNumber. $studentName",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "$className • ${mark.subject} (${mark.assessmentName})",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (mark.remarks.isNotBlank()) {
                    Text(
                        text = "Remark: ${mark.remarks}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}
