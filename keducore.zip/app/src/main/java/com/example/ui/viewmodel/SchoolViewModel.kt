package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.SchoolDatabase
import com.example.data.model.*
import com.example.data.repository.SchoolRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class UserRole {
    PRINCIPAL,
    TEACHER
}

sealed interface AuthState {
    object LoggedOut : AuthState
    data class LoggedInPrincipal(
        val name: String = "Dr. Arthur Vance, Ph.D",
        val username: String = "admin",
        val email: String = "admin@stjudeacademy.edu"
    ) : AuthState
    data class LoggedInTeacher(
        val teacher: Teacher
    ) : AuthState
}

data class TeacherAttendanceState(
    val schoolClass: SchoolClass? = null,
    val students: List<Student> = emptyList(),
    val attendanceMap: Map<Long, Boolean> = emptyMap(), // studentId -> isPresent
    val reasonMap: Map<Long, String> = emptyMap(), // studentId -> reason
    val isSubmitted: Boolean = false,
    val submittedAt: Long? = null,
    val notes: String = "",
    val isLoading: Boolean = false
)

class SchoolViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SchoolRepository
    private val dateFormatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val monthFormatter = SimpleDateFormat("yyyy-MM", Locale.getDefault())

    // Authentication & Role state
    private val _authState = MutableStateFlow<AuthState>(AuthState.LoggedOut)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _currentRole = MutableStateFlow(UserRole.PRINCIPAL)
    val currentRole: StateFlow<UserRole> = _currentRole.asStateFlow()

    private val _selectedTeacher = MutableStateFlow<Teacher?>(null)
    val selectedTeacher: StateFlow<Teacher?> = _selectedTeacher.asStateFlow()

    // Date state for attendance & filtering
    private val _selectedDate = MutableStateFlow(dateFormatter.format(Date()))
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    // Month state for monthly reports
    private val _selectedMonth = MutableStateFlow(monthFormatter.format(Date()))
    val selectedMonth: StateFlow<String> = _selectedMonth.asStateFlow()

    // Snackbar / Feedback message
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // Database flows
    val teachers: StateFlow<List<Teacher>>
    val classes: StateFlow<List<SchoolClass>>
    val students: StateFlow<List<Student>>
    val announcements: StateFlow<List<Announcement>>
    val allLeaves: StateFlow<List<LeaveApplication>>
    val allHomework: StateFlow<List<Homework>>
    val allMarks: StateFlow<List<StudentMark>>
    val allTimetables: StateFlow<List<TimetableEntry>>
    val allExams: StateFlow<List<ExamSchedule>>
    val allEvents: StateFlow<List<SchoolEvent>>
    val holidays: StateFlow<List<SchoolEvent>>
    val schoolSettings: StateFlow<SchoolSettingsEntity?>
    val absenceLogs: StateFlow<List<AbsenceNotificationLog>>
    val allAttendanceRecords: StateFlow<List<AttendanceRecord>>

    // Principal Attendance summary flow reactively combined with selectedDate
    val principalAttendanceSummary: StateFlow<List<ClassAttendanceSummary>>

    // Teacher Attendance records for selected date
    val teacherDailyAttendance: StateFlow<List<TeacherAttendanceRecord>>

    // Teacher's specific attendance state
    private val _teacherAttendanceState = MutableStateFlow(TeacherAttendanceState())
    val teacherAttendanceState: StateFlow<TeacherAttendanceState> = _teacherAttendanceState.asStateFlow()

    // Security PIN Lock State
    private val _isPrincipalUnlocked = MutableStateFlow(false)
    val isPrincipalUnlocked: StateFlow<Boolean> = _isPrincipalUnlocked.asStateFlow()

    init {
        val database = SchoolDatabase.getDatabase(application, viewModelScope)
        repository = SchoolRepository(database.schoolDao())

        teachers = repository.allTeachers
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        classes = repository.allClasses
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        students = repository.allStudents
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        announcements = repository.allAnnouncements
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        allLeaves = repository.allLeaves
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        allHomework = repository.allHomework
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        allMarks = repository.allMarks
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        allTimetables = repository.allTimetables
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        allExams = repository.allExams
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        allEvents = repository.allSchoolEvents
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        holidays = repository.allHolidays
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        schoolSettings = repository.schoolSettings
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

        absenceLogs = repository.allAbsenceLogs
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        allAttendanceRecords = repository.allAttendanceRecords
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
        principalAttendanceSummary = _selectedDate
            .flatMapLatest { date ->
                repository.getAllClassesAttendanceSummary(date)
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
        teacherDailyAttendance = _selectedDate
            .flatMapLatest { date ->
                repository.getTeacherAttendanceByDate(date)
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        // Automatically set first teacher when teachers load if not set
        viewModelScope.launch {
            teachers.collect { list ->
                if (_selectedTeacher.value == null && list.isNotEmpty()) {
                    _selectedTeacher.value = list.first()
                    loadTeacherAttendance()
                }
            }
        }
    }

    // --- Authentication Actions ---

    fun loginPrincipal(identifier: String, pass: String): String? {
        val settings = schoolSettings.value
        val expectedUsername = settings?.principalUsername?.ifBlank { "admin" } ?: "admin"
        val expectedEmail = settings?.schoolEmail?.ifBlank { "admin@stjudeacademy.edu" } ?: "admin@stjudeacademy.edu"
        val expectedPassword = settings?.principalPassword?.ifBlank { "admin123" } ?: "admin123"

        val trimmedIdentifier = identifier.trim()
        val isUsernameMatch = trimmedIdentifier.equals(expectedUsername, ignoreCase = true)
        val isEmailMatch = trimmedIdentifier.equals(expectedEmail, ignoreCase = true)

        if (!isUsernameMatch && !isEmailMatch) {
            return "Invalid Principal username or email."
        }
        if (pass != expectedPassword) {
            return "Incorrect password."
        }

        _authState.value = AuthState.LoggedInPrincipal(
            name = settings?.principalName ?: "Dr. Arthur Vance, Ph.D",
            username = expectedUsername,
            email = expectedEmail
        )
        _currentRole.value = UserRole.PRINCIPAL
        _isPrincipalUnlocked.value = true
        _userMessage.value = "Welcome back, Principal!"
        return null
    }

    suspend fun loginTeacher(identifier: String, pass: String): String? {
        val teacher = repository.getTeacherByUsernameOrEmail(identifier.trim())
            ?: return "No teacher found with username or email \"$identifier\"."

        if (!teacher.isActive) {
            return "This faculty account is deactivated. Please contact the Principal."
        }

        val expectedPass = teacher.passwordHash.ifBlank { "teacher123" }
        if (pass != expectedPass) {
            return "Incorrect password."
        }

        repository.updateTeacherLastLogin(teacher.id)
        _selectedTeacher.value = teacher
        _authState.value = AuthState.LoggedInTeacher(teacher)
        _currentRole.value = UserRole.TEACHER
        loadTeacherAttendance()
        _userMessage.value = "Welcome back, ${teacher.name}!"
        return null
    }

    fun loginDemoPrincipal() {
        val settings = schoolSettings.value
        _authState.value = AuthState.LoggedInPrincipal(
            name = settings?.principalName ?: "Dr. Arthur Vance, Ph.D",
            username = settings?.principalUsername ?: "admin",
            email = settings?.schoolEmail ?: "admin@stjudeacademy.edu"
        )
        _currentRole.value = UserRole.PRINCIPAL
        _isPrincipalUnlocked.value = true
        _userMessage.value = "Logged in as Principal (Admin Portal)"
    }

    fun loginDemoTeacher(teacher: Teacher) {
        if (!teacher.isActive) {
            _userMessage.value = "Teacher ${teacher.name} is deactivated."
            return
        }
        viewModelScope.launch {
            repository.updateTeacherLastLogin(teacher.id)
            _selectedTeacher.value = teacher
            _authState.value = AuthState.LoggedInTeacher(teacher)
            _currentRole.value = UserRole.TEACHER
            loadTeacherAttendance()
            _userMessage.value = "Logged in as ${teacher.name}"
        }
    }

    fun logout() {
        _authState.value = AuthState.LoggedOut
        _isPrincipalUnlocked.value = false
        _userMessage.value = "Logged out successfully."
    }

    fun changePrincipalPassword(currentPass: String, newPass: String): String? {
        val settings = schoolSettings.value ?: SchoolSettingsEntity()
        val expectedPass = settings.principalPassword.ifBlank { "admin123" }
        if (currentPass != expectedPass) {
            return "Current password does not match."
        }
        if (newPass.length < 4) {
            return "New password must be at least 4 characters."
        }
        viewModelScope.launch {
            val updated = settings.copy(principalPassword = newPass)
            repository.updateSchoolSettings(updated)
            _userMessage.value = "Principal password updated successfully."
        }
        return null
    }

    suspend fun changeTeacherPassword(teacherId: Long, currentPass: String, newPass: String): String? {
        val teacher = repository.getTeacherById(teacherId) ?: return "Teacher not found."
        val expectedPass = teacher.passwordHash.ifBlank { "teacher123" }
        if (currentPass != expectedPass) {
            return "Current password is incorrect."
        }
        if (newPass.length < 4) {
            return "New password must be at least 4 characters."
        }
        repository.updateTeacherPassword(teacherId, newPass)
        // Refresh selected teacher if matching
        if (_selectedTeacher.value?.id == teacherId) {
            _selectedTeacher.value = teacher.copy(passwordHash = newPass)
        }
        _userMessage.value = "Password changed successfully."
        return null
    }

    fun resetTeacherPasswordByPrincipal(teacherId: Long, newPass: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateTeacherPassword(teacherId, newPass)
            _userMessage.value = "Teacher password reset successfully."
            onSuccess()
        }
    }

    fun toggleTeacherStatus(teacher: Teacher) {
        viewModelScope.launch {
            val newStatus = !teacher.isActive
            repository.updateTeacherStatus(teacher.id, newStatus)
            _userMessage.value = "Teacher ${teacher.name} account is now ${if (newStatus) "Active" else "Deactivated"}."
        }
    }

    fun saveTeacherWithClass(teacher: Teacher, assignedClassId: Long?, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val teacherId = repository.saveTeacher(teacher)
            repository.assignTeacherToClass(teacherId, assignedClassId)
            _userMessage.value = "Teacher \"${teacher.name}\" saved successfully."
            onSuccess()
        }
    }

    fun setRole(role: UserRole) {
        _currentRole.value = role
        if (role == UserRole.TEACHER) {
            if (_selectedTeacher.value == null && teachers.value.isNotEmpty()) {
                _selectedTeacher.value = teachers.value.first()
            }
            loadTeacherAttendance()
        }
    }

    fun unlockPrincipal(pinEntered: String): Boolean {
        val currentPin = schoolSettings.value?.principalPin ?: "1234"
        val isPinEnabled = schoolSettings.value?.isPinEnabled ?: false
        if (!isPinEnabled || pinEntered == currentPin) {
            _isPrincipalUnlocked.value = true
            return true
        }
        return false
    }

    fun lockPrincipal() {
        _isPrincipalUnlocked.value = false
    }

    fun selectTeacher(teacher: Teacher) {
        _selectedTeacher.value = teacher
        loadTeacherAttendance()
    }

    fun setSelectedDate(date: String) {
        _selectedDate.value = date
        loadTeacherAttendance()
    }

    fun setSelectedMonth(month: String) {
        _selectedMonth.value = month
    }

    fun shiftDate(days: Int) {
        try {
            val cal = Calendar.getInstance()
            val current = dateFormatter.parse(_selectedDate.value) ?: Date()
            cal.time = current
            cal.add(Calendar.DAY_OF_YEAR, days)
            _selectedDate.value = dateFormatter.format(cal.time)
            loadTeacherAttendance()
        } catch (_: Exception) {}
    }

    fun setToday() {
        _selectedDate.value = dateFormatter.format(Date())
        loadTeacherAttendance()
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    // --- Teacher Attendance Handling ---
    fun loadTeacherAttendance() {
        val teacher = _selectedTeacher.value ?: return
        val date = _selectedDate.value

        viewModelScope.launch {
            _teacherAttendanceState.update { it.copy(isLoading = true) }
            val currentClasses = classes.value
            val assignedClass = currentClasses.find { it.teacherId == teacher.id }

            if (assignedClass == null) {
                _teacherAttendanceState.value = TeacherAttendanceState(
                    schoolClass = null,
                    students = emptyList(),
                    isLoading = false
                )
                return@launch
            }

            val classStudents = students.value.filter { it.classId == assignedClass.id }
            val recordFlow = repository.getAttendanceRecord(assignedClass.id, date).first()

            val attendanceMap = mutableMapOf<Long, Boolean>()
            val reasonMap = mutableMapOf<Long, String>()

            if (recordFlow != null) {
                val items = repository.getAttendanceItems(recordFlow.id).first()
                classStudents.forEach { student ->
                    val item = items.find { it.studentId == student.id }
                    val isPres = item?.isPresent ?: true
                    attendanceMap[student.id] = isPres
                    reasonMap[student.id] = item?.absentReason ?: ""
                }
                _teacherAttendanceState.value = TeacherAttendanceState(
                    schoolClass = assignedClass,
                    students = classStudents,
                    attendanceMap = attendanceMap,
                    reasonMap = reasonMap,
                    isSubmitted = recordFlow.isSubmitted,
                    submittedAt = recordFlow.submittedAt,
                    notes = recordFlow.notes,
                    isLoading = false
                )
            } else {
                classStudents.forEach { student ->
                    attendanceMap[student.id] = true
                    reasonMap[student.id] = ""
                }
                _teacherAttendanceState.value = TeacherAttendanceState(
                    schoolClass = assignedClass,
                    students = classStudents,
                    attendanceMap = attendanceMap,
                    reasonMap = reasonMap,
                    isSubmitted = false,
                    submittedAt = null,
                    notes = "",
                    isLoading = false
                )
            }
        }
    }

    fun toggleStudentAttendance(studentId: Long) {
        val current = _teacherAttendanceState.value.attendanceMap[studentId] ?: true
        val updatedMap = _teacherAttendanceState.value.attendanceMap.toMutableMap()
        updatedMap[studentId] = !current
        _teacherAttendanceState.update { it.copy(attendanceMap = updatedMap) }
    }

    fun setStudentPresent(studentId: Long, isPresent: Boolean) {
        val updatedMap = _teacherAttendanceState.value.attendanceMap.toMutableMap()
        updatedMap[studentId] = isPresent
        _teacherAttendanceState.update { it.copy(attendanceMap = updatedMap) }
    }

    fun setStudentAbsentReason(studentId: Long, reason: String) {
        val updatedMap = _teacherAttendanceState.value.reasonMap.toMutableMap()
        updatedMap[studentId] = reason
        _teacherAttendanceState.update { it.copy(reasonMap = updatedMap) }
    }

    fun markAllPresent() {
        val updatedMap = _teacherAttendanceState.value.students.associate { it.id to true }
        _teacherAttendanceState.update { it.copy(attendanceMap = updatedMap) }
    }

    fun markAllAbsent() {
        val updatedMap = _teacherAttendanceState.value.students.associate { it.id to false }
        _teacherAttendanceState.update { it.copy(attendanceMap = updatedMap) }
    }

    fun updateAttendanceNotes(notes: String) {
        _teacherAttendanceState.update { it.copy(notes = notes) }
    }

    fun saveOrSubmitAttendance(isSubmitting: Boolean) {
        val state = _teacherAttendanceState.value
        val assignedClass = state.schoolClass ?: return
        val teacher = _selectedTeacher.value ?: return
        val date = _selectedDate.value

        viewModelScope.launch {
            val studentStatuses = state.students.map { student ->
                val isPres = state.attendanceMap[student.id] ?: true
                val reason = state.reasonMap[student.id] ?: ""
                Pair(student, Pair(isPres, reason))
            }

            repository.saveAndSubmitAttendance(
                classId = assignedClass.id,
                teacherId = teacher.id,
                date = date,
                isSubmitted = isSubmitting,
                notes = state.notes,
                studentStatuses = studentStatuses
            )

            _teacherAttendanceState.update {
                it.copy(
                    isSubmitted = isSubmitting,
                    submittedAt = if (isSubmitting) System.currentTimeMillis() else it.submittedAt
                )
            }

            _userMessage.value = if (isSubmitting) {
                "Attendance successfully submitted to Principal for ${assignedClass.displayName}!"
            } else {
                "Attendance draft saved."
            }
        }
    }

    // --- Teacher Daily Attendance (Marked by Principal or Self) ---
    fun markTeacherAttendance(teacherId: Long, date: String, status: String, notes: String = "") {
        viewModelScope.launch {
            repository.saveTeacherAttendance(
                TeacherAttendanceRecord(
                    teacherId = teacherId,
                    date = date,
                    status = status,
                    notes = notes
                )
            )
            _userMessage.value = "Teacher attendance updated to $status."
        }
    }

    // --- Student-wise Attendance Stats Calculation ---
    suspend fun getStudentStats(studentId: Long): StudentAttendanceStats {
        return repository.getStudentAttendanceStats(studentId)
    }

    // --- CRUD Actions ---

    // Teachers CRUD
    fun saveTeacher(teacher: Teacher, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveTeacher(teacher)
            _userMessage.value = "Teacher \"${teacher.name}\" saved successfully."
            onSuccess()
        }
    }

    fun deleteTeacher(teacher: Teacher) {
        viewModelScope.launch {
            repository.deleteTeacher(teacher)
            _userMessage.value = "Teacher \"${teacher.name}\" removed."
        }
    }

    // Classes CRUD & Teacher Assignment
    fun saveClass(schoolClass: SchoolClass, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveClass(schoolClass)
            _userMessage.value = "Class \"${schoolClass.displayName}\" updated."
            onSuccess()
        }
    }

    fun deleteClass(schoolClass: SchoolClass) {
        viewModelScope.launch {
            repository.deleteClass(schoolClass)
            _userMessage.value = "Class \"${schoolClass.displayName}\" removed."
        }
    }

    fun assignClassTeacher(classId: Long, teacherId: Long?) {
        viewModelScope.launch {
            val targetClass = classes.value.find { it.id == classId }
            if (targetClass != null) {
                repository.saveClass(targetClass.copy(teacherId = teacherId))
                val teacherName = teachers.value.find { it.id == teacherId }?.name ?: "None"
                _userMessage.value = "Assigned ${targetClass.displayName} to $teacherName."
            }
        }
    }

    // Students CRUD
    fun saveStudent(student: Student, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveStudent(student)
            _userMessage.value = "Student \"${student.name}\" details updated."
            onSuccess()
            loadTeacherAttendance()
        }
    }

    fun toggleStudentStatus(student: Student) {
        viewModelScope.launch {
            val newStatus = !student.isActive
            repository.updateStudentStatus(student.id, newStatus)
            _userMessage.value = if (newStatus) {
                "Student \"${student.name}\" activated."
            } else {
                "Student \"${student.name}\" deactivated."
            }
            loadTeacherAttendance()
        }
    }

    fun setStudentStatus(studentId: Long, isActive: Boolean) {
        viewModelScope.launch {
            repository.updateStudentStatus(studentId, isActive)
            _userMessage.value = if (isActive) "Student status set to Active." else "Student status set to Inactive."
            loadTeacherAttendance()
        }
    }

    fun deleteStudent(student: Student) {
        viewModelScope.launch {
            repository.deleteStudent(student)
            _userMessage.value = "Student \"${student.name}\" removed."
            loadTeacherAttendance()
        }
    }

    // Timetables
    fun saveTimetableEntry(entry: TimetableEntry, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveTimetableEntry(entry)
            _userMessage.value = "Timetable slot for ${entry.subject} saved."
            onSuccess()
        }
    }

    fun deleteTimetableEntry(entry: TimetableEntry) {
        viewModelScope.launch {
            repository.deleteTimetableEntry(entry)
            _userMessage.value = "Timetable slot removed."
        }
    }

    // Exams
    fun saveExamSchedule(exam: ExamSchedule, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveExamSchedule(exam)
            _userMessage.value = "Exam schedule for ${exam.subject} saved."
            onSuccess()
        }
    }

    fun deleteExamSchedule(exam: ExamSchedule) {
        viewModelScope.launch {
            repository.deleteExamSchedule(exam)
            _userMessage.value = "Exam schedule removed."
        }
    }

    // School Events & Holidays
    fun saveSchoolEvent(event: SchoolEvent, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveSchoolEvent(event)
            _userMessage.value = "${if (event.isHoliday) "Holiday" else "Event"} \"${event.title}\" saved."
            onSuccess()
        }
    }

    fun deleteSchoolEvent(event: SchoolEvent) {
        viewModelScope.launch {
            repository.deleteSchoolEvent(event)
            _userMessage.value = "Event removed."
        }
    }

    // Homework
    fun addHomework(homework: Homework, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveHomework(homework)
            _userMessage.value = "Homework \"${homework.title}\" posted."
            onSuccess()
        }
    }

    fun deleteHomework(homework: Homework) {
        viewModelScope.launch {
            repository.deleteHomework(homework)
            _userMessage.value = "Homework deleted."
        }
    }

    // Marks
    fun saveMark(mark: StudentMark, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveMark(mark)
            _userMessage.value = "Mark recorded for student."
            onSuccess()
        }
    }

    fun saveBatchMarks(marks: List<StudentMark>, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveMarks(marks)
            _userMessage.value = "Recorded marks for ${marks.size} students."
            onSuccess()
        }
    }

    fun deleteMark(mark: StudentMark) {
        viewModelScope.launch {
            repository.deleteMark(mark)
            _userMessage.value = "Mark entry removed."
        }
    }

    // Announcements
    fun sendAnnouncement(announcement: Announcement, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveAnnouncement(announcement)
            _userMessage.value = "Announcement broadcasted!"
            onSuccess()
        }
    }

    fun deleteAnnouncement(announcement: Announcement) {
        viewModelScope.launch {
            repository.deleteAnnouncement(announcement)
            _userMessage.value = "Announcement removed."
        }
    }

    // Leaves
    fun applyLeave(leave: LeaveApplication, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.applyLeave(leave)
            _userMessage.value = "Leave application submitted to Principal."
            onSuccess()
        }
    }

    fun updateLeaveStatus(leaveId: Long, status: String, principalRemark: String) {
        viewModelScope.launch {
            repository.updateLeaveStatus(leaveId, status, principalRemark)
            _userMessage.value = "Leave application $status."
        }
    }

    // School Settings & Password
    fun updateSchoolSettings(settings: SchoolSettingsEntity, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateSchoolSettings(settings)
            _userMessage.value = "School settings updated successfully."
            onSuccess()
        }
    }

    // Absence Notifications
    fun sendAbsenceNotifications(
        absentStudents: List<AbsentStudentDetail>,
        className: String,
        date: String
    ) {
        viewModelScope.launch {
            val logs = absentStudents.map { student ->
                val reasonText = if (student.reason.isNotBlank()) " Reason: ${student.reason}." else ""
                val message = "Dear Parent, ${student.studentName} ($className, Roll #${student.rollNumber}) was marked ABSENT on $date.$reasonText Please contact school office if needed."
                AbsenceNotificationLog(
                    studentId = student.studentId,
                    studentName = student.studentName,
                    className = className,
                    parentContact = student.parentContact.ifBlank { "+1 555-0100" },
                    date = date,
                    message = message,
                    status = "DELIVERED"
                )
            }
            repository.logAbsenceNotifications(logs)
            _userMessage.value = "Sent absence alerts to parents of ${absentStudents.size} students."
        }
    }

    fun verifyPrincipalPin(pin: String): Boolean {
        val configured = schoolSettings.value?.principalPin?.ifBlank { "1234" } ?: "1234"
        return pin == configured
    }

    // Backup & Restore
    fun exportBackup(context: Context) {
        viewModelScope.launch {
            val json = repository.exportDataAsJson()
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "School_Database_Backup_${SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())}.json")
                putExtra(Intent.EXTRA_TEXT, json)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share School Backup JSON"))
            _userMessage.value = "Backup generated successfully."
        }
    }

    fun importBackup(jsonString: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val success = repository.importDataFromJson(jsonString)
            if (success) {
                _userMessage.value = "Database backup restored successfully!"
                onSuccess()
            } else {
                _userMessage.value = "Failed to restore backup: Invalid JSON format."
            }
        }
    }

    // Quick Communication Intents (Call, SMS, WhatsApp)
    fun makePhoneCall(context: Context, phoneNumber: String) {
        if (phoneNumber.isBlank()) return
        try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${phoneNumber.replace(" ", "")}"))
            context.startActivity(intent)
        } catch (_: Exception) {
            _userMessage.value = "Unable to open phone dialer."
        }
    }

    fun sendSms(context: Context, phoneNumber: String, body: String = "") {
        if (phoneNumber.isBlank()) return
        try {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${phoneNumber.replace(" ", "")}")).apply {
                putExtra("sms_body", body)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            _userMessage.value = "Unable to open SMS app."
        }
    }

    fun shareTextReport(context: Context, title: String, content: String) {
        try {
            val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TITLE, title)
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, content)
                type = "text/plain"
            }
            val shareIntent = Intent.createChooser(sendIntent, "Export Report")
            context.startActivity(shareIntent)
        } catch (_: Exception) {
            _userMessage.value = "Unable to share report."
        }
    }
}
