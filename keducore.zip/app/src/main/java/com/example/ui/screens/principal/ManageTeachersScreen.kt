package com.example.ui.screens.principal

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SchoolClass
import com.example.data.model.Teacher
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatusBadge
import com.example.ui.components.TeacherProfileDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageTeachersScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val teachers by viewModel.teachers.collectAsState()
    val classes by viewModel.classes.collectAsState()

    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingTeacher by remember { mutableStateOf<Teacher?>(null) }
    var teacherToDelete by remember { mutableStateOf<Teacher?>(null) }
    var viewingTeacherProfile by remember { mutableStateOf<Teacher?>(null) }
    var teacherForPasswordReset by remember { mutableStateOf<Teacher?>(null) }
    var teacherForStatusToggle by remember { mutableStateOf<Teacher?>(null) }

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(0) } // 0: All, 1: Active, 2: Deactivated

    val filteredTeachers = remember(teachers, searchQuery, selectedFilter) {
        teachers.filter { teacher ->
            val matchesFilter = when (selectedFilter) {
                1 -> teacher.isActive
                2 -> !teacher.isActive
                else -> true
            }
            val matchesSearch = if (searchQuery.isBlank()) true else {
                teacher.name.contains(searchQuery, ignoreCase = true) ||
                teacher.subject.contains(searchQuery, ignoreCase = true) ||
                teacher.email.contains(searchQuery, ignoreCase = true) ||
                teacher.username.contains(searchQuery, ignoreCase = true) ||
                teacher.employeeId.contains(searchQuery, ignoreCase = true)
            }
            matchesFilter && matchesSearch
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("teacher_search_field"),
                placeholder = { Text("Search by name, username, subject, ID...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Filter Chips (All, Active, Deactivated)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedFilter == 0,
                    onClick = { selectedFilter = 0 },
                    label = { Text("All (${teachers.size})") }
                )
                FilterChip(
                    selected = selectedFilter == 1,
                    onClick = { selectedFilter = 1 },
                    label = { Text("Active (${teachers.count { it.isActive }})") }
                )
                FilterChip(
                    selected = selectedFilter == 2,
                    onClick = { selectedFilter = 2 },
                    label = { Text("Deactivated (${teachers.count { !it.isActive }})") }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Faculty Directory (${filteredTeachers.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${classes.count { it.teacherId != null }} / ${classes.size} classes assigned",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (filteredTeachers.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.PersonSearch,
                    title = if (teachers.isEmpty()) "No Teachers Added" else "No Teachers Found",
                    description = if (teachers.isEmpty()) "Add teachers to create accounts and assign them to classes." else "Try a different search query or filter."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredTeachers, key = { it.id }) { teacher ->
                        val assignedClass = classes.find { it.teacherId == teacher.id }
                        TeacherAccountCard(
                            teacher = teacher,
                            assignedClass = assignedClass,
                            onClick = { viewingTeacherProfile = teacher },
                            onEdit = {
                                editingTeacher = teacher
                                showAddEditDialog = true
                            },
                            onResetPassword = {
                                teacherForPasswordReset = teacher
                            },
                            onToggleStatus = {
                                teacherForStatusToggle = teacher
                            },
                            onDelete = {
                                teacherToDelete = teacher
                            }
                        )
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = {
                editingTeacher = null
                showAddEditDialog = true
            },
            containerColor = PrimaryNavy,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("add_teacher_fab")
        ) {
            Icon(Icons.Default.PersonAdd, contentDescription = "Add Teacher")
        }
    }

    // Teacher Profile Dialog
    viewingTeacherProfile?.let { teacher ->
        val assignedClass = classes.find { it.teacherId == teacher.id }
        TeacherProfileDialog(
            teacher = teacher,
            assignedClass = assignedClass,
            viewModel = viewModel,
            onDismiss = { viewingTeacherProfile = null },
            onEdit = {
                viewingTeacherProfile = null
                editingTeacher = teacher
                showAddEditDialog = true
            }
        )
    }

    if (showAddEditDialog) {
        val currentAssignedClass = classes.find { it.teacherId == editingTeacher?.id }
        AddEditTeacherDialog(
            teacher = editingTeacher,
            availableClasses = classes,
            currentClassId = currentAssignedClass?.id,
            onDismiss = { showAddEditDialog = false },
            onSave = { teacher, selectedClassId ->
                viewModel.saveTeacherWithClass(
                    teacher = teacher,
                    assignedClassId = selectedClassId,
                    onSuccess = { showAddEditDialog = false }
                )
            }
        )
    }

    // Reset Teacher Password Dialog
    teacherForPasswordReset?.let { teacher ->
        ResetTeacherPasswordDialog(
            teacher = teacher,
            onDismiss = { teacherForPasswordReset = null },
            onConfirm = { newPass ->
                viewModel.resetTeacherPasswordByPrincipal(teacher.id, newPass)
                teacherForPasswordReset = null
            }
        )
    }

    // Status Toggle Confirmation Dialog
    teacherForStatusToggle?.let { teacher ->
        val isDeactivating = teacher.isActive
        AlertDialog(
            onDismissRequest = { teacherForStatusToggle = null },
            title = {
                Text(if (isDeactivating) "Deactivate Teacher Account?" else "Activate Teacher Account?")
            },
            text = {
                Text(
                    if (isDeactivating)
                        "Are you sure you want to deactivate ${teacher.name}'s account? They will not be able to log in to the faculty portal until reactivated."
                    else
                        "Activate ${teacher.name}'s account to restore their login access to the teacher portal."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.toggleTeacherStatus(teacher)
                        teacherForStatusToggle = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDeactivating) MaterialTheme.colorScheme.error else PrimaryNavy
                    )
                ) {
                    Text(if (isDeactivating) "Deactivate" else "Activate")
                }
            },
            dismissButton = {
                TextButton(onClick = { teacherForStatusToggle = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (teacherToDelete != null) {
        ConfirmDeleteDialog(
            title = "Delete Teacher?",
            message = "Are you sure you want to remove ${teacherToDelete?.name}? If they are assigned as a class teacher, the class will become unassigned.",
            onConfirm = {
                teacherToDelete?.let { viewModel.deleteTeacher(it) }
                teacherToDelete = null
            },
            onDismiss = { teacherToDelete = null }
        )
    }
}

@Composable
fun TeacherAccountCard(
    teacher: Teacher,
    assignedClass: SchoolClass?,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onResetPassword: () -> Unit,
    onToggleStatus: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("teacher_card_${teacher.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            1.dp,
            if (teacher.isActive) MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
            else MaterialTheme.colorScheme.error.copy(alpha = 0.4f)
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Avatar
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(if (teacher.isActive) PrimaryNavy else Color.Gray),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = teacher.name.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString(""),
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = teacher.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = teacher.employeeId.ifBlank { "EMP-${teacher.id}" },
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Subject: ${teacher.subject}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "• @${teacher.username.ifBlank { teacher.email.substringBefore("@") }}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Action Menu
                Box {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.testTag("teacher_menu_${teacher.id}")
                    ) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Teacher Actions")
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("View Full Profile") },
                            onClick = {
                                menuExpanded = false
                                onClick()
                            },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
                        )
                        DropdownMenuItem(
                            text = { Text("Edit Details & Access") },
                            onClick = {
                                menuExpanded = false
                                onEdit()
                            },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) }
                        )
                        DropdownMenuItem(
                            text = { Text("Reset Password") },
                            onClick = {
                                menuExpanded = false
                                onResetPassword()
                            },
                            leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) }
                        )
                        DropdownMenuItem(
                            text = {
                                Text(
                                    if (teacher.isActive) "Deactivate Account" else "Activate Account",
                                    color = if (teacher.isActive) MaterialTheme.colorScheme.error else PresentGreen
                                )
                            },
                            onClick = {
                                menuExpanded = false
                                onToggleStatus()
                            },
                            leadingIcon = {
                                Icon(
                                    if (teacher.isActive) Icons.Default.Block else Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = if (teacher.isActive) MaterialTheme.colorScheme.error else PresentGreen
                                )
                            }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Delete Teacher", color = MaterialTheme.colorScheme.error) },
                            onClick = {
                                menuExpanded = false
                                onDelete()
                            },
                            leadingIcon = { Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Badges Row: Class Assignment + Account Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (assignedClass != null) {
                    StatusBadge(
                        text = "Class: ${assignedClass.displayName}",
                        containerColor = PresentGreenContainer.copy(alpha = 0.6f),
                        contentColor = PresentGreen,
                        icon = Icons.Default.Class
                    )
                } else {
                    StatusBadge(
                        text = "No Class Assigned",
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                StatusBadge(
                    text = if (teacher.isActive) "Active Account" else "Deactivated",
                    containerColor = if (teacher.isActive) PresentGreenContainer else AbsentRedContainer,
                    contentColor = if (teacher.isActive) PresentGreen else AbsentRed,
                    icon = if (teacher.isActive) Icons.Default.CheckCircle else Icons.Default.Cancel
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditTeacherDialog(
    teacher: Teacher?,
    availableClasses: List<SchoolClass>,
    currentClassId: Long?,
    onDismiss: () -> Unit,
    onSave: (Teacher, Long?) -> Unit
) {
    var name by remember { mutableStateOf(teacher?.name ?: "") }
    var email by remember { mutableStateOf(teacher?.email ?: "") }
    var phone by remember { mutableStateOf(teacher?.phone ?: "") }
    var subject by remember { mutableStateOf(teacher?.subject ?: "") }
    var employeeId by remember { mutableStateOf(teacher?.employeeId ?: "") }
    var qualification by remember { mutableStateOf(teacher?.qualification ?: "") }
    var assignedSubjects by remember { mutableStateOf(teacher?.assignedSubjects ?: "") }
    var address by remember { mutableStateOf(teacher?.address ?: "") }

    // Account Credentials
    var username by remember {
        mutableStateOf(
            teacher?.username ?: if (name.isNotBlank()) name.lowercase().replace(" ", ".") else ""
        )
    }
    var password by remember { mutableStateOf(teacher?.passwordHash ?: "teacher123") }
    var passwordVisible by remember { mutableStateOf(false) }
    var isActive by remember { mutableStateOf(teacher?.isActive ?: true) }

    // Class Assignment Selection (null = none)
    var selectedClassId by remember { mutableStateOf<Long?>(currentClassId) }
    var classDropdownExpanded by remember { mutableStateOf(false) }

    var nameError by remember { mutableStateOf(false) }
    var subjectError by remember { mutableStateOf(false) }
    var usernameError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (teacher == null) "Create Teacher Account" else "Edit Teacher Profile & Access",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Personal & Academic Header
                item {
                    Text(
                        text = "Personal & Academic Information",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = {
                            name = it
                            nameError = it.isBlank()
                            if (teacher == null && username.isBlank()) {
                                username = it.lowercase().trim().replace("\\s+".toRegex(), ".")
                            }
                        },
                        label = { Text("Teacher Full Name *") },
                        isError = nameError,
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_teacher_name")
                    )
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = subject,
                            onValueChange = {
                                subject = it
                                subjectError = it.isBlank()
                            },
                            label = { Text("Primary Subject *") },
                            isError = subjectError,
                            singleLine = true,
                            modifier = Modifier.weight(1.2f).testTag("input_teacher_subject")
                        )
                        OutlinedTextField(
                            value = employeeId,
                            onValueChange = { employeeId = it },
                            label = { Text("Emp ID") },
                            placeholder = { Text("EMP-105") },
                            singleLine = true,
                            modifier = Modifier.weight(0.8f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = assignedSubjects,
                        onValueChange = { assignedSubjects = it },
                        label = { Text("Teaching Subjects (e.g. Algebra, Calculus)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Class Assignment Dropdown
                item {
                    Text(
                        text = "Class Teacher Assignment",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                item {
                    ExposedDropdownMenuBox(
                        expanded = classDropdownExpanded,
                        onExpandedChange = { classDropdownExpanded = !classDropdownExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val selectedClassName = availableClasses.find { it.id == selectedClassId }?.displayName
                            ?: "No Class Assigned (Subject Teacher Only)"

                        OutlinedTextField(
                            value = selectedClassName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Assigned Class") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = classDropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )

                        ExposedDropdownMenu(
                            expanded = classDropdownExpanded,
                            onDismissRequest = { classDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("None (Subject Teacher Only)") },
                                onClick = {
                                    selectedClassId = null
                                    classDropdownExpanded = false
                                }
                            )
                            availableClasses.forEach { schoolClass ->
                                val isAssignedToOther = schoolClass.teacherId != null && schoolClass.teacherId != teacher?.id
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(schoolClass.displayName, fontWeight = FontWeight.SemiBold)
                                            if (isAssignedToOther) {
                                                Text("(Will replace existing teacher)", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                                            }
                                        }
                                    },
                                    onClick = {
                                        selectedClassId = schoolClass.id
                                        classDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Login Credentials Section
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Portal Login Credentials & Access",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                item {
                    OutlinedTextField(
                        value = username,
                        onValueChange = {
                            username = it
                            usernameError = it.isBlank()
                        },
                        label = { Text("Username for Login *") },
                        placeholder = { Text("e.g. robert.smith") },
                        isError = usernameError,
                        leadingIcon = { Icon(Icons.Default.AccountCircle, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_teacher_username")
                    )
                }

                item {
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password *") },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle password"
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_teacher_password")
                    )
                }

                item {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Account Active Status", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("Allow teacher to sign in to portal", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(
                                checked = isActive,
                                onCheckedChange = { isActive = it }
                            )
                        }
                    }
                }

                // Contact Details Section
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Contact Details",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("Phone") },
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("input_teacher_phone")
                        )
                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Email") },
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("input_teacher_email")
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = qualification,
                        onValueChange = { qualification = it },
                        label = { Text("Academic Qualification (e.g. M.Sc, B.Ed)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Residential Address") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) nameError = true
                    if (subject.isBlank()) subjectError = true
                    if (username.isBlank()) usernameError = true

                    if (name.isNotBlank() && subject.isNotBlank() && username.isNotBlank()) {
                        onSave(
                            Teacher(
                                id = teacher?.id ?: 0L,
                                name = name.trim(),
                                email = email.trim().ifBlank { "${username.trim()}@school.edu" },
                                phone = phone.trim(),
                                subject = subject.trim(),
                                employeeId = employeeId.trim().ifBlank { "EMP-${(teacher?.id?.takeIf { it > 0 } ?: (System.currentTimeMillis() % 900 + 100))}" },
                                qualification = qualification.trim().ifBlank { "B.Ed, Bachelor's Degree" },
                                assignedSubjects = assignedSubjects.trim(),
                                address = address.trim(),
                                username = username.trim(),
                                passwordHash = password.trim().ifBlank { "teacher123" },
                                isActive = isActive
                            ),
                            selectedClassId
                        )
                    }
                },
                modifier = Modifier.testTag("save_teacher_button")
            ) {
                Text(if (teacher == null) "Create Teacher Account" else "Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun ResetTeacherPasswordDialog(
    teacher: Teacher,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Reset Password for ${teacher.name}", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Set a new login password for faculty username: @${teacher.username.ifBlank { teacher.email.substringBefore("@") }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (error != null) {
                    Text(
                        text = error ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                OutlinedTextField(
                    value = newPassword,
                    onValueChange = {
                        newPassword = it
                        error = null
                    },
                    label = { Text("New Password") },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = null
                            )
                        }
                    },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("reset_pass_input")
                )

                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = {
                        confirmPassword = it
                        error = null
                    },
                    label = { Text("Confirm New Password") },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("reset_pass_confirm_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (newPassword.length < 4) {
                        error = "Password must be at least 4 characters."
                    } else if (newPassword != confirmPassword) {
                        error = "Passwords do not match."
                    } else {
                        onConfirm(newPassword)
                    }
                }
            ) {
                Text("Set Password")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
