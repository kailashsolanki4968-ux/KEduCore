package com.example.ui.screens.academics

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SchoolClass
import com.example.data.model.Student
import com.example.data.model.StudentMark
import com.example.ui.components.EmptyStateView
import com.example.ui.components.ReportCardDialog
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel
import com.example.ui.viewmodel.UserRole
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AcademicResultsAndReportsScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentRole by viewModel.currentRole.collectAsState()
    val classes by viewModel.classes.collectAsState()
    val students by viewModel.students.collectAsState()
    val allMarks by viewModel.allMarks.collectAsState()

    var selectedClassId by remember { mutableStateOf<Long?>(null) }
    var selectedSubjectFilter by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    var studentForReportCard by remember { mutableStateOf<Student?>(null) }
    var showEnterMarksDialog by remember { mutableStateOf(false) }

    LaunchedEffect(classes) {
        if (selectedClassId == null && classes.isNotEmpty()) {
            selectedClassId = classes.first().id
        }
    }

    val distinctSubjects = remember(allMarks) {
        allMarks.map { it.subject }.distinct().filter { it.isNotBlank() }
    }

    val filteredMarks = remember(allMarks, selectedClassId, selectedSubjectFilter, searchQuery, students) {
        allMarks.filter { mark ->
            val matchesClass = selectedClassId == null || mark.classId == selectedClassId
            val matchesSubject = selectedSubjectFilter == null || mark.subject.equals(selectedSubjectFilter, ignoreCase = true)
            val student = students.find { it.id == mark.studentId }
            val matchesSearch = searchQuery.isBlank() || (student?.name?.contains(searchQuery, ignoreCase = true) == true || mark.subject.contains(searchQuery, ignoreCase = true))
            matchesClass && matchesSubject && matchesSearch
        }
    }

    // Analytics summary
    val totalMarksCount = filteredMarks.size
    val averageScore = remember(filteredMarks) {
        if (totalMarksCount > 0) {
            val totalPct = filteredMarks.sumOf { (it.obtainedMarks.toDouble() / it.maxMarks.toDouble()) * 100.0 }
            (totalPct / totalMarksCount).toInt()
        } else 0
    }
    val highestScore = remember(filteredMarks) {
        filteredMarks.maxOfOrNull { it.obtainedMarks } ?: 0
    }
    val passingCount = remember(filteredMarks) {
        filteredMarks.count { (it.obtainedMarks.toFloat() / it.maxMarks.toFloat()) >= 0.5f }
    }
    val passRate = remember(totalMarksCount, passingCount) {
        if (totalMarksCount > 0) ((passingCount.toFloat() / totalMarksCount.toFloat()) * 100).toInt() else 100
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showEnterMarksDialog = true },
                containerColor = PrimaryNavy,
                contentColor = Color.White,
                modifier = Modifier.testTag("record_marks_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Enter Marks")
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header & Export
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Academic Results & Reports",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Subject-wise assessments & student report cards",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                FilledTonalButton(
                    onClick = {
                        val content = buildString {
                            appendLine("=== SUBJECT-WISE RESULTS & PERFORMANCE REPORT ===")
                            appendLine("Generated: ${SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())}")
                            appendLine("Class: ${classes.find { it.id == selectedClassId }?.displayName ?: "All"}")
                            appendLine("Average Score: $averageScore% | Pass Rate: $passRate% | Highest: $highestScore")
                            appendLine("----------------------------------------")
                            filteredMarks.forEach { m ->
                                val st = students.find { it.id == m.studentId }
                                appendLine("${st?.name ?: "Student"} (Roll #${st?.rollNumber ?: ""}): ${m.subject} = ${m.obtainedMarks}/${m.maxMarks} [${m.assessmentName}] - ${m.remarks}")
                            }
                        }
                        viewModel.shareTextReport(context, "Academic_Results_Report", content)
                    },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("export_results_btn")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Export", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Class Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(classes) { c ->
                    FilterChip(
                        selected = selectedClassId == c.id,
                        onClick = { selectedClassId = c.id },
                        label = { Text(c.displayName, fontSize = 12.sp) },
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Subject Filter Chips
            if (distinctSubjects.isNotEmpty()) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = selectedSubjectFilter == null,
                            onClick = { selectedSubjectFilter = null },
                            label = { Text("All Subjects", fontSize = 11.sp) }
                        )
                    }
                    items(distinctSubjects) { subj ->
                        FilterChip(
                            selected = selectedSubjectFilter == subj,
                            onClick = { selectedSubjectFilter = subj },
                            label = { Text(subj, fontSize = 11.sp) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // High level Analytics Card
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Average", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$averageScore%", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Pass Rate", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$passRate%", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = PresentGreen)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Highest", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$highestScore pts", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.secondary)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Assessments", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$totalMarksCount", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Marks List
            if (filteredMarks.isEmpty()) {
                EmptyStateView(
                    title = "No Marks Recorded",
                    description = "Tap + to enter marks and generate subject reports.",
                    icon = Icons.Default.Grade
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredMarks) { mark ->
                        val student = students.find { it.id == mark.studentId }
                        val pct = (mark.obtainedMarks.toFloat() / mark.maxMarks.toFloat()) * 100f
                        val grade = if (pct >= 90) "A+" else if (pct >= 80) "A" else if (pct >= 70) "B" else if (pct >= 60) "C" else "D"

                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (student != null) {
                                        studentForReportCard = student
                                    }
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(if (pct >= 75f) PresentGreenContainer else if (pct >= 50f) PendingAmberContainer else AbsentRedContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = grade,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (pct >= 75f) PresentGreen else if (pct >= 50f) PendingAmber else AbsentRed
                                    )
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(student?.name ?: "Student", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text("• Roll #${student?.rollNumber ?: ""}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text(
                                        text = "${mark.subject} (${mark.assessmentName})",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    if (mark.remarks.isNotBlank()) {
                                        Text(
                                            text = mark.remarks,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "${mark.obtainedMarks}/${mark.maxMarks}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = "${pct.toInt()}%",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Report Card Dialog
    studentForReportCard?.let { st ->
        val cl = classes.find { it.id == st.classId }
        ReportCardDialog(
            student = st,
            schoolClass = cl,
            viewModel = viewModel,
            onDismiss = { studentForReportCard = null }
        )
    }

    if (showEnterMarksDialog) {
        EnterMarkDialog(
            classes = classes,
            students = students,
            defaultClassId = selectedClassId ?: classes.firstOrNull()?.id ?: 1,
            onDismiss = { showEnterMarksDialog = false },
            onSave = { newMark ->
                viewModel.saveMark(newMark) {
                    showEnterMarksDialog = false
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnterMarkDialog(
    classes: List<SchoolClass>,
    students: List<Student>,
    defaultClassId: Long,
    onDismiss: () -> Unit,
    onSave: (StudentMark) -> Unit
) {
    var selectedClassId by remember { mutableStateOf(defaultClassId) }
    val classStudents = remember(students, selectedClassId) {
        students.filter { it.classId == selectedClassId }
    }
    var selectedStudentId by remember { mutableStateOf(classStudents.firstOrNull()?.id ?: 0L) }
    var subject by remember { mutableStateOf("Mathematics") }
    var assessmentName by remember { mutableStateOf("Mid-Term Exam") }
    var maxMarks by remember { mutableIntStateOf(100) }
    var obtainedMarks by remember { mutableIntStateOf(85) }
    var remarks by remember { mutableStateOf("Good performance") }

    LaunchedEffect(classStudents) {
        if (classStudents.isNotEmpty() && !classStudents.any { it.id == selectedStudentId }) {
            selectedStudentId = classStudents.first().id
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Enter Student Mark", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Class Selector
                Text("Select Class:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(classes) { c ->
                        FilterChip(
                            selected = selectedClassId == c.id,
                            onClick = { selectedClassId = c.id },
                            label = { Text(c.displayName, fontSize = 11.sp) }
                        )
                    }
                }

                // Student Selector
                Text("Select Student:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(classStudents) { st ->
                        FilterChip(
                            selected = selectedStudentId == st.id,
                            onClick = { selectedStudentId = st.id },
                            label = { Text("${st.name} (#${st.rollNumber})", fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject (e.g. Science, Math)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = assessmentName,
                    onValueChange = { assessmentName = it },
                    label = { Text("Assessment (e.g. Unit Test 1)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = "$obtainedMarks",
                        onValueChange = { obtainedMarks = it.toIntOrNull() ?: 0 },
                        label = { Text("Marks Obtained") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = "$maxMarks",
                        onValueChange = { maxMarks = it.toIntOrNull() ?: 100 },
                        label = { Text("Max Marks") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = remarks,
                    onValueChange = { remarks = it },
                    label = { Text("Teacher Remarks") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedStudentId > 0 && subject.isNotBlank()) {
                        onSave(
                            StudentMark(
                                classId = selectedClassId,
                                studentId = selectedStudentId,
                                subject = subject.trim(),
                                assessmentName = assessmentName.trim(),
                                maxMarks = maxMarks,
                                obtainedMarks = obtainedMarks,
                                remarks = remarks.trim(),
                                date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                            )
                        )
                    }
                },
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Save Mark")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
