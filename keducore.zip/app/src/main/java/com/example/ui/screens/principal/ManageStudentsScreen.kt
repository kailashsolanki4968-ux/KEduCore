package com.example.ui.screens.principal

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SchoolClass
import com.example.data.model.Student
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageStudentsScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val students by viewModel.students.collectAsState()
    val classes by viewModel.classes.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedClassFilter by remember { mutableStateOf<Long?>(null) } // null = All classes

    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingStudent by remember { mutableStateOf<Student?>(null) }
    var studentToDelete by remember { mutableStateOf<Student?>(null) }
    var viewingProfileStudent by remember { mutableStateOf<Student?>(null) }
    var viewingReportCardStudent by remember { mutableStateOf<Student?>(null) }

    val filteredStudents = remember(students, searchQuery, selectedClassFilter) {
        students.filter { student ->
            val matchesClass = selectedClassFilter == null || student.classId == selectedClassFilter
            val matchesSearch = searchQuery.isBlank() ||
                student.name.contains(searchQuery, ignoreCase = true) ||
                student.rollNumber.contains(searchQuery, ignoreCase = true) ||
                student.parentContact.contains(searchQuery, ignoreCase = true) ||
                student.parentName.contains(searchQuery, ignoreCase = true)
            matchesClass && matchesSearch
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Search and Class Filter
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("student_search_field"),
                placeholder = { Text("Search by name, roll no, or parent...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Class Filter Horizontal Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedClassFilter == null,
                        onClick = { selectedClassFilter = null },
                        label = { Text("All Classes (${students.size})", fontSize = 12.sp) }
                    )
                }
                items(classes) { c ->
                    val count = students.count { it.classId == c.id }
                    FilterChip(
                        selected = selectedClassFilter == c.id,
                        onClick = { selectedClassFilter = c.id },
                        label = { Text("${c.displayName} ($count)", fontSize = 12.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (filteredStudents.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.PersonSearch,
                    title = if (students.isEmpty()) "No Students Registered" else "No Students Match Filter",
                    description = if (students.isEmpty()) "Add students to assign them to classes and record attendance." else "Try adjusting your search query or class filter."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredStudents, key = { it.id }) { student ->
                        val studentClass = classes.find { it.id == student.classId }
                        StudentItemCard(
                            student = student,
                            schoolClass = studentClass,
                            onClick = { viewingProfileStudent = student },
                            onEdit = {
                                editingStudent = student
                                showAddEditDialog = true
                            },
                            onToggleStatus = {
                                viewModel.toggleStudentStatus(student)
                            },
                            onDelete = {
                                studentToDelete = student
                            }
                        )
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = {
                editingStudent = null
                showAddEditDialog = true
            },
            containerColor = PrimaryNavy,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("add_student_fab")
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Student")
        }
    }

    // Full Profile Dialog
    viewingProfileStudent?.let { student ->
        StudentProfileDialog(
            student = student,
            classes = classes,
            viewModel = viewModel,
            onDismiss = { viewingProfileStudent = null },
            onEdit = {
                viewingProfileStudent = null
                editingStudent = student
                showAddEditDialog = true
            },
            onGenerateReportCard = { st ->
                viewingProfileStudent = null
                viewingReportCardStudent = st
            }
        )
    }

    // Report Card Dialog
    viewingReportCardStudent?.let { student ->
        val sc = classes.find { it.id == student.classId }
        ReportCardDialog(
            student = student,
            schoolClass = sc,
            viewModel = viewModel,
            onDismiss = { viewingReportCardStudent = null }
        )
    }

    if (showAddEditDialog) {
        AddEditStudentDialog(
            student = editingStudent,
            classes = classes,
            defaultClassId = selectedClassFilter,
            onDismiss = { showAddEditDialog = false },
            onSave = { student ->
                viewModel.saveStudent(student)
                showAddEditDialog = false
            }
        )
    }

    if (studentToDelete != null) {
        ConfirmDeleteDialog(
            title = "Delete Student?",
            message = "Are you sure you want to remove ${studentToDelete?.name} (Roll #${studentToDelete?.rollNumber})? This will also remove their attendance and marks history.",
            onConfirm = {
                studentToDelete?.let { viewModel.deleteStudent(it) }
                studentToDelete = null
            },
            onDismiss = { studentToDelete = null }
        )
    }
}

@Composable
fun StudentItemCard(
    student: Student,
    schoolClass: SchoolClass?,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onToggleStatus: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("student_card_${student.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (student.isActive) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        border = BorderStroke(
            1.dp,
            if (student.isActive) MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f) else AbsentRed.copy(alpha = 0.3f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Student Avatar
            StudentAvatar(
                avatarKey = student.photoAvatar,
                gender = student.gender,
                size = 44
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = student.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (student.isActive) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "#${student.rollNumber}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StatusBadge(
                        text = schoolClass?.displayName ?: "Unassigned",
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        contentColor = MaterialTheme.colorScheme.primary,
                        icon = Icons.Default.School
                    )

                    Surface(
                        color = if (student.isActive) PresentGreenContainer else AbsentRedContainer,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = if (student.isActive) "Active" else "Inactive",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (student.isActive) PresentGreen else AbsentRed,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }

                    if (student.bloodGroup.isNotBlank()) {
                        Text(
                            text = "• ${student.bloodGroup}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (student.parentContact.isNotBlank() || student.parentName.isNotBlank()) {
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Guardian: ${student.parentName.ifBlank { "Parent" }} (${student.parentContact})",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onToggleStatus,
                    modifier = Modifier.size(32.dp).testTag("toggle_status_${student.id}")
                ) {
                    Icon(
                        imageVector = if (student.isActive) Icons.Default.Block else Icons.Default.CheckCircleOutline,
                        contentDescription = if (student.isActive) "Deactivate Student" else "Activate Student",
                        tint = if (student.isActive) MaterialTheme.colorScheme.onSurfaceVariant else PresentGreen,
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(onClick = onEdit, modifier = Modifier.size(32.dp).testTag("edit_student_${student.id}")) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit Student", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp).testTag("delete_student_${student.id}")) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Student", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditStudentDialog(
    student: Student?,
    classes: List<SchoolClass>,
    defaultClassId: Long?,
    onDismiss: () -> Unit,
    onSave: (Student) -> Unit
) {
    var name by remember { mutableStateOf(student?.name ?: "") }
    var rollNumber by remember { mutableStateOf(student?.rollNumber ?: "") }
    var parentName by remember { mutableStateOf(student?.parentName ?: "") }
    var parentContact by remember { mutableStateOf(student?.parentContact ?: "") }
    var guardianRelation by remember { mutableStateOf(student?.guardianRelation ?: "Father") }
    var gender by remember { mutableStateOf(student?.gender ?: "Male") }
    var bloodGroup by remember { mutableStateOf(student?.bloodGroup ?: "O+") }
    var dateOfBirth by remember { mutableStateOf(student?.dateOfBirth ?: "2010-05-15") }
    var admissionDate by remember { mutableStateOf(student?.admissionDate ?: "2022-04-01") }
    var address by remember { mutableStateOf(student?.address ?: "") }
    var isActive by remember { mutableStateOf(student?.isActive ?: true) }
    var selectedClassId by remember {
        mutableStateOf(student?.classId ?: defaultClassId ?: classes.firstOrNull()?.id ?: 0L)
    }

    var nameError by remember { mutableStateOf(false) }
    var rollError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = if (student == null) "Register New Student" else "Edit Official Student Record",
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Principal / Administrative Authority",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = {
                            name = it
                            nameError = it.isBlank()
                        },
                        label = { Text("Student Full Name *") },
                        isError = nameError,
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_student_name")
                    )
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = rollNumber,
                            onValueChange = {
                                rollNumber = it
                                rollError = it.isBlank()
                            },
                            label = { Text("Roll No *") },
                            isError = rollError,
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("input_student_roll")
                        )
                        OutlinedTextField(
                            value = bloodGroup,
                            onValueChange = { bloodGroup = it },
                            label = { Text("Blood Group") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Text("Assign to Class & Section:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    if (classes.isEmpty()) {
                        Text("No classes configured. Please create a class first.", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                    } else {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(classes) { c ->
                                FilterChip(
                                    selected = selectedClassId == c.id,
                                    onClick = { selectedClassId = c.id },
                                    label = { Text(c.displayName, fontSize = 11.sp) },
                                    leadingIcon = if (selectedClassId == c.id) {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                    } else null
                                )
                            }
                        }
                    }
                }

                item {
                    Text("Account Status:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = isActive,
                            onClick = { isActive = true },
                            label = { Text("Active Enrollment", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PresentGreenContainer,
                                selectedLabelColor = PresentGreen
                            )
                        )
                        FilterChip(
                            selected = !isActive,
                            onClick = { isActive = false },
                            label = { Text("Deactivated / Inactive", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AbsentRedContainer,
                                selectedLabelColor = AbsentRed
                            )
                        )
                    }
                }

                item {
                    Text("Gender:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Male", "Female", "Other").forEach { g ->
                            FilterChip(
                                selected = gender == g,
                                onClick = { gender = g },
                                label = { Text(g, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = parentName,
                        onValueChange = { parentName = it },
                        label = { Text("Parent / Guardian Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = parentContact,
                            onValueChange = { parentContact = it },
                            label = { Text("Parent Phone") },
                            singleLine = true,
                            modifier = Modifier.weight(1.3f).testTag("input_parent_contact")
                        )
                        OutlinedTextField(
                            value = guardianRelation,
                            onValueChange = { guardianRelation = it },
                            label = { Text("Relation") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = dateOfBirth,
                            onValueChange = { dateOfBirth = it },
                            label = { Text("Date of Birth") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = admissionDate,
                            onValueChange = { admissionDate = it },
                            label = { Text("Admission Date") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Residential Address") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) nameError = true
                    if (rollNumber.isBlank()) rollError = true

                    if (name.isNotBlank() && rollNumber.isNotBlank()) {
                        onSave(
                            Student(
                                id = student?.id ?: 0L,
                                name = name.trim(),
                                rollNumber = rollNumber.trim(),
                                classId = selectedClassId,
                                parentContact = parentContact.trim(),
                                gender = gender,
                                parentName = parentName.trim(),
                                guardianRelation = guardianRelation.trim(),
                                bloodGroup = bloodGroup.trim(),
                                dateOfBirth = dateOfBirth.trim(),
                                admissionDate = admissionDate.trim(),
                                address = address.trim(),
                                isActive = isActive
                            )
                        )
                    }
                },
                modifier = Modifier.testTag("save_student_button")
            ) {
                Text("Save Official Record")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
