package com.example.ui.screens.academics

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExamSchedule
import com.example.data.model.SchoolClass
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel
import com.example.ui.viewmodel.UserRole
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExamTimetableScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentRole by viewModel.currentRole.collectAsState()
    val classes by viewModel.classes.collectAsState()
    val allExams by viewModel.allExams.collectAsState()

    var selectedClassFilter by remember { mutableStateOf<Long?>(null) } // null = All classes
    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingExam by remember { mutableStateOf<ExamSchedule?>(null) }

    val filteredExams = remember(allExams, selectedClassFilter) {
        allExams.filter { exam ->
            selectedClassFilter == null || exam.classId == selectedClassFilter
        }.sortedBy { it.examDate }
    }

    Scaffold(
        floatingActionButton = {
            if (currentRole == UserRole.PRINCIPAL) {
                FloatingActionButton(
                    onClick = {
                        editingExam = null
                        showAddEditDialog = true
                    },
                    containerColor = PrimaryNavy,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("add_exam_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Exam")
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header & Export
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Exam Timetable & Datesheet",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${filteredExams.size} Scheduled Papers",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                FilledTonalButton(
                    onClick = {
                        val content = buildString {
                            appendLine("=== SCHOOL EXAM TIMETABLE / DATESHEET ===")
                            appendLine("Generated: ${SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())}")
                            appendLine("----------------------------------------")
                            filteredExams.forEach { exam ->
                                val cName = classes.find { it.id == exam.classId }?.displayName ?: "All Grades"
                                appendLine("Date: ${exam.examDate} (${exam.startTime} - ${exam.endTime})")
                                appendLine("Exam: ${exam.examName} | Class: $cName")
                                appendLine("Subject: ${exam.subject} | Max Marks: ${exam.maxMarks} | Room: ${exam.roomNumber}")
                                if (exam.instructions.isNotBlank()) appendLine("Instructions: ${exam.instructions}")
                                appendLine("----------------------------------------")
                            }
                        }
                        viewModel.shareTextReport(context, "Exam_Datesheet", content)
                    },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("export_exam_timetable_btn")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Export", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Class Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedClassFilter == null,
                        onClick = { selectedClassFilter = null },
                        label = { Text("All Classes", fontSize = 12.sp) },
                        shape = RoundedCornerShape(8.dp)
                    )
                }
                items(classes) { c ->
                    FilterChip(
                        selected = selectedClassFilter == c.id,
                        onClick = { selectedClassFilter = c.id },
                        label = { Text(c.displayName, fontSize = 12.sp) },
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (filteredExams.isEmpty()) {
                EmptyStateView(
                    title = "No Exams Scheduled",
                    description = "Exam papers and datesheet entries will appear here.",
                    icon = Icons.Default.EventNote
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredExams) { exam ->
                        val schoolClass = classes.find { it.id == exam.classId }

                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = exam.examName,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }

                                    StatusBadge(
                                        text = schoolClass?.displayName ?: "Class",
                                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                                        contentColor = MaterialTheme.colorScheme.secondary
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(SecondaryTealLight.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.MenuBook, contentDescription = null, tint = SecondaryTeal)
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = exam.subject,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Text(
                                                text = "📅 ${exam.examDate}",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Text(
                                                text = "⏰ ${exam.startTime} - ${exam.endTime}",
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Room: ${exam.roomNumber.ifBlank { "Main Hall" }}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("Max Marks: ${exam.maxMarks}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }

                                if (exam.instructions.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Note: ${exam.instructions}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                    )
                                }

                                if (currentRole == UserRole.PRINCIPAL) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TextButton(
                                            onClick = {
                                                editingExam = exam
                                                showAddEditDialog = true
                                            }
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Edit", fontSize = 12.sp)
                                        }

                                        TextButton(
                                            onClick = { viewModel.deleteExamSchedule(exam) },
                                            colors = ButtonDefaults.textButtonColors(contentColor = AbsentRed)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Delete", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddEditDialog) {
        AddEditExamDialog(
            exam = editingExam,
            classes = classes,
            onDismiss = { showAddEditDialog = false },
            onSave = { newExam ->
                viewModel.saveExamSchedule(newExam) {
                    showAddEditDialog = false
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditExamDialog(
    exam: ExamSchedule?,
    classes: List<SchoolClass>,
    onDismiss: () -> Unit,
    onSave: (ExamSchedule) -> Unit
) {
    var examName by remember { mutableStateOf(exam?.examName ?: "Mid-Term Examination 2026") }
    var selectedClassId by remember { mutableStateOf(exam?.classId ?: classes.firstOrNull()?.id ?: 1) }
    var subject by remember { mutableStateOf(exam?.subject ?: "") }
    var examDate by remember { mutableStateOf(exam?.examDate ?: SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }
    var startTime by remember { mutableStateOf(exam?.startTime ?: "09:00 AM") }
    var endTime by remember { mutableStateOf(exam?.endTime ?: "12:00 PM") }
    var roomNumber by remember { mutableStateOf(exam?.roomNumber ?: "Exam Hall A") }
    var maxMarks by remember { mutableIntStateOf(exam?.maxMarks ?: 100) }
    var instructions by remember { mutableStateOf(exam?.instructions ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (exam == null) "Schedule Exam Paper" else "Edit Exam Paper", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = examName,
                    onValueChange = { examName = it },
                    label = { Text("Exam Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = examDate,
                        onValueChange = { examDate = it },
                        label = { Text("Date (YYYY-MM-DD)") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = "$maxMarks",
                        onValueChange = { maxMarks = it.toIntOrNull() ?: 100 },
                        label = { Text("Max Marks") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = startTime,
                        onValueChange = { startTime = it },
                        label = { Text("Start Time") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = endTime,
                        onValueChange = { endTime = it },
                        label = { Text("End Time") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = roomNumber,
                    onValueChange = { roomNumber = it },
                    label = { Text("Room / Hall") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = instructions,
                    onValueChange = { instructions = it },
                    label = { Text("Instructions / Allowed Materials") },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Assign Class:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(classes) { c ->
                        FilterChip(
                            selected = selectedClassId == c.id,
                            onClick = { selectedClassId = c.id },
                            label = { Text(c.displayName, fontSize = 11.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (subject.isNotBlank() && examName.isNotBlank()) {
                        onSave(
                            ExamSchedule(
                                id = exam?.id ?: 0L,
                                examName = examName.trim(),
                                classId = selectedClassId,
                                subject = subject.trim(),
                                examDate = examDate.trim(),
                                startTime = startTime.trim(),
                                endTime = endTime.trim(),
                                roomNumber = roomNumber.trim(),
                                maxMarks = maxMarks,
                                instructions = instructions.trim()
                            )
                        )
                    }
                },
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Save Exam")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
