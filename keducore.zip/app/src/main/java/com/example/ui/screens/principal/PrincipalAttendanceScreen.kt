package com.example.ui.screens.principal

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AbsentStudentDetail
import com.example.data.model.ClassAttendanceSummary
import com.example.ui.components.*
import com.example.ui.screens.reports.AttendanceReportsScreen
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrincipalAttendanceScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedDate by viewModel.selectedDate.collectAsState()
    val summaries by viewModel.principalAttendanceSummary.collectAsState()

    var activeView by remember { mutableIntStateOf(0) } // 0: Daily Dashboard, 1: Full Reports & Percentages
    var selectedTab by remember { mutableIntStateOf(0) } // 0: By Class, 1: Absent Students List
    var showParentAlertsDialog by remember { mutableStateOf(false) }
    var showTeacherRegisterDialog by remember { mutableStateOf(false) }

    val totalStudents = summaries.sumOf { it.totalStudents }
    val totalPresent = summaries.sumOf { it.presentCount }
    val totalAbsent = summaries.sumOf { it.absentCount }
    val submittedClasses = summaries.count { it.isSubmitted }
    val totalClasses = summaries.size

    val allAbsentStudents = remember(summaries) {
        summaries.flatMap { summary ->
            summary.absentStudentsWithNotes.map { detail ->
                Triple(summary.classItem.displayName, summary.teacherName, detail)
            }
        }
    }

    if (activeView == 1) {
        Column(modifier = modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { activeView = 0 }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Text("Attendance Analytics & Reports", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            AttendanceReportsScreen(viewModel = viewModel)
        }
        return
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Date Navigator
        DateNavigatorBar(
            selectedDate = selectedDate,
            onPreviousDay = { viewModel.shiftDate(-1) },
            onNextDay = { viewModel.shiftDate(1) },
            onToday = { viewModel.setToday() }
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Quick Action Pill Buttons for Features (Reports, Absence Alerts, Teacher Attendance)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilledTonalButton(
                onClick = { activeView = 1 },
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f).testTag("btn_view_reports")
            ) {
                Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Reports & %", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            FilledTonalButton(
                onClick = { showParentAlertsDialog = true },
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = AbsentRedContainer.copy(alpha = 0.6f)),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f).testTag("btn_parent_alerts")
            ) {
                Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = AbsentRed, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Parent Alerts", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AbsentRed)
            }

            FilledTonalButton(
                onClick = { showTeacherRegisterDialog = true },
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = SecondaryTealLight.copy(alpha = 0.4f)),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f).testTag("btn_teacher_attendance")
            ) {
                Icon(Icons.Default.Badge, contentDescription = null, tint = SecondaryTeal, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Staff Register", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SecondaryTeal)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // High level metrics
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricStatCard(
                title = "Total Present",
                value = "$totalPresent",
                subValue = "of $totalStudents students",
                icon = Icons.Default.CheckCircle,
                containerColor = PresentGreenContainer.copy(alpha = 0.5f),
                iconTint = PresentGreen,
                modifier = Modifier.weight(1f)
            )
            MetricStatCard(
                title = "Total Absent",
                value = "$totalAbsent",
                subValue = if (totalStudents > 0) "${(totalAbsent * 100) / totalStudents}% absent" else "0%",
                icon = Icons.Default.Cancel,
                containerColor = AbsentRedContainer.copy(alpha = 0.5f),
                iconTint = AbsentRed,
                modifier = Modifier.weight(1f)
            )
            MetricStatCard(
                title = "Submissions",
                value = "$submittedClasses / $totalClasses",
                subValue = "Classes updated",
                icon = Icons.Default.FactCheck,
                containerColor = InfoBlueContainer.copy(alpha = 0.5f),
                iconTint = InfoBlue,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Tab selection (Class overview vs Absentee list)
        PrimaryTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.Transparent,
            modifier = Modifier.fillMaxWidth()
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("All Classes ($totalClasses)", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.testTag("tab_all_classes")
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Absent Students ($totalAbsent)", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.PersonOff, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.testTag("tab_absent_students")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (selectedTab == 0) {
            if (summaries.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Class,
                    title = "No Classes Found",
                    description = "Add classes in the Classes tab to view daily attendance."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(summaries, key = { it.classItem.id }) { summary ->
                        ClassAttendanceCard(summary = summary)
                    }
                }
            }
        } else {
            if (allAbsentStudents.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Celebration,
                    title = "No Absent Students Recorded",
                    description = if (submittedClasses > 0) "All students are marked present for this date!" else "Attendance has not been submitted for any class yet."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 80.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(allAbsentStudents, key = { "${it.first}_${it.third.studentId}" }) { (className, teacherName, absentDetail) ->
                        AbsenteeDetailCard(
                            className = className,
                            teacherName = teacherName,
                            absentDetail = absentDetail
                        )
                    }
                }
            }
        }
    }

    if (showParentAlertsDialog) {
        ParentAbsenceAlertsDialog(
            dailySummaries = summaries,
            viewModel = viewModel,
            onDismiss = { showParentAlertsDialog = false }
        )
    }

    if (showTeacherRegisterDialog) {
        TeacherAttendanceRegisterDialog(
            viewModel = viewModel,
            onDismiss = { showTeacherRegisterDialog = false }
        )
    }
}

@Composable
fun ClassAttendanceCard(
    summary: ClassAttendanceSummary,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }

    val formattedSubmissionTime = remember(summary.submittedAt) {
        if (summary.submittedAt != null) {
            val format = SimpleDateFormat("hh:mm a", Locale.getDefault())
            format.format(Date(summary.submittedAt))
        } else null
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded }
            .testTag("class_attendance_card_${summary.classItem.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = summary.classItem.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Teacher: ${summary.teacherName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                SubmissionStatusChip(isSubmitted = summary.isSubmitted)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Attendance ratio stats
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Total: ${summary.totalStudents}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Present: ${summary.presentCount}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = PresentGreen
                    )
                    Text(
                        text = "Absent: ${summary.absentCount}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = AbsentRed
                    )
                }

                if (formattedSubmissionTime != null) {
                    Text(
                        text = "at $formattedSubmissionTime",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (summary.absentStudentsWithNotes.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                AnimatedVisibility(visible = isExpanded) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    ) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Absent Students & Reasons:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = AbsentRed
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        summary.absentStudentsWithNotes.forEach { absent ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "• ${absent.studentName} (#${absent.rollNumber})",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                if (absent.reason.isNotBlank()) {
                                    Text(
                                        text = absent.reason,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                if (!isExpanded) {
                    Text(
                        text = "Tap to view ${summary.absentStudentsWithNotes.size} absent details ▼",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AbsenteeDetailCard(
    className: String,
    teacherName: String,
    absentDetail: AbsentStudentDetail,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(AbsentRedContainer),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = absentDetail.rollNumber,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = AbsentRed
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = absentDetail.studentName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "$className • Teacher: $teacherName",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (absentDetail.reason.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Note: ${absentDetail.reason}",
                        style = MaterialTheme.typography.bodySmall,
                        color = PendingAmber,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            StatusBadge(
                text = "Absent",
                containerColor = AbsentRedContainer,
                contentColor = AbsentRed
            )
        }
    }
}
