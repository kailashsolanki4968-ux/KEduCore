package com.example.ui.screens.academics

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SchoolClass
import com.example.data.model.Teacher
import com.example.data.model.TimetableEntry
import com.example.ui.components.EmptyStateView
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel
import com.example.ui.viewmodel.UserRole

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimetableScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentRole by viewModel.currentRole.collectAsState()
    val selectedTeacher by viewModel.selectedTeacher.collectAsState()
    val classes by viewModel.classes.collectAsState()
    val teachers by viewModel.teachers.collectAsState()
    val allTimetables by viewModel.allTimetables.collectAsState()

    val daysOfWeek = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
    var selectedDay by remember { mutableStateOf("Monday") }

    // Mode: 0 = Class Timetable, 1 = Teacher Timetable
    var viewMode by remember { mutableIntStateOf(if (currentRole == UserRole.TEACHER) 1 else 0) }
    var selectedClassId by remember { mutableStateOf<Long?>(null) }
    var filterTeacherId by remember { mutableStateOf<Long?>(null) }

    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingEntry by remember { mutableStateOf<TimetableEntry?>(null) }

    LaunchedEffect(classes, selectedTeacher) {
        if (selectedClassId == null && classes.isNotEmpty()) {
            selectedClassId = classes.first().id
        }
        if (filterTeacherId == null) {
            filterTeacherId = selectedTeacher?.id ?: teachers.firstOrNull()?.id
        }
    }

    val currentEntries = remember(allTimetables, viewMode, selectedClassId, filterTeacherId, selectedDay) {
        allTimetables.filter { entry ->
            val matchesDay = entry.dayOfWeek.equals(selectedDay, ignoreCase = true)
            val matchesTarget = if (viewMode == 0) {
                selectedClassId != null && entry.classId == selectedClassId
            } else {
                filterTeacherId != null && entry.teacherId == filterTeacherId
            }
            matchesDay && matchesTarget
        }.sortedBy { it.periodNumber }
    }

    Scaffold(
        floatingActionButton = {
            if (currentRole == UserRole.PRINCIPAL) {
                FloatingActionButton(
                    onClick = {
                        editingEntry = null
                        showAddEditDialog = true
                    },
                    containerColor = PrimaryNavy,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("add_timetable_entry_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Timetable Slot")
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // View Mode Toggle (Class Timetable vs Teacher Timetable)
            PrimaryTabRow(
                selectedTabIndex = viewMode,
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.clip(RoundedCornerShape(10.dp))
            ) {
                Tab(
                    selected = viewMode == 0,
                    onClick = { viewMode = 0 },
                    text = { Text("Class Timetable", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                    icon = { Icon(Icons.Default.Class, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("tab_class_timetable")
                )
                Tab(
                    selected = viewMode == 1,
                    onClick = { viewMode = 1 },
                    text = { Text("Teacher Schedule", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                    icon = { Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("tab_teacher_timetable")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Class or Teacher Selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (viewMode == 0) {
                    // Class selector chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(classes) { c ->
                            FilterChip(
                                selected = selectedClassId == c.id,
                                onClick = { selectedClassId = c.id },
                                label = { Text(c.displayName, fontSize = 12.sp) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }
                } else {
                    // Teacher selector chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(teachers) { t ->
                            FilterChip(
                                selected = filterTeacherId == t.id,
                                onClick = { filterTeacherId = t.id },
                                label = { Text(t.name, fontSize = 12.sp) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }
                }

                // Share button
                IconButton(
                    onClick = {
                        val header = if (viewMode == 0) {
                            val cName = classes.find { it.id == selectedClassId }?.displayName ?: "Class"
                            "Timetable for $cName - $selectedDay"
                        } else {
                            val tName = teachers.find { it.id == filterTeacherId }?.name ?: "Teacher"
                            "Teaching Schedule for $tName - $selectedDay"
                        }
                        val content = buildString {
                            appendLine("=== $header ===")
                            if (currentEntries.isEmpty()) {
                                appendLine("No periods scheduled for this day.")
                            } else {
                                currentEntries.forEach { entry ->
                                    val t = teachers.find { it.id == entry.teacherId }?.name ?: "Teacher"
                                    val c = classes.find { it.id == entry.classId }?.displayName ?: "Class"
                                    appendLine("Period ${entry.periodNumber} (${entry.startTime} - ${entry.endTime}): ${entry.subject} | $c | Teacher: $t | Room: ${entry.roomNumber}")
                                }
                            }
                        }
                        viewModel.shareTextReport(context, header, content)
                    },
                    modifier = Modifier.testTag("share_timetable_button")
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Share Timetable", tint = MaterialTheme.colorScheme.primary)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Day of Week Selector
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(daysOfWeek) { day ->
                    val isSelected = selectedDay == day
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .clickable { selectedDay = day }
                            .testTag("day_selector_$day")
                    ) {
                        Text(
                            text = day.take(3),
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Timetable Period Slots
            if (currentEntries.isEmpty()) {
                EmptyStateView(
                    title = "No Periods Scheduled",
                    description = "No timetable slots recorded for $selectedDay.",
                    icon = Icons.Default.Schedule
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(currentEntries) { entry ->
                        val teacher = teachers.find { it.id == entry.teacherId }
                        val schoolClass = classes.find { it.id == entry.classId }

                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Period Badge
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("P${entry.periodNumber}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = entry.subject,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${entry.startTime} - ${entry.endTime}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (viewMode == 0) "Teacher: ${teacher?.name ?: "Unassigned"} • Room ${entry.roomNumber}" else "Class: ${schoolClass?.displayName ?: "Class"} • Room ${entry.roomNumber}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                if (currentRole == UserRole.PRINCIPAL) {
                                    IconButton(
                                        onClick = {
                                            editingEntry = entry
                                            showAddEditDialog = true
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                    }

                                    IconButton(
                                        onClick = { viewModel.deleteTimetableEntry(entry) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AbsentRed, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddEditDialog) {
        AddEditTimetableDialog(
            entry = editingEntry,
            defaultDay = selectedDay,
            defaultClassId = selectedClassId ?: classes.firstOrNull()?.id ?: 1,
            classes = classes,
            teachers = teachers,
            onDismiss = { showAddEditDialog = false },
            onSave = { newEntry ->
                viewModel.saveTimetableEntry(newEntry) {
                    showAddEditDialog = false
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditTimetableDialog(
    entry: TimetableEntry?,
    defaultDay: String,
    defaultClassId: Long,
    classes: List<SchoolClass>,
    teachers: List<Teacher>,
    onDismiss: () -> Unit,
    onSave: (TimetableEntry) -> Unit
) {
    var dayOfWeek by remember { mutableStateOf(entry?.dayOfWeek ?: defaultDay) }
    var selectedClassId by remember { mutableStateOf(entry?.classId ?: defaultClassId) }
    var selectedTeacherId by remember { mutableStateOf(entry?.teacherId ?: teachers.firstOrNull()?.id ?: 1) }
    var periodNumber by remember { mutableIntStateOf(entry?.periodNumber ?: 1) }
    var startTime by remember { mutableStateOf(entry?.startTime ?: "08:30 AM") }
    var endTime by remember { mutableStateOf(entry?.endTime ?: "09:15 AM") }
    var subject by remember { mutableStateOf(entry?.subject ?: "") }
    var roomNumber by remember { mutableStateOf(entry?.roomNumber ?: "301") }

    val days = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (entry == null) "Add Timetable Period" else "Edit Timetable Period", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Subject
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject (e.g. Math, Physics)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Period Number & Day
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = "$periodNumber",
                        onValueChange = { periodNumber = it.toIntOrNull() ?: 1 },
                        label = { Text("Period (1-7)") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = roomNumber,
                        onValueChange = { roomNumber = it },
                        label = { Text("Room No") },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Time Slots
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = startTime,
                        onValueChange = { startTime = it },
                        label = { Text("Start Time") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = endTime,
                        onValueChange = { endTime = it },
                        label = { Text("End Time") },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Class Picker Chips
                Text("Select Class:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(classes) { c ->
                        FilterChip(
                            selected = selectedClassId == c.id,
                            onClick = { selectedClassId = c.id },
                            label = { Text(c.displayName, fontSize = 11.sp) }
                        )
                    }
                }

                // Teacher Picker Chips
                Text("Select Teacher:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(teachers) { t ->
                        FilterChip(
                            selected = selectedTeacherId == t.id,
                            onClick = { selectedTeacherId = t.id },
                            label = { Text(t.name, fontSize = 11.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (subject.isNotBlank()) {
                        onSave(
                            TimetableEntry(
                                id = entry?.id ?: 0L,
                                classId = selectedClassId,
                                dayOfWeek = dayOfWeek,
                                periodNumber = periodNumber,
                                startTime = startTime,
                                endTime = endTime,
                                subject = subject.trim(),
                                teacherId = selectedTeacherId,
                                roomNumber = roomNumber.trim()
                            )
                        )
                    }
                },
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Save Slot")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
