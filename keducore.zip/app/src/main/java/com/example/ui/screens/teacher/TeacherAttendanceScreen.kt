package com.example.ui.screens.teacher

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Student
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TeacherAttendanceScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val attendanceState by viewModel.teacherAttendanceState.collectAsState()
    val selectedDate by viewModel.selectedDate.collectAsState()
    val selectedTeacher by viewModel.selectedTeacher.collectAsState()

    val assignedClass = attendanceState.schoolClass
    val students = attendanceState.students
    val attendanceMap = attendanceState.attendanceMap
    val reasonMap = attendanceState.reasonMap

    val totalStudents = students.size
    val presentCount = students.count { attendanceMap[it.id] ?: true }
    val absentCount = totalStudents - presentCount

    var showSubmitConfirmation by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Date Navigator
        DateNavigatorBar(
            selectedDate = selectedDate,
            onPreviousDay = { viewModel.shiftDate(-1) },
            onNextDay = { viewModel.shiftDate(1) },
            onToday = { viewModel.setToday() }
        )

        Spacer(modifier = Modifier.height(10.dp))

        if (assignedClass == null) {
            EmptyStateView(
                icon = Icons.Default.Warning,
                title = "No Class Assigned",
                description = "You (${selectedTeacher?.name ?: "Teacher"}) are not assigned as a Class Teacher to any class. Please contact the Principal to assign your class."
            )
        } else {
            // Class Info Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = assignedClass.displayName,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (assignedClass.roomNumber.isNotBlank()) {
                                StatusBadge(
                                    text = assignedClass.roomNumber,
                                    containerColor = MaterialTheme.colorScheme.surface,
                                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Teacher: ${selectedTeacher?.name ?: ""}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    SubmissionStatusChip(isSubmitted = attendanceState.isSubmitted)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Attendance Counts & Quick Actions Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    StatusBadge(
                        text = "$presentCount Present",
                        containerColor = PresentGreenContainer,
                        contentColor = PresentGreen,
                        icon = Icons.Default.Check
                    )
                    StatusBadge(
                        text = "$absentCount Absent",
                        containerColor = AbsentRedContainer,
                        contentColor = AbsentRed,
                        icon = Icons.Default.Close
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(
                        onClick = { viewModel.markAllPresent() },
                        modifier = Modifier.testTag("mark_all_present_button")
                    ) {
                        Text("All Present", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PresentGreen)
                    }
                    TextButton(
                        onClick = { viewModel.markAllAbsent() },
                        modifier = Modifier.testTag("mark_all_absent_button")
                    ) {
                        Text("All Absent", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AbsentRed)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Student Attendance List
            if (students.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.PeopleOutline,
                    title = "No Students in ${assignedClass.displayName}",
                    description = "No students are currently enrolled in this class."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(students, key = { it.id }) { student ->
                        val isPresent = attendanceMap[student.id] ?: true
                        val absentReason = reasonMap[student.id] ?: ""

                        TeacherStudentAttendanceCard(
                            student = student,
                            isPresent = isPresent,
                            absentReason = absentReason,
                            onTogglePresent = { viewModel.toggleStudentAttendance(student.id) },
                            onReasonChange = { reason -> viewModel.setStudentAbsentReason(student.id, reason) }
                        )
                    }

                    // Optional Notes Field at bottom of list
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = attendanceState.notes,
                            onValueChange = { viewModel.updateAttendanceNotes(it) },
                            label = { Text("General Session Remarks (Optional)") },
                            placeholder = { Text("e.g. Completed topic 4, 2 students left early for sports") },
                            modifier = Modifier.fillMaxWidth().testTag("attendance_session_notes_field"),
                            shape = RoundedCornerShape(12.dp),
                            minLines = 2
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                }

                // Bottom Action Buttons
                Surface(
                    tonalElevation = 3.dp,
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp, bottom = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.saveOrSubmitAttendance(isSubmitting = false) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).testTag("save_draft_attendance_button")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save Draft")
                        }

                        Button(
                            onClick = { showSubmitConfirmation = true },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryNavy),
                            modifier = Modifier.weight(1.3f).testTag("submit_attendance_principal_button")
                        ) {
                            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Submit to Principal")
                        }
                    }
                }
            }
        }
    }

    if (showSubmitConfirmation) {
        AlertDialog(
            onDismissRequest = { showSubmitConfirmation = false },
            icon = { Icon(Icons.Default.FactCheck, contentDescription = null, tint = PrimaryNavy) },
            title = { Text("Submit Attendance to Principal?", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Date: $selectedDate")
                    Text("Class: ${assignedClass?.displayName}")
                    Text("Present: $presentCount | Absent: $absentCount")
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "The Principal will immediately receive this attendance report along with the names of all absent students.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.saveOrSubmitAttendance(isSubmitting = true)
                        showSubmitConfirmation = false
                    },
                    modifier = Modifier.testTag("dialog_confirm_submit_attendance")
                ) {
                    Text("Confirm & Submit")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSubmitConfirmation = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun TeacherStudentAttendanceCard(
    student: Student,
    isPresent: Boolean,
    absentReason: String,
    onTogglePresent: () -> Unit,
    onReasonChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("attendance_student_card_${student.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isPresent) MaterialTheme.colorScheme.surface else AbsentRedContainer.copy(alpha = 0.35f)
        ),
        border = BorderStroke(
            width = if (!isPresent) 1.5.dp else 1.dp,
            color = if (!isPresent) AbsentRed.copy(alpha = 0.4f) else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Roll number badge
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(if (isPresent) MaterialTheme.colorScheme.secondaryContainer else AbsentRedContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = student.rollNumber,
                        fontWeight = FontWeight.Bold,
                        color = if (isPresent) MaterialTheme.colorScheme.onSecondaryContainer else AbsentRed,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = student.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (student.parentContact.isNotBlank()) {
                        Text(
                            text = "Phone: ${student.parentContact}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Present / Absent Toggle Buttons
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(2.dp)
                ) {
                    Surface(
                        color = if (isPresent) PresentGreen else Color.Transparent,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .clickable { if (!isPresent) onTogglePresent() }
                            .testTag("present_btn_${student.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = if (isPresent) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "P",
                                color = if (isPresent) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Surface(
                        color = if (!isPresent) AbsentRed else Color.Transparent,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .clickable { if (isPresent) onTogglePresent() }
                            .testTag("absent_btn_${student.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = null,
                                tint = if (!isPresent) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "A",
                                color = if (!isPresent) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            // Optional note input for absent students
            AnimatedVisibility(visible = !isPresent) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                ) {
                    OutlinedTextField(
                        value = absentReason,
                        onValueChange = onReasonChange,
                        label = { Text("Reason for Absence (Optional Note)") },
                        placeholder = { Text("e.g. Sick, Family function, Informed parent") },
                        singleLine = true,
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.EditNote,
                                contentDescription = null,
                                tint = AbsentRed
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("absent_note_${student.id}"),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        }
    }
}
