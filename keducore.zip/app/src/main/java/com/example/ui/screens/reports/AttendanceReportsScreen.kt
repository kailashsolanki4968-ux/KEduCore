package com.example.ui.screens.reports

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ClassAttendanceSummary
import com.example.data.model.SchoolClass
import com.example.data.model.Student
import com.example.data.model.StudentAttendanceStats
import com.example.ui.components.DateNavigatorBar
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceReportsScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier,
    onStudentClick: (Student) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val selectedDate by viewModel.selectedDate.collectAsState()
    val selectedMonth by viewModel.selectedMonth.collectAsState()
    val classes by viewModel.classes.collectAsState()
    val students by viewModel.students.collectAsState()
    val dailySummaries by viewModel.principalAttendanceSummary.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Daily Class-Wise, 1: Monthly Summary, 2: Student-Wise %
    var selectedClassFilter by remember { mutableStateOf<Long?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    // Student stats cache
    var studentStatsList by remember { mutableStateOf<List<StudentAttendanceStats>>(emptyList()) }
    var isLoadingStats by remember { mutableStateOf(false) }

    LaunchedEffect(students, selectedTab) {
        if (selectedTab == 2) {
            isLoadingStats = true
            val list = mutableListOf<StudentAttendanceStats>()
            students.forEach { st ->
                val stats = viewModel.getStudentStats(st.id)
                list.add(stats)
            }
            studentStatsList = list.sortedByDescending { it.attendancePercentage }
            isLoadingStats = false
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Tab Selector
        PrimaryTabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.clip(RoundedCornerShape(12.dp))
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Daily Reports", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Today, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.testTag("tab_daily_reports")
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Class-Wise", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.BarChart, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.testTag("tab_class_reports")
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Student %", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Percent, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.testTag("tab_student_reports")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Date Bar for Daily Tab
        if (selectedTab == 0) {
            DateNavigatorBar(
                selectedDate = selectedDate,
                onPreviousDay = { viewModel.shiftDate(-1) },
                onNextDay = { viewModel.shiftDate(1) },
                onToday = { viewModel.setToday() }
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Export Action Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = when (selectedTab) {
                    0 -> "Daily Attendance Breakdown ($selectedDate)"
                    1 -> "Class-Wise Attendance Performance"
                    else -> "Student Attendance Percentage Register"
                },
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            FilledTonalButton(
                onClick = {
                    val exportText = buildString {
                        appendLine("=== SCHOOL ATTENDANCE REPORT ===")
                        appendLine("Generated on: ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())}")
                        appendLine("Report Type: ${if (selectedTab == 0) "Daily ($selectedDate)" else if (selectedTab == 1) "Class Breakdown" else "Student Percentages"}")
                        appendLine("----------------------------------------")
                        if (selectedTab == 0 || selectedTab == 1) {
                            dailySummaries.forEach { summary ->
                                val pct = if (summary.totalStudents > 0) (summary.presentCount.toFloat() / summary.totalStudents * 100).toInt() else 0
                                appendLine("${summary.classItem.displayName}: Total=${summary.totalStudents}, Present=${summary.presentCount}, Absent=${summary.absentCount}, Attendance=${pct}%")
                            }
                        } else {
                            studentStatsList.forEach { st ->
                                appendLine("${st.student.name} (Roll ${st.student.rollNumber}, ${st.className}): ${st.attendancePercentage.toInt()}% (${st.presentDays}/${st.totalRecordedDays} days)")
                            }
                        }
                    }
                    viewModel.shareTextReport(context, "Attendance_Report_${selectedDate}", exportText)
                },
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("export_attendance_report_btn")
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Export", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Search & Filter (for Student tab)
        if (selectedTab == 2) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Filter by student name or roll...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().testTag("attendance_student_search")
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Tab Content
        when (selectedTab) {
            0 -> DailyAttendanceReportView(dailySummaries = dailySummaries)
            1 -> ClassWiseAttendanceReportView(dailySummaries = dailySummaries)
            2 -> {
                if (isLoadingStats) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                } else {
                    val filteredStats = remember(studentStatsList, searchQuery, selectedClassFilter) {
                        studentStatsList.filter {
                            (selectedClassFilter == null || it.student.classId == selectedClassFilter) &&
                            (searchQuery.isBlank() || it.student.name.contains(searchQuery, ignoreCase = true) || it.student.rollNumber.contains(searchQuery, ignoreCase = true))
                        }
                    }
                    StudentWiseAttendanceReportView(
                        statsList = filteredStats,
                        onStudentClick = onStudentClick
                    )
                }
            }
        }
    }
}

@Composable
fun DailyAttendanceReportView(dailySummaries: List<ClassAttendanceSummary>) {
    if (dailySummaries.isEmpty()) {
        EmptyStateView(
            title = "No Classes Found",
            description = "Add classes to view attendance reports.",
            icon = Icons.Default.FactCheck
        )
        return
    }

    val totalEnrolled = dailySummaries.sumOf { it.totalStudents }
    val totalPresent = dailySummaries.sumOf { it.presentCount }
    val totalAbsent = dailySummaries.sumOf { it.absentCount }
    val overallPercentage = if (totalEnrolled > 0) (totalPresent.toFloat() / totalEnrolled.toFloat()) * 100f else 0f

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // High Level Metrics
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PrimaryNavy),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "School Overall Attendance",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${overallPercentage.toInt()}%",
                            color = Color.White,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Present", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                                Text("$totalPresent", color = PresentGreenContainer, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Absent", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                                Text("$totalAbsent", color = AbsentRedContainer, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Total", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                                Text("$totalEnrolled", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            }
                        }
                    }
                }
            }
        }

        items(dailySummaries) { summary ->
            val percentage = if (summary.totalStudents > 0) (summary.presentCount.toFloat() / summary.totalStudents.toFloat()) * 100f else 0f
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = summary.classItem.displayName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Teacher: ${summary.teacherName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        StatusBadge(
                            text = if (summary.isSubmitted) "Submitted (${percentage.toInt()}%)" else "Pending (${percentage.toInt()}%)",
                            containerColor = if (summary.isSubmitted) PresentGreenContainer else PendingAmberContainer,
                            contentColor = if (summary.isSubmitted) PresentGreen else PendingAmber
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { (percentage / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = if (percentage >= 80f) PresentGreen else if (percentage >= 60f) PendingAmber else AbsentRed,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Enrolled: ${summary.totalStudents}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Present: ${summary.presentCount}", fontSize = 12.sp, color = PresentGreen, fontWeight = FontWeight.SemiBold)
                        Text("Absent: ${summary.absentCount}", fontSize = 12.sp, color = AbsentRed, fontWeight = FontWeight.SemiBold)
                    }

                    if (summary.absentStudentsWithNotes.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Absent Students:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AbsentRed)
                        summary.absentStudentsWithNotes.forEach { ab ->
                            Text(
                                text = "• ${ab.studentName} (Roll #${ab.rollNumber})${if (ab.reason.isNotBlank()) " - ${ab.reason}" else ""}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ClassWiseAttendanceReportView(dailySummaries: List<ClassAttendanceSummary>) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.Analytics, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                    Column {
                        Text("Class Attendance Analytics", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Real-time comparative performance across classes.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        items(dailySummaries.sortedByDescending { if (it.totalStudents > 0) it.presentCount.toFloat() / it.totalStudents else 0f }) { summary ->
            val percentage = if (summary.totalStudents > 0) (summary.presentCount.toFloat() / summary.totalStudents.toFloat()) * 100f else 0f
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(
                                if (percentage >= 80f) PresentGreenContainer else if (percentage >= 60f) PendingAmberContainer else AbsentRedContainer
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${percentage.toInt()}%",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (percentage >= 80f) PresentGreen else if (percentage >= 60f) PendingAmber else AbsentRed
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(summary.classItem.displayName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("Teacher: ${summary.teacherName} • Room ${summary.classItem.roomNumber}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { (percentage / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = if (percentage >= 80f) PresentGreen else if (percentage >= 60f) PendingAmber else AbsentRed
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("${summary.presentCount}/${summary.totalStudents}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Present", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun StudentWiseAttendanceReportView(
    statsList: List<StudentAttendanceStats>,
    onStudentClick: (Student) -> Unit
) {
    if (statsList.isEmpty()) {
        EmptyStateView(
            title = "No Student Records",
            description = "Attendance records will populate here once marked.",
            icon = Icons.Default.People
        )
        return
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(statsList) { stats ->
            val pct = stats.attendancePercentage
            val isWarning = pct < 75f

            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isWarning) AbsentRedContainer.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onStudentClick(stats.student) }
                    .testTag("student_attendance_row_${stats.student.id}")
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                if (pct >= 85f) PresentGreenContainer else if (pct >= 75f) PendingAmberContainer else AbsentRedContainer
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${pct.toInt()}%",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (pct >= 85f) PresentGreen else if (pct >= 75f) PendingAmber else AbsentRed
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(stats.student.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("#${stats.student.rollNumber}", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                            }
                        }
                        Text(
                            text = "${stats.className} • ${stats.presentDays} Present / ${stats.absentDays} Absent",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (isWarning) {
                        StatusBadge(
                            text = "Low <75%",
                            containerColor = AbsentRedContainer,
                            contentColor = AbsentRed,
                            icon = Icons.Default.Warning
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                        )
                    }
                }
            }
        }
    }
}
