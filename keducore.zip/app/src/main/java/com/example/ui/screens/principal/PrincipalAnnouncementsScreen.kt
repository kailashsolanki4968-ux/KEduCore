package com.example.ui.screens.principal

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Announcement
import com.example.data.model.SchoolClass
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun PrincipalAnnouncementsScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val announcements by viewModel.announcements.collectAsState()
    val classes by viewModel.classes.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var announcementToDelete by remember { mutableStateOf<Announcement?>(null) }
    var selectedAudienceFilter by remember { mutableStateOf<String?>(null) } // null = all

    val filteredAnnouncements = remember(announcements, selectedAudienceFilter) {
        if (selectedAudienceFilter == null) announcements
        else announcements.filter { it.targetAudience.contains(selectedAudienceFilter!!, ignoreCase = true) }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "School Announcements",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Broadcast notices to specific classes, all faculty, or everyone",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedAudienceFilter == null,
                        onClick = { selectedAudienceFilter = null },
                        label = { Text("All (${announcements.size})", fontSize = 12.sp) }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedAudienceFilter == "TEACHERS",
                        onClick = { selectedAudienceFilter = "TEACHERS" },
                        label = { Text("Teachers Only", fontSize = 12.sp) }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedAudienceFilter == "CLASS",
                        onClick = { selectedAudienceFilter = "CLASS" },
                        label = { Text("Class Specific", fontSize = 12.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (filteredAnnouncements.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Campaign,
                    title = "No Announcements Found",
                    description = "Tap the button below to publish notices or circulars."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredAnnouncements, key = { it.id }) { ann ->
                        AnnouncementItemCard(
                            announcement = ann,
                            onDelete = { announcementToDelete = ann }
                        )
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showAddDialog = true },
            containerColor = PrimaryNavy,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("add_announcement_fab")
        ) {
            Icon(Icons.Default.Add, contentDescription = "Create Announcement")
        }
    }

    if (showAddDialog) {
        CreateAnnouncementDialog(
            classes = classes,
            onDismiss = { showAddDialog = false },
            onSave = { ann ->
                viewModel.sendAnnouncement(ann)
                showAddDialog = false
            }
        )
    }

    if (announcementToDelete != null) {
        ConfirmDeleteDialog(
            title = "Delete Announcement?",
            message = "Are you sure you want to delete \"${announcementToDelete?.title}\"?",
            onConfirm = {
                announcementToDelete?.let { viewModel.deleteAnnouncement(it) }
                announcementToDelete = null
            },
            onDismiss = { announcementToDelete = null }
        )
    }
}

@Composable
fun AnnouncementItemCard(
    announcement: Announcement,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val formattedDate = remember(announcement.createdAt) {
        val format = SimpleDateFormat("MMM dd, yyyy • hh:mm a", Locale.getDefault())
        format.format(Date(announcement.createdAt))
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = if (announcement.isImportant) 1.5.dp else 1.dp,
            color = if (announcement.isImportant) AccentGoldDark else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (announcement.isImportant) {
                        StatusBadge(
                            text = "High Priority",
                            containerColor = AccentGoldLight.copy(alpha = 0.3f),
                            contentColor = AccentGoldDark,
                            icon = Icons.Default.PriorityHigh
                        )
                    }

                    StatusBadge(
                        text = when {
                            announcement.targetAudience == "TEACHERS" -> "All Teachers"
                            announcement.targetAudience.startsWith("CLASS_") -> announcement.targetAudience.replace("CLASS_", "Class ")
                            else -> "All School"
                        },
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = announcement.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = announcement.content,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "By ${announcement.authorName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = formattedDate,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun CreateAnnouncementDialog(
    classes: List<SchoolClass>,
    onDismiss: () -> Unit,
    onSave: (Announcement) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var targetMode by remember { mutableStateOf("ALL") } // "ALL", "TEACHERS", "CLASS"
    var selectedClassId by remember { mutableStateOf(classes.firstOrNull()?.id ?: 0L) }
    var isImportant by remember { mutableStateOf(false) }
    var titleError by remember { mutableStateOf(false) }
    var contentError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Create School Notification", fontWeight = FontWeight.Bold)
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = {
                            title = it
                            titleError = it.isBlank()
                        },
                        label = { Text("Notification Title *") },
                        isError = titleError,
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_announcement_title")
                    )
                }

                item {
                    OutlinedTextField(
                        value = content,
                        onValueChange = {
                            content = it
                            contentError = it.isBlank()
                        },
                        label = { Text("Message Body *") },
                        isError = contentError,
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth().testTag("input_announcement_content")
                    )
                }

                item {
                    Text("Target Audience:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = targetMode == "ALL",
                            onClick = { targetMode = "ALL" },
                            label = { Text("All School", fontSize = 11.sp) }
                        )
                        FilterChip(
                            selected = targetMode == "TEACHERS",
                            onClick = { targetMode = "TEACHERS" },
                            label = { Text("All Teachers", fontSize = 11.sp) }
                        )
                        FilterChip(
                            selected = targetMode == "CLASS",
                            onClick = { targetMode = "CLASS" },
                            label = { Text("Specific Class", fontSize = 11.sp) }
                        )
                    }
                }

                if (targetMode == "CLASS" && classes.isNotEmpty()) {
                    item {
                        Text("Select Target Class:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(classes) { c ->
                                FilterChip(
                                    selected = selectedClassId == c.id,
                                    onClick = { selectedClassId = c.id },
                                    label = { Text(c.displayName, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isImportant,
                            onCheckedChange = { isImportant = it }
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Mark as High Priority / Urgent Alert",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank()) titleError = true
                    if (content.isBlank()) contentError = true

                    if (title.isNotBlank() && content.isNotBlank()) {
                        val target = when (targetMode) {
                            "TEACHERS" -> "TEACHERS"
                            "CLASS" -> {
                                val cName = classes.find { it.id == selectedClassId }?.displayName ?: "Class"
                                "CLASS_$cName"
                            }
                            else -> "ALL"
                        }
                        onSave(
                            Announcement(
                                title = title.trim(),
                                content = content.trim(),
                                authorName = "Principal",
                                targetAudience = target,
                                isImportant = isImportant,
                                createdAt = System.currentTimeMillis()
                            )
                        )
                    }
                },
                modifier = Modifier.testTag("publish_announcement_button")
            ) {
                Text("Publish Notice")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
