package com.example.ui.components

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun StudentAvatar(
    avatarKey: String,
    gender: String,
    modifier: Modifier = Modifier,
    size: Int = 48
) {
    val isGirl = gender.equals("Female", ignoreCase = true)
    val bgColor = if (isGirl) Color(0xFFF8BBD0) else Color(0xFFBBDEFB)
    val iconColor = if (isGirl) Color(0xFFC2185B) else Color(0xFF1976D2)

    Box(
        modifier = modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(bgColor),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = if (isGirl) Icons.Default.Face else Icons.Default.Face,
            contentDescription = "Avatar",
            tint = iconColor,
            modifier = Modifier.size((size * 0.6).dp)
        )
    }
}

@Composable
fun StudentProfileDialog(
    student: Student,
    classes: List<SchoolClass>,
    viewModel: SchoolViewModel,
    onDismiss: () -> Unit,
    onEdit: (() -> Unit)? = null,
    onGenerateReportCard: (Student) -> Unit
) {
    val context = LocalContext.current
    val schoolClass = classes.find { it.id == student.classId }
    val settings by viewModel.schoolSettings.collectAsState()

    var stats by remember { mutableStateOf<StudentAttendanceStats?>(null) }

    LaunchedEffect(student.id) {
        stats = viewModel.getStudentStats(student.id)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Top Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Student Profile",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (onEdit != null) "Administrator Management View" else "Teacher View (Read-Only)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row {
                        if (onEdit != null) {
                            IconButton(onClick = onEdit, modifier = Modifier.testTag("edit_student_profile_btn")) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit Student Details", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    // Header card with Avatar and basic stats
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PrimaryNavy),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                StudentAvatar(
                                    avatarKey = student.photoAvatar,
                                    gender = student.gender,
                                    size = 64
                                )

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = student.name,
                                            color = Color.White,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )
                                        Surface(
                                            color = if (student.isActive) PresentGreen.copy(alpha = 0.3f) else AbsentRed.copy(alpha = 0.3f),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = if (student.isActive) "ACTIVE" else "DEACTIVATED",
                                                color = if (student.isActive) PresentGreenContainer else AbsentRedContainer,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "Roll #${student.rollNumber} • ${schoolClass?.displayName ?: "Unassigned"}",
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 13.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Surface(
                                            color = Color.White.copy(alpha = 0.2f),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = "Blood: ${student.bloodGroup.ifBlank { "O+" }}",
                                                color = Color.White,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                        Surface(
                                            color = Color.White.copy(alpha = 0.2f),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = student.gender,
                                                color = Color.White,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Attendance summary badge
                    item {
                        val pct = stats?.attendancePercentage ?: 100f
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.FactCheck, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Column {
                                        Text("Overall Attendance", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(
                                            text = "${pct.toInt()}% (${stats?.presentDays ?: 0}/${stats?.totalRecordedDays ?: 0} Days)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                }

                                StatusBadge(
                                    text = if (pct >= 85f) "Good" else if (pct >= 75f) "Average" else "Low Attendance",
                                    containerColor = if (pct >= 85f) PresentGreenContainer else if (pct >= 75f) PendingAmberContainer else AbsentRedContainer,
                                    contentColor = if (pct >= 85f) PresentGreen else if (pct >= 75f) PendingAmber else AbsentRed
                                )
                            }
                        }
                    }

                    // Guardian & Contact Details
                    item {
                        Text("Parent & Guardian Information", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Guardian Name", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(student.parentName.ifBlank { "Parent / Guardian" }, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    }
                                    StatusBadge(
                                        text = student.guardianRelation.ifBlank { "Parent" },
                                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                                        contentColor = MaterialTheme.colorScheme.secondary
                                    )
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Contact Number", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(student.parentContact.ifBlank { "Not provided" }, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    }

                                    if (student.parentContact.isNotBlank()) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            FilledTonalIconButton(
                                                onClick = { viewModel.makePhoneCall(context, student.parentContact) },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(Icons.Default.Phone, contentDescription = "Call", modifier = Modifier.size(18.dp))
                                            }
                                            FilledTonalIconButton(
                                                onClick = { viewModel.sendSms(context, student.parentContact, "Hello, regarding ${student.name} from ${settings?.schoolName ?: "KEduCore"}:") },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(Icons.Default.Chat, contentDescription = "SMS", modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }

                                if (student.address.isNotBlank()) {
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                    Column {
                                        Text("Residential Address", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(student.address, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }

                    // Basic Details
                    item {
                        Text("Personal & School Records", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text("Date of Birth", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(student.dateOfBirth.ifBlank { "2010-05-15" }, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    }
                                    Column {
                                        Text("Gender", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(student.gender, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    }
                                    Column {
                                        Text("Admission Date", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(student.admissionDate.ifBlank { "2022-04-01" }, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bottom Action: Generate Report Card
                Button(
                    onClick = {
                        onDismiss()
                        onGenerateReportCard(student)
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryNavy),
                    modifier = Modifier.fillMaxWidth().testTag("generate_report_card_btn")
                ) {
                    Icon(Icons.Default.Assessment, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Generate Detailed Report Card", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ReportCardDialog(
    student: Student,
    schoolClass: SchoolClass?,
    viewModel: SchoolViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val allMarks by viewModel.allMarks.collectAsState()
    val settings by viewModel.schoolSettings.collectAsState()

    var studentStats by remember { mutableStateOf<StudentAttendanceStats?>(null) }

    LaunchedEffect(student.id) {
        studentStats = viewModel.getStudentStats(student.id)
    }

    val studentMarks = remember(allMarks, student.id) {
        allMarks.filter { it.studentId == student.id }
    }

    val totalObtained = remember(studentMarks) { studentMarks.sumOf { it.obtainedMarks } }
    val totalMax = remember(studentMarks) { studentMarks.sumOf { it.maxMarks } }
    val percentage = remember(totalObtained, totalMax) {
        if (totalMax > 0) (totalObtained.toFloat() / totalMax.toFloat()) * 100f else 0f
    }

    val finalGrade = remember(percentage) {
        when {
            percentage >= 90f -> "A+ (Outstanding)"
            percentage >= 80f -> "A (Excellent)"
            percentage >= 70f -> "B (Good)"
            percentage >= 60f -> "C (Satisfactory)"
            percentage >= 50f -> "D (Pass)"
            else -> "F (Needs Improvement)"
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.9f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Official Academic Report Card",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    // School Banner
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = PrimaryNavy),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = settings?.schoolName ?: "St. Jude International Academy",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = settings?.schoolAddress ?: "Academic City",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 11.sp,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = "Academic Session: ${settings?.academicSession ?: "2026-2027"}",
                                    color = PresentGreenContainer,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    // Student Details Snapshot
                    item {
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Student: ${student.name}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Roll No: ${student.rollNumber} • Class: ${schoolClass?.displayName ?: "Grade 10"}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Attendance: ${studentStats?.attendancePercentage?.toInt() ?: 100}%", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = PresentGreen)
                                    Text("Status: Active", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    // Subject Marks Table
                    item {
                        Text("Subject Assessment Performance", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Subject", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(1.5f))
                                    Text("Score", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                                    Text("Grade", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                                }
                                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

                                if (studentMarks.isEmpty()) {
                                    Text("No marks recorded yet.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(8.dp))
                                } else {
                                    studentMarks.forEach { mark ->
                                        val subPct = (mark.obtainedMarks.toFloat() / mark.maxMarks.toFloat()) * 100f
                                        val subGrade = if (subPct >= 90) "A+" else if (subPct >= 80) "A" else if (subPct >= 70) "B" else if (subPct >= 60) "C" else "D"
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1.5f)) {
                                                Text(mark.subject, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                                if (mark.remarks.isNotBlank()) {
                                                    Text(mark.remarks, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                            }
                                            Text("${mark.obtainedMarks}/${mark.maxMarks}", fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                                            Text(subGrade, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                                        }
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                                    }
                                }
                            }
                        }
                    }

                    // Overall Summary Card
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Overall Percentage", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${percentage.toInt()}%", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("Overall Grade", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(finalGrade, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Total Marks: $totalObtained / $totalMax", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text("Result: ${if (percentage >= 50f) "PASSED" else "FAIL"}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (percentage >= 50f) PresentGreen else AbsentRed)
                                }
                            }
                        }
                    }

                    // Signatures
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("____________________", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("Class Teacher", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("____________________", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(settings?.principalName ?: "Principal", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Export / Share Report Card button
                Button(
                    onClick = {
                        val reportText = buildString {
                            appendLine("==========================================")
                            appendLine(settings?.schoolName ?: "KEDUCORE ACADEMY")
                            appendLine("ACADEMIC PROGRESS REPORT CARD")
                            appendLine("Session: ${settings?.academicSession ?: "2026-2027"}")
                            appendLine("==========================================")
                            appendLine("Student Name: ${student.name}")
                            appendLine("Roll Number: ${student.rollNumber}")
                            appendLine("Class: ${schoolClass?.displayName ?: "Grade 10"}")
                            appendLine("Attendance: ${studentStats?.attendancePercentage?.toInt() ?: 100}%")
                            appendLine("------------------------------------------")
                            appendLine("SUBJECT-WISE PERFORMANCE:")
                            studentMarks.forEach { m ->
                                appendLine("${m.subject}: ${m.obtainedMarks}/${m.maxMarks} (${m.remarks})")
                            }
                            appendLine("------------------------------------------")
                            appendLine("TOTAL: $totalObtained / $totalMax")
                            appendLine("PERCENTAGE: ${percentage.toInt()}%")
                            appendLine("GRADE: $finalGrade")
                            appendLine("FINAL RESULT: ${if (percentage >= 50f) "PASSED" else "NEEDS IMPROVEMENT"}")
                            appendLine("------------------------------------------")
                            appendLine("Issued by: ${settings?.principalName ?: "Principal Office"}")
                        }
                        viewModel.shareTextReport(context, "Report_Card_${student.name}", reportText)
                    },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("export_report_card_btn")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Export / Share Report Card", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
