package com.example.ui.screens.teacher

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LeaveApplication
import com.example.ui.components.EmptyStateView
import com.example.ui.components.LeaveStatusChip
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun TeacherLeavesScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val allLeaves by viewModel.allLeaves.collectAsState()
    val selectedTeacher by viewModel.selectedTeacher.collectAsState()

    val myLeaves = remember(allLeaves, selectedTeacher) {
        if (selectedTeacher == null) emptyList()
        else allLeaves.filter { it.teacherId == selectedTeacher!!.id }
    }

    var showApplyDialog by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "My Leave Applications",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Apply for leave and track principal approvals",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (myLeaves.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.EventNote,
                    title = "No Leave Applications",
                    description = "Need time off? Tap the button below to submit a leave application to the Principal."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(myLeaves, key = { it.id }) { leave ->
                        TeacherLeaveCard(leave = leave)
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showApplyDialog = true },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("apply_leave_fab")
        ) {
            Icon(Icons.Default.Add, contentDescription = "Apply Leave")
        }
    }

    if (showApplyDialog && selectedTeacher != null) {
        ApplyLeaveDialog(
            onDismiss = { showApplyDialog = false },
            onApply = { leaveType, start, end, reason ->
                viewModel.applyLeave(
                    LeaveApplication(
                        teacherId = selectedTeacher!!.id,
                        leaveType = leaveType,
                        startDate = start,
                        endDate = end,
                        reason = reason
                    )
                )
                showApplyDialog = false
            }
        )
    }
}

@Composable
fun TeacherLeaveCard(
    leave: LeaveApplication,
    modifier: Modifier = Modifier
) {
    val formattedDate = remember(leave.appliedAt) {
        val format = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        format.format(Date(leave.appliedAt))
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = leave.leaveType,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Applied on $formattedDate",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                LeaveStatusChip(status = leave.status)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Duration bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    Text("Duration", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(
                    text = "${leave.startDate} to ${leave.endDate}",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Reason: ${leave.reason}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (leave.principalRemark.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Principal Remark: ${leave.principalRemark}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ApplyLeaveDialog(
    onDismiss: () -> Unit,
    onApply: (leaveType: String, start: String, end: String, reason: String) -> Unit
) {
    var leaveType by remember { mutableStateOf("Casual Leave") }
    var startDate by remember { mutableStateOf("Tomorrow") }
    var endDate by remember { mutableStateOf("Tomorrow") }
    var reason by remember { mutableStateOf("") }
    var reasonError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Apply for Leave", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Leave Type", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Casual Leave", "Sick Leave", "Personal Leave").forEach { type ->
                        FilterChip(
                            selected = leaveType == type,
                            onClick = { leaveType = type },
                            label = { Text(type.replace(" Leave", ""), fontSize = 12.sp) }
                        )
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = startDate,
                        onValueChange = { startDate = it },
                        label = { Text("From Date *") },
                        placeholder = { Text("24 Aug") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("dialog_leave_start_field")
                    )
                    OutlinedTextField(
                        value = endDate,
                        onValueChange = { endDate = it },
                        label = { Text("To Date *") },
                        placeholder = { Text("25 Aug") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("dialog_leave_end_field")
                    )
                }

                OutlinedTextField(
                    value = reason,
                    onValueChange = {
                        reason = it
                        reasonError = it.isBlank()
                    },
                    label = { Text("Reason for Leave *") },
                    placeholder = { Text("Describe reason for leave...") },
                    isError = reasonError,
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth().testTag("dialog_leave_reason_field")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (reason.isBlank()) reasonError = true
                    if (reason.isNotBlank() && startDate.isNotBlank() && endDate.isNotBlank()) {
                        onApply(leaveType, startDate.trim(), endDate.trim(), reason.trim())
                    }
                },
                modifier = Modifier.testTag("dialog_leave_submit_button")
            ) {
                Text("Submit Application")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
