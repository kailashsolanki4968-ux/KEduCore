package com.example.ui.screens.principal

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LeaveApplication
import com.example.data.model.Teacher
import com.example.ui.components.EmptyStateView
import com.example.ui.components.LeaveStatusChip
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun PrincipalLeavesScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val leaves by viewModel.allLeaves.collectAsState()
    val teachers by viewModel.teachers.collectAsState()

    var filterStatus by remember { mutableStateOf("ALL") } // "ALL", "PENDING", "APPROVED", "REJECTED"
    var reviewingLeave by remember { mutableStateOf<LeaveApplication?>(null) }
    var reviewAction by remember { mutableStateOf<String?>(null) } // "APPROVED" or "REJECTED"

    val pendingCount = leaves.count { it.status == "PENDING" }
    val approvedCount = leaves.count { it.status == "APPROVED" }
    val rejectedCount = leaves.count { it.status == "REJECTED" }

    val filteredLeaves = remember(leaves, filterStatus) {
        if (filterStatus == "ALL") leaves
        else leaves.filter { it.status.equals(filterStatus, ignoreCase = true) }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Status Filter Chips Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = filterStatus == "ALL",
                onClick = { filterStatus = "ALL" },
                label = { Text("All (${leaves.size})") }
            )
            FilterChip(
                selected = filterStatus == "PENDING",
                onClick = { filterStatus = "PENDING" },
                label = { Text("Pending ($pendingCount)") }
            )
            FilterChip(
                selected = filterStatus == "APPROVED",
                onClick = { filterStatus = "APPROVED" },
                label = { Text("Approved ($approvedCount)") }
            )
            FilterChip(
                selected = filterStatus == "REJECTED",
                onClick = { filterStatus = "REJECTED" },
                label = { Text("Rejected ($rejectedCount)") }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (filteredLeaves.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.EventBusy,
                title = "No Leave Applications",
                description = if (filterStatus != "ALL") "No leaves in $filterStatus status." else "Teachers can submit leave requests from their dashboard."
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 80.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredLeaves, key = { it.id }) { leave ->
                    val teacher = teachers.find { it.id == leave.teacherId }
                    PrincipalLeaveCard(
                        leave = leave,
                        teacher = teacher,
                        onApprove = {
                            reviewingLeave = leave
                            reviewAction = "APPROVED"
                        },
                        onReject = {
                            reviewingLeave = leave
                            reviewAction = "REJECTED"
                        }
                    )
                }
            }
        }
    }

    if (reviewingLeave != null && reviewAction != null) {
        LeaveDecisionDialog(
            leave = reviewingLeave!!,
            action = reviewAction!!,
            onDismiss = {
                reviewingLeave = null
                reviewAction = null
            },
            onConfirm = { remark ->
                viewModel.updateLeaveStatus(reviewingLeave!!.id, reviewAction!!, remark)
                reviewingLeave = null
                reviewAction = null
            }
        )
    }
}

@Composable
fun PrincipalLeaveCard(
    leave: LeaveApplication,
    teacher: Teacher?,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    modifier: Modifier = Modifier
) {
    val formattedAppliedDate = remember(leave.appliedAt) {
        val format = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        format.format(Date(leave.appliedAt))
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Text(
                            text = teacher?.name ?: "Faculty Member",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${teacher?.subject ?: "Subject"} • Applied $formattedAppliedDate",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                LeaveStatusChip(status = leave.status)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Leave duration & type badge
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = leave.leaveType,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "${leave.startDate} to ${leave.endDate}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Reason: ${leave.reason}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (leave.principalRemark.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Principal Note: ${leave.principalRemark}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            // Action buttons if pending or re-decision
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (leave.status != "APPROVED") {
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = PresentGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).testTag("approve_leave_${leave.id}")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Approve")
                    }
                }

                if (leave.status != "REJECTED") {
                    OutlinedButton(
                        onClick = onReject,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AbsentRed),
                        border = BorderStroke(1.dp, AbsentRed),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).testTag("reject_leave_${leave.id}")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reject")
                    }
                }
            }
        }
    }
}

@Composable
fun LeaveDecisionDialog(
    leave: LeaveApplication,
    action: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var remark by remember { mutableStateOf("") }
    val isApprove = action == "APPROVED"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isApprove) "Approve Leave Application" else "Reject Leave Application",
                fontWeight = FontWeight.Bold,
                color = if (isApprove) PresentGreen else AbsentRed
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Leave: ${leave.leaveType} (${leave.startDate} – ${leave.endDate})",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = remark,
                    onValueChange = { remark = it },
                    label = { Text("Optional Principal Remark / Instructions") },
                    placeholder = { Text(if (isApprove) "e.g. Substitute arranged with Grade 9" else "e.g. Crucial examination week") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth().testTag("dialog_leave_remark_field")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(remark.trim()) },
                colors = ButtonDefaults.buttonColors(containerColor = if (isApprove) PresentGreen else AbsentRed),
                modifier = Modifier.testTag("dialog_leave_confirm_button")
            ) {
                Text(if (isApprove) "Confirm Approval" else "Confirm Rejection")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
