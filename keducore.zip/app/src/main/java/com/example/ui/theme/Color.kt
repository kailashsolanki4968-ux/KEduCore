package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Navy & Indigo palette
val PrimaryNavy = Color(0xFF1A237E)
val PrimaryNavyLight = Color(0xFF534BAE)
val PrimaryNavyDark = Color(0xFF000051)

// Secondary & Accent colors
val AccentGold = Color(0xFFFFB300)
val GoldAccent = AccentGold
val AccentGoldLight = Color(0xFFFFE54C)
val AccentGoldDark = Color(0xFFC68400)

val SecondaryTeal = Color(0xFF00897B)
val SecondaryTealLight = Color(0xFF4EBAAA)

// Status colors
val PresentGreen = Color(0xFF2E7D32)
val PresentGreenContainer = Color(0xFFE8F5E9)
val AbsentRed = Color(0xFFC62828)
val AbsentRedContainer = Color(0xFFFFEBEE)
val PendingAmber = Color(0xFFEF6C00)
val PendingAmberContainer = Color(0xFFFFF3E0)
val InfoBlue = Color(0xFF1565C0)
val InfoBlueContainer = Color(0xFFE3F2FD)

// Surfaces & Backgrounds
val SurfaceLight = Color(0xFFF8F9FE)
val SurfaceCard = Color(0xFFFFFFFF)
val OutlineVariant = Color(0xFFE0E3EB)
val TextPrimary = Color(0xFF1C1B1F)
val TextSecondary = Color(0xFF49454F)

// Dark theme colors
val PrimaryNavy80 = Color(0xFF9FA8DA)
val SecondaryTeal80 = Color(0xFF80CBC4)
val AccentGold80 = Color(0xFFFFE082)
val BackgroundDark = Color(0xFF121316)
val SurfaceDark = Color(0xFF1E1F24)
val SurfaceCardDark = Color(0xFF28292E)
