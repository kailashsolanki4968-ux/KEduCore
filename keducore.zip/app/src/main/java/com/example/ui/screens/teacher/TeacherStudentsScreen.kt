package com.example.ui.screens.teacher

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Student
import com.example.ui.components.EmptyStateView
import com.example.ui.components.ReportCardDialog
import com.example.ui.components.StudentAvatar
import com.example.ui.components.StudentProfileDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.SchoolViewModel

@Composable
fun TeacherStudentsScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val attendanceState by viewModel.teacherAttendanceState.collectAsState()
    val classes by viewModel.classes.collectAsState()
    val assignedClass = attendanceState.schoolClass
    val students = attendanceState.students

    var searchQuery by remember { mutableStateOf("") }
    var selectedStudentForProfile by remember { mutableStateOf<Student?>(null) }
    var selectedStudentForReportCard by remember { mutableStateOf<Student?>(null) }

    val filteredStudents = remember(students, searchQuery) {
        if (searchQuery.isBlank()) students
        else students.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
            it.rollNumber.contains(searchQuery, ignoreCase = true) ||
            it.parentContact.contains(searchQuery, ignoreCase = true) ||
            it.parentName.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        if (assignedClass == null) {
            EmptyStateView(
                icon = Icons.Default.School,
                title = "No Class Assigned",
                description = "You do not have an assigned class to view student rosters."
            )
        } else {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Class: ${assignedClass.displayName}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Surface(
                            color = SecondaryTeal.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "Assigned Class",
                                color = SecondaryTeal,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "${students.size} Enrolled Students • Room ${assignedClass.roomNumber} • Read-Only Records",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("teacher_students_search_field"),
                placeholder = { Text("Search class students by name or roll...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            if (filteredStudents.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.PersonSearch,
                    title = "No Students Found",
                    description = "No students match your query."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 80.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredStudents, key = { it.id }) { student ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedStudentForProfile = student }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                StudentAvatar(
                                    avatarKey = student.photoAvatar,
                                    gender = student.gender,
                                    size = 44
                                )

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(
                                            text = student.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Surface(
                                            color = MaterialTheme.colorScheme.surfaceVariant,
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = "Roll #${student.rollNumber}",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }

                                    if (student.parentContact.isNotBlank() || student.parentName.isNotBlank()) {
                                        Text(
                                            text = "Parent: ${student.parentName.ifBlank { "Guardian" }} (${student.parentContact})",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                OutlinedButton(
                                    onClick = { selectedStudentForReportCard = student },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Report", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    selectedStudentForProfile?.let { st ->
        StudentProfileDialog(
            student = st,
            classes = classes,
            viewModel = viewModel,
            onDismiss = { selectedStudentForProfile = null },
            onEdit = null, // Teacher has read-only access to official student details
            onGenerateReportCard = {
                selectedStudentForProfile = null
                selectedStudentForReportCard = it
            }
        )
    }

    selectedStudentForReportCard?.let { st ->
        ReportCardDialog(
            student = st,
            schoolClass = assignedClass,
            viewModel = viewModel,
            onDismiss = { selectedStudentForReportCard = null }
        )
    }
}
